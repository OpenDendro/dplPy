from __future__ import print_function

__copyright__ = """
   dplPy for tree ring width time series analyses
   Copyright (C) 2021  OpenDendro

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""

__license__ = "GNU GPLv3"

#!/usr/bin/python
# -*- coding: utf-8 -*-

# Date: 11/17/2021 
# Author: Tyson Lee Swetnam
# Project: OpenDendro- Writers
# Description: Writers for all supported file types (*.CSV, *.RWL, and *.TXT)
# 
# example usages: 
# >>> import dplpy as dpl 
# >>> dpl.writers("./data/in_file.csv", "./data/out_file.rwl")
# >>> dpl.writers("./data/in_file.rwl", "./data/out_file.txt")
# >>> dpl.writers("./data/in_file.txt", "./data/out_file.csv")
# 
# example command line application:
# $ python src/dplpy.py writer --input ./data/in_file.csv --output ./data/out_file.rwl
#
# module uses two arguments: input file and output file 
# define `writer` module as a definition function
# input is expected to be a file path with file name and extension

import pandas as pd
import numpy as np
from ._validate import _require_dataframe
from .site_metadata import SiteMetadata


def _tridas_metadata_from_header(header):
    """Map a writers() `header` (a SiteMetadata, a dict, or None) onto what
    write_tridas() wants: a (metadata, taxon) pair. SiteMetadata is site-level,
    so its site name becomes the object title and its species the element taxon.
    Returns (metadata_or_None, taxon_or_None); the convenience path writes with
    validate=False, so missing fields become empty placeholders."""
    if header is None:
        return (None, None)
    if isinstance(header, SiteMetadata):
        md = {
            "project_title": header.site_name,
            "investigator": header.investigators,
            "objects": [{"title": header.site_name, "type": "unknown"}],
        }
        return (md, header.species_name)
    if isinstance(header, dict):
        return (header, header.get("taxon"))
    # a TridasMetadata (or anything write_tridas accepts) passes through
    return (header, None)


def writers(data: pd.DataFrame, label: str, format: str, header=None,
            chronology_type="standard", column="std", prec=0.001, gaps=-99,
            sep="\t", float_format="%.4f", na_rep="NA"):
    """Output dplpy datasets to .csv, .rwl and .crn files.

    Write a dataframe to a .csv, .rwl, .crn or .txt file as set by ``format``,
    created in the current directory unless a path is included in ``label``. For
    'csv'/'rwl', ``data`` is a ring-width dataframe (years x series); for 'crn',
    ``data`` is a *chronology* (from dpl.chron()) and a ``header`` of site metadata
    is REQUIRED to populate the Tucson .crn header.

    Parameters
    ----------
    data : pandas dataframe
        ring widths (csv/rwl) or a chronology from dpl.chron() (crn).
    label : str
        name (can include file path) to give the file; no extension.
    format : str
        'csv', 'rwl', 'crn', or 'txt'.
    header : dict, required for format='crn'
        site metadata with the keys: 'site_id', 'site_name', 'species_code',
        'state_country', 'species', 'elevation', 'latitude', 'longitude',
        'investigators'; optionally 'completion_date'. First/last year are taken
        from the chronology.
    chronology_type : str, default 'standard'
        for format='crn', the ITRDB chronology type written in header record 2:
        'standard' (blank code), 'arstan' ('A'), or 'residual' ('R').
    column : str, default 'std'
        for format='crn', which chronology column to write (e.g. 'std', 'res').
    prec : float, default 0.001
        for format='rwl', the measurement precision in mm: 0.001 (values x1000,
        end marker -9999) or 0.01 (values x100, end marker 999); the
        precision->marker mapping follows dplR's write.tucson. Note dplPy defaults
        to 0.001 (dplR defaults to 0.01) and encodes interior gaps via ``gaps``.
    gaps : {int, "split"}, default -99
        for format='rwl', how to encode a *true interior gap* (a NaN inside a series;
        a real 0 is a locally absent ring and is always written as 0): a negative
        integer (default -99) writes that sentinel in the gap (it must be negative so
        it is not read as a ring width, and not a stop marker; the reader turns it
        back into NaN), or "split" closes the block with the end marker and reopens a
        new block at the next present year.
    sep, float_format, na_rep :
        for format='txt', the column delimiter (default tab), printf float format
        (default '%.4f', None for full precision), and missing-value text (default
        'NA'). For 'txt', ``data`` may be a DataFrame, a single Series, or a list of
        year-aligned Series.

    Returns
    -------
    None
    """
    # 'txt' accepts a DataFrame, a single Series, or a list of year-aligned Series
    # (the author chooses the columns). Every other format requires a DataFrame.
    if format != "txt":
        _require_dataframe(data)

    if not isinstance(label, str):
        raise TypeError("Expected label to be of type str, not " + str(type(label)))

    if not isinstance(format, str):
        raise TypeError("Expected format to be of type str, not " + str(type(format)))

    # TRiDaS is written by the standalone writer (its metadata surface dwarfs the
    # other formats). This is the convenience path: treat `data` as ring widths
    # unless it carries a samp_depth column (a chronology). The full-control path,
    # with mandatory-field validation, is dpl.write_tridas().
    if format == "tridas":
        from .tridas import write_tridas, TridasMetadata
        cols = [str(c).lower() for c in data.columns]
        is_crn = any(c.startswith("samp_depth") or c.startswith("samp.depth")
                     for c in cols)
        md, taxon = _tridas_metadata_from_header(header)
        out = write_tridas(label,
                           rwl=None if is_crn else data,
                           crn=data if is_crn else None,
                           metadata=md, taxon=taxon, prec=prec, validate=False)
        print("Writing to " + out)
        print("Done.")
        return

    filename = label + "." + format
    print("Writing to " + filename)
    output = open(filename, "w")
    try:
        if format == "csv":
            write_csv(data, output)
        elif format == "rwl":
            write_rwl(data, output, prec=prec, gaps=gaps)
        elif format == "crn":
            write_crn(data, output, header=header,
                      chronology_type=chronology_type, column=column)
        elif format == "txt":
            write_txt(data, output, sep=sep, float_format=float_format, na_rep=na_rep)
        else:
            raise ValueError("Invalid file format given as parameter. Accepted file formats are csv, rwl, crn and txt")
    finally:
        output.close()
    print("Done.")


def conv_data(data):
    if np.isnan(data):
        return "NA"
    else:
        return str(data)


def write_csv(data, file):
    file.write('"Year","')
    file.write('","'.join(data.columns.tolist()))
    file.write('"\n')

    for year, row in data.iterrows():
        file.write(str(year))
        file.write(",")
        file.write(",".join(map(conv_data, row)))
        file.write('\n')


def write_rwl(data, file, prec=0.001, gaps=-99):
    """Write a ring-width dataframe (years x series -- raw widths or detrended RWI) to
    a Tucson decadal .rwl file.

    ``prec`` is the measurement precision in mm; the precision->marker mapping
    follows dplR's write.tucson: 0.001 writes values * 1000 with a -9999 end marker,
    0.01 writes values * 100 with a 999 end marker. Values are right-justified in
    6-column fields. dplPy defaults to ``prec=0.001`` (dplR defaults to 0.01) and
    encodes interior gaps via ``gaps`` rather than dplR's 0 / -9.99 missing string.

    A real 0 in ``data`` is a *locally absent ring* and is always written as 0.
    ``gaps`` controls how a *true interior gap* (a NaN inside a series' span) is
    encoded:

    * a negative integer (default ``-99``): write that sentinel in the gap within
      one continuous block. It must be negative (so the reader does not read it as a
      width) and must not collide with a stop marker; the reader turns it back into
      NaN on read.
    * ``"split"``: close the current block with the end marker and reopen a new
      block at the next present year, restoring the gap as NaN on read.
    """
    if prec == 0.01:
        rproc, stop_code = 100, 999
    elif prec == 0.001:
        rproc, stop_code = 1000, -9999
    else:
        raise ValueError("prec must be 0.01 or 0.001, got " + repr(prec))

    if gaps != "split":
        # A gap sentinel: must be a plain integer, negative (so it is never read
        # as a width), and not a value the reader treats specially (999 / -9999
        # are stop / precision-shift markers at these precisions).
        if isinstance(gaps, bool) or not isinstance(gaps, (int, np.integer)):
            raise ValueError('gaps must be "split" or a negative integer '
                             '(e.g. -9 or -99), got ' + repr(gaps))
        gaps = int(gaps)
        if gaps >= 0:
            raise ValueError("gaps sentinel must be negative so it is not read as "
                             "a ring width, got " + repr(gaps))
        if gaps in (-9999, 999, stop_code):
            raise ValueError("gaps sentinel " + repr(gaps) + " collides with a "
                             "stop marker; use e.g. -9 or -99")

    def head(name, year):
        # The series id + year end at column 12. A BC (negative) year needs one
        # extra column, taken from the id field.
        if year < 0:
            return str(name).ljust(7) + str(year).rjust(5)
        return str(name).ljust(8) + str(year).rjust(4)

    def cell(value):
        return "%6d" % int(value)

    for series in data.columns:
        col = data[series]
        start = col.first_valid_index()
        end = col.last_valid_index()
        if start is None:                           # all-NaN series: skip
            continue
        i, end = int(start), int(end)
        file.write(head(series, i))
        while i <= end:
            if np.isnan(col[i]) and gaps == "split":
                # split mode: close this block, skip the NaN run, reopen at the
                # next present year.
                file.write(cell(stop_code) + "\n")
                while i <= end and np.isnan(col[i]):
                    i += 1
                if i <= end:
                    file.write(head(series, i))
                continue
            if np.isnan(col[i]):
                file.write(cell(gaps))              # sentinel; stays in the block
            else:
                file.write(cell(round(col[i] * rproc)))
            i += 1
            if i % 10 == 0:                         # new decade line
                file.write("\n" + head(series, i))
        file.write(cell(stop_code) + "\n")


# Required site-metadata keys for the .crn header, and the ITRDB chronology
# type codes written in header record 2 (columns 62-63).
_CRN_HEADER_KEYS = ["site_id", "site_name", "species_code", "state_country",
                    "species", "elevation", "latitude", "longitude",
                    "investigators"]
_CRN_TYPE_CODE = {"standard": "  ", "arstan": "A ", "residual": "R "}


def write_crn(chron_data, file, header=None, chronology_type="standard", column="std"):
    """Write a chronology to a Tucson .crn file.

    ``chron_data`` is a chronology -- the output of dpl.chron() -- with an index
    column (``column``, default 'std') and a 'samp_depth' column, indexed by
    year. Index values are written as integers = round(index, 3) * 1000 (so 1000
    is mean growth), with the sample depth alongside, in the ITRDB decadal layout;
    the missing-value code is 9990. ``header`` populates the three ITRDB header
    records; it may be a plain dict (keys below) or a ``SiteMetadata`` object
    (e.g. ``dpl.SiteMetadata.from_rwl(rwl)``), which is rendered to that dict.
    """
    if column not in chron_data.columns:
        raise ValueError("chronology column '" + str(column) + "' not found; "
                         "available columns: " + str(list(chron_data.columns)))
    if "samp_depth" not in chron_data.columns:
        raise ValueError("chronology must have a 'samp_depth' column -- pass the "
                         "output of dpl.chron().")
    # Accept a SiteMetadata (the shared metadata object) as well as a plain dict.
    # A SiteMetadata is rendered to the .crn header dict; a dict is used as-is.
    if isinstance(header, SiteMetadata):
        header = header.to_crn_header()
    if not isinstance(header, dict):
        raise ValueError("writing a .crn file requires a 'header' dict (or a "
                         "SiteMetadata) of site metadata with keys: "
                         + ", ".join(_CRN_HEADER_KEYS))
    missing = [k for k in _CRN_HEADER_KEYS if k not in header]
    if missing:
        raise ValueError("header is missing required key(s): " + ", ".join(missing))
    ct = str(chronology_type).lower()
    if ct not in _CRN_TYPE_CODE:
        raise ValueError("chronology_type must be 'standard', 'arstan', or 'residual'.")

    years = np.asarray(chron_data.index, dtype=int)
    idx = chron_data[column].to_numpy(dtype=float)
    depth = chron_data["samp_depth"].to_numpy()
    first_yr, last_yr = int(years.min()), int(years.max())
    site_id = str(header["site_id"])[:6]

    # --- three ITRDB header records ---
    def fld(v, w):                                  # left-justified fixed field
        return str(v)[:w].ljust(w)
    lat, lon = str(header["latitude"]), str(header["longitude"])
    lat_long = (lat + lon) if len(lon) > 5 else (lat + " " + lon)
    yrs = ("%d %d" % (first_yr, last_yr)).ljust(9)
    rec1 = fld(site_id, 6) + "   " + fld(header["site_name"], 52) + fld(header["species_code"], 4)
    rec2 = (fld(site_id, 6) + "   " + fld(header["state_country"], 13)
            + fld(header["species"], 18) + fld(header["elevation"], 5) + "  "
            + fld(lat_long, 10) + "    " + _CRN_TYPE_CODE[ct] + "    " + yrs)
    rec3 = (fld(site_id, 6) + "   " + fld(header["investigators"], 63)
            + fld(header.get("completion_date", ""), 8))
    file.write(rec1 + "\n" + rec2 + "\n" + rec3 + "\n")

    # --- decadal data records ---
    def pair(v, d):
        if np.isnan(v):
            return "9990  0"                        # missing-value marker + 0 depth
        return ("%4d" % int(round(v * 1000))) + ("%3d" % int(d))
    decades = years // 10 * 10
    unique_decades = sorted(set(decades.tolist()))
    lines = []
    for di, dec in enumerate(unique_decades):
        pos = np.flatnonzero(decades == dec)
        n = len(pos)
        pairs = "".join(pair(idx[j], depth[j]) for j in pos)
        # the opening (partial) decade is padded at the FRONT to 10 pairs
        front = ("9990  0" * (10 - n)) if di == 0 else ""
        lines.append(site_id.ljust(6) + ("%4d" % int(years[pos[0]])) + front + pairs)
    # pad the final (partial) decade at the END to 10 pairs
    n_last = int((decades == unique_decades[-1]).sum())
    lines[-1] = lines[-1] + "9990  0" * (10 - n_last)
    file.write("\n".join(lines) + "\n")


def write_txt(data, file, sep="\t", float_format="%.4f", na_rep="NA"):
    """Write a set of year-aligned variables to a tab/space-delimited text table.

    This is a general "columns of your choosing" writer, modelled on ARSTAN's
    "tabs" file but not fixed to its columns: you decide what to output. Typical
    ARSTAN columns -- sample depth, mean segment length, mean age, and the raw /
    standard / residual / ARSTAN chronologies -- are assembled by the caller from
    dpl.samp_stats() and dpl.chron_ars() (and a raw-width mean), e.g.::

        meta = dpl.samp_stats(data)                     # samp_depth, seg, age
        ars  = dpl.chron_ars(rwi)                        # std, res, ars, samp_depth
        raw  = data.mean(axis=1).rename("raw")          # raw-width mean chronology
        tabs = pd.concat([meta[["samp_depth", "seg", "age"]], raw,
                          ars[["std", "res", "ars"]]], axis=1)
        dpl.writers(tabs, "site_tabs", "txt")

    Parameters
    ----------
    data : pandas dataframe, or a single Series, or a list/tuple of Series
        the variables to write, one per output column. A list/tuple of named
        Series is aligned on the union of their year indexes; each column's header
        is its Series/column name.
    sep : str, default "\\t"
        column delimiter (tab by default; pass e.g. " " or "," for other layouts).
    float_format : str or None, default "%.4f"
        printf-style format for floating-point values; None writes full precision.
    na_rep : str, default "NA"
        text written for missing (NaN) cells.
    """
    if isinstance(data, pd.Series):
        frame = data.to_frame()
    elif isinstance(data, (list, tuple)):
        if not all(isinstance(s, pd.Series) for s in data):
            raise TypeError("For 'txt', a list input must contain only pandas "
                            "Series (one per column).")
        frame = pd.concat(list(data), axis=1)
    elif isinstance(data, pd.DataFrame):
        frame = data
    else:
        raise TypeError("Expected a pandas DataFrame, Series, or a list of Series, "
                        "not " + str(type(data)))

    frame = frame.sort_index()
    frame.index.name = frame.index.name or "year"
    frame.to_csv(file, sep=sep, float_format=float_format, na_rep=na_rep)
