from __future__ import print_function

__copyright__ = """
   dplPy for tree ring width time series analyses
   Copyright (C) 2024  OpenDendro

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
"""

__license__ = "GNU GPLv3"

#!/usr/bin/python
# -*- coding: utf-8 -*-

# Date: 9/8/2022
# Author: Ifeoluwa Ale
# Project: OpenDendro- Readers
# Description: Reads data from supported file types (*.CSV and *.RWL)
#              and stores them in a dataframe
#
# The Tucson (.rwl) reader was substantially hardened in v0.2.x to handle
# the "not-that-rare" formatting problems found in real ITRDB files while
# preserving byte-for-byte backward compatibility on clean files. The design
# mirrors dplR's read.tucson() robustness model (header auto-detection, a
# fixed-width parse with a whitespace-delimited fallback, per-series precision
# detection, and tolerant per-line error handling), with two DELIBERATE
# departures from dplR agreed for dplPy:
#
#   * No-data internal gaps (years with no row at all) stay NaN, which keeps
#     genuine gaps out of any downstream mean/detrend.
#   * Anomalous negative values (anything < 0 that is not the -9999 stop
#     marker, e.g. -7 or -2599) are set to NaN AND a warning is emitted. Ring
#     widths cannot be negative, so these are treated as missing and the user
#     is told.

import os
import re
import warnings
import urllib.request
from collections import Counter
from datetime import date

import pandas as pd
import numpy as np


def _read_text(filename, encoding=None):
    """Read a text file as a string, resolving its character encoding.

    UTF-8 is tried first -- it is self-validating and ASCII passes, so virtually
    every clean ITRDB file takes this path unchanged. If the bytes are not valid
    UTF-8 and the caller named an ``encoding``, that is used; otherwise the file is
    read as latin1, which decodes all 256 byte values losslessly, so a wrong guess
    discards nothing and the file can be re-read with ``encoding=`` set. This keeps
    a single accented byte in a header comment (an investigator's name, the ITRDB
    norm for European sites) from crashing the reader with a UnicodeDecodeError.

    Returns ``(text, used_encoding, assumed)`` where ``assumed`` is True only when
    the latin1 fallback was taken without the caller naming an encoding."""
    with open(filename, "rb") as fh:
        raw = fh.read()
    if encoding is not None:
        return raw.decode(encoding), encoding, False
    try:
        return raw.decode("utf-8"), "utf-8", False
    except UnicodeDecodeError:
        return raw.decode("latin1"), "latin1", True


def readers(filename: str, skip_lines=0, header=None, strict=True, format=None,
            join=True, encoding=None):
    """Read a common ring-width data file (.csv, .rwl) into a pandas DataFrame.

    Parameters
    ----------
    filename : str
        a data file (.CSV, .RWL or .RAW). May be a local path or an http(s) URL
        (e.g. from the NOAA/ITRDB archive) -- both are read the same way.
    header : bool or None, default None
        whether a 3-line site-metadata header sits at the top of the file. ``None``
        auto-detects it the way dplR does; pass ``True``/``False`` to force.
    skip_lines : int, default 0
        how many of the first lines of the file to skip when reading it.
    format : {None, "tucson", "csv", "tridas"}, default None
        force the file format regardless of suffix. ``None`` infers it: .csv as CSV,
        .rwl/.raw as Tucson, .xml as TRiDaS, any other suffix by sniffing content.
        ("rwl"/"raw" are aliases for "tucson"; "xml" for "tridas".) A TRiDaS file is
        parsed and, for the common single-table case, returned as one ring-width
        DataFrame; a multi-table or chronology TRiDaS file raises with a pointer to
        ``dpl.read_tridas()``, which returns the full ``TridasProject``.
    strict : bool, default True
        ``True`` refuses a file with an unrecoverable problem (fail-loud). ``False``
        (salvage) recovers as much as possible: a self-overlapping or
        precision-shifted series is dropped, a duplicate series ID is renamed and
        kept, and a file with nothing usable returns ``None``. Every action is warned
        about and recorded on ``df.attrs["dplpy_salvage"]``.
    join : bool, default True
        ``True`` (matching dplR) merges a series written as two or more disjoint
        same-ID blocks into one. ``False`` keeps them as separate series (the
        2nd+ block renamed) -- the per-segment view a crossdating QA needs.
    encoding : str or None, default None
        character encoding. ``None`` reads as UTF-8 (covers ASCII) and falls back to
        latin1 with a warning for non-UTF-8 bytes (e.g. an accented investigator
        name). Pass an explicit encoding to silence the warning. The encoding used is
        recorded in ``df.attrs["dplpy_encoding"]``.

    Returns
    -------
    data : pandas dataframe
        Year-indexed ring widths. Non-fatal advisories about the file are attached to
        ``df.attrs`` (and a concise heads-up is printed): ``dplpy_beyond_column``,
        ``dplpy_interior_gaps``, ``dplpy_case_merged``, ``dplpy_case_variant_ids``,
        ``dplpy_blank_lines`` and ``dplpy_encoding`` (plus ``dplpy_salvage`` in
        salvage mode).

    Examples
    --------
    >>> import dplpy as dpl
    >>> data = dpl.readers("../tests/data/csv/file.csv")
    >>> data = dpl.readers("../tests/data/rwl/file.rwl")           # header auto-detected
    >>> data = dpl.readers("https://www.ncei.noaa.gov/pub/data/paleo/treering/"
    ...                    "measurements/northamerica/usa/ak132x.rwl")  # read from a URL

    References
    ----------
    .. [1] https:/opendendro.org/dplpy-man/#readers
    """
    if not isinstance(strict, bool):
        raise ValueError("strict must be True (strict) or False (salvage), got "
                         + repr(strict))

    # `filename` may be a local path or an http(s) URL -- read either the same way.
    is_url = filename.lower().startswith(("http://", "https://"))
    FORMAT = "." + filename.split(".")[-1]

    # Resolve the format: explicit `format` wins; otherwise infer from a known
    # suffix; otherwise sniff the content so a Tucson file with a nonstandard
    # extension (e.g. .txt) still reads.
    if format is not None:
        f = str(format).strip().lower()
        if f in ("tucson", "rwl", "raw"):
            fmt = "tucson"
        elif f == "csv":
            fmt = "csv"
        elif f in ("tridas", "xml"):
            fmt = "tridas"
        else:
            raise ValueError("format must be None, 'tucson', 'csv', or 'tridas'")
    elif filename.upper().endswith(".CSV"):
        fmt = "csv"
    elif filename.upper().endswith((".RWL", ".RAW")):
        fmt = "tucson"
    elif filename.upper().endswith(".XML"):
        fmt = "tridas"
    else:
        fmt = _sniff_format(filename, is_url)
        if fmt is None:
            raise ValueError(
                "Could not determine the file format; pass format='tucson', 'csv', "
                "or 'tridas' (suffixes: .csv, .rwl, .raw, .xml)."
            )
        warnings.warn("File suffix '" + FORMAT + "' not recognized; inferred "
                      + fmt + " format from the file contents.")

    # TRiDaS XML is a different shape (a hierarchy of possibly many tables). For
    # the common single-table file we return one ring-width frame; a multi-table
    # or chronology file raises with a pointer to dpl.read_tridas().
    if fmt == "tridas":
        if is_url:
            raise ValueError("reading TRiDaS from a URL is not supported yet; "
                             "download the .xml file and read it locally.")
        from .tridas import read_tridas_single
        return read_tridas_single(filename)

    # open the input file and read its data into a pandas dataframe
    if fmt == "csv":
        try:
            series_data = pd.read_csv(filename, skiprows=skip_lines,
                                      encoding=encoding)   # None -> pandas default (utf-8)
            csv_encoding, csv_assumed = (encoding or "utf-8"), False
        except UnicodeDecodeError:
            # not valid UTF-8 and no encoding given: fall back to latin1 (lossless)
            series_data = pd.read_csv(filename, skiprows=skip_lines, encoding="latin1")
            csv_encoding, csv_assumed = "latin1", True
        if series_data is not None:
            series_data.attrs["dplpy_encoding"] = csv_encoding
            series_data.attrs["dplpy_encoding_assumed"] = csv_assumed
    else:  # tucson
        if is_url:
            raw_lines = _fetch_url_lines(filename)
            series_data = _lines_to_dataframe(raw_lines, skip_lines, header, strict,
                                              os.path.basename(filename), join=join)
            if series_data is not None:
                series_data.attrs["dplpy_encoding"] = "utf-8"
                series_data.attrs["dplpy_encoding_assumed"] = False
        else:
            series_data = process_rwl_pandas(filename, skip_lines, header, strict,
                                             join=join, encoding=encoding)

    # If no data is returned, then an error was encountered when reading the file.
    if series_data is None:
        if not strict:
            # Salvage mode: nothing usable, but don't derail a batch -- warn and
            # return None so the caller can simply skip this file.
            warnings.warn(
                "No usable data could be read from " + os.path.basename(filename)
                + "; returning None (strict=False)."
            )
            return None
        errorMsg = """
        Error reading file. Check that file exists and that file formatting is consistent with {format} format.
        If your file contains headers, run dpl.headers(file_path, header=True)
        """.format(format=FORMAT)
        raise ValueError(errorMsg)
    salvage_report = series_data.attrs.get("dplpy_salvage", [])
    combined = series_data.attrs.get("dplpy_combined", [])
    case_merged = series_data.attrs.get("dplpy_case_merged", [])
    hdr_skipped = series_data.attrs.get("dplpy_header_lines_skipped", None)
    meta = series_data.attrs.get("dplpy_metadata", None)
    dropped = series_data.attrs.get("dplpy_dropped", 0)
    beyond_column = series_data.attrs.get("dplpy_beyond_column", [])
    interior_gaps = series_data.attrs.get("dplpy_interior_gaps", [])
    blank_lines = series_data.attrs.get("dplpy_blank_lines", [])
    enc_used = series_data.attrs.get("dplpy_encoding", "utf-8")
    enc_assumed = series_data.attrs.get("dplpy_encoding_assumed", False)
    precision = series_data.attrs.get("dplpy_precision", {})
    mixed_precision = series_data.attrs.get("dplpy_mixed_precision", False)
    series_data.set_index('Year', inplace=True, drop=True)
    series_data.attrs["dplpy_encoding"] = enc_used                 # re-attach
    series_data.attrs["dplpy_encoding_assumed"] = enc_assumed
    series_data.attrs["dplpy_precision"] = precision
    series_data.attrs["dplpy_mixed_precision"] = mixed_precision
    series_data.attrs["dplpy_salvage"] = salvage_report            # re-attach (survives set_index)
    series_data.attrs["dplpy_combined"] = combined
    series_data.attrs["dplpy_case_merged"] = case_merged
    series_data.attrs["dplpy_dropped"] = dropped
    series_data.attrs["dplpy_beyond_column"] = beyond_column
    series_data.attrs["dplpy_interior_gaps"] = interior_gaps
    series_data.attrs["dplpy_blank_lines"] = blank_lines
    if hdr_skipped is not None:
        series_data.attrs["dplpy_header_lines_skipped"] = hdr_skipped
    if meta is not None:
        series_data.attrs["dplpy_metadata"] = meta

    # Advisory: series IDs that differ only in letter case (e.g. 'FDD08A' vs
    # 'FDD08a'). A case-sensitive read keeps them as separate series, and a core
    # whose ID case flips mid-file can leave one block without its stop marker
    # (which then trips the "no stop marker / assuming precision" fallback).
    # Almost always one core with an inconsistent-case ID.
    case_variants = _case_variant_findings(series_data.columns)
    series_data.attrs["dplpy_case_variant_ids"] = case_variants

    basename = os.path.basename(filename)

    # Advisory: the file was not valid UTF-8 and no encoding was named, so it was
    # read as latin1 (lossless, but non-ASCII header text may be approximate).
    if series_data.attrs.get("dplpy_encoding_assumed"):
        warnings.warn(
            basename + " is not valid UTF-8; read as latin1. Non-ASCII text (e.g. "
            "accented names in the header) may be approximate -- pass encoding= to "
            "set it explicitly. Ring-width values are unaffected.")

    first_year = int(series_data.index.min())
    last_year = int(series_data.index.max())

    # Sanity check: a ring cannot post-date the present. A most-recent year in the
    # future flags a misdated file or a mis-parsed year (e.g. a 5-digit year from
    # a bad field split). Strict (strict=True) stops; salvage warns and keeps.
    this_year = date.today().year
    if last_year > this_year:
        msg = (basename + ": the most recent year is " + str(last_year)
               + ", which is in the future (the current year is " + str(this_year)
               + "). A ring cannot post-date the present -- the file may be "
               "misdated or a year was mis-parsed.")
        if not strict:
            warnings.warn(msg)
        else:
            raise ValueError(msg)

    # One-line success summary (concise for notebooks): file, format, series
    # count, and the period covered, plus a note if a header was auto-detected.
    label = {"csv": "csv", "tucson": "rwl"}.get(fmt, fmt)
    summary = (basename + " successfully extracted as " + label + " file with "
               + str(series_data.shape[1]) + " series covering the period from "
               + str(first_year) + " to " + str(last_year))
    if hdr_skipped:
        summary += (" (auto-detected " + str(hdr_skipped) + " header line"
                    + ("s" if hdr_skipped != 1 else "") + ")")
    if dropped:
        summary += (", with " + str(dropped) + " unreadable value"
                    + ("s" if dropped != 1 else "") + " set to NaN")
    print(summary)

    # Report any duplicate-ID series that were merged from more than one block
    # (non-overlapping segments sharing a code), so the combining is visible.
    if combined:
        print("  " + str(len(combined)) + " series combined from non-overlapping "
              "duplicate IDs (merged segments):")
        for c in combined:
            print("    " + str(c["series"]) + ": " + str(c["n_blocks"])
                  + " segments spanning " + str(c["first_year"]) + " to "
                  + str(c["last_year"]))

    # Report case-variant series that were merged into one core (IDs differing only
    # in letter case, disjoint years, a missing stop marker -- see read_rwl). Shown
    # so the merge is never silent; the pieces are also on df.attrs['dplpy_case_merged'].
    if case_merged:
        print("  " + str(len(case_merged)) + " case-variant series merged (IDs "
              "differing only in letter case with a missing stop marker -- likely "
              "one core split by a case change):")
        for c in case_merged:
            print("    " + " / ".join(c["ids"]) + " -> " + str(c["canonical"])
                  + " (" + str(c["first_year"]) + " to " + str(c["last_year"]) + ")")

    # Report any duplicate-ID series that were kept SEPARATE under join=False (the
    # counterpart of the merge report above), so the split is visible in both strict
    # and salvage mode -- it lives in df.attrs["dplpy_salvage"] but is a normal,
    # successful action, not an error, so it is surfaced here rather than only warned.
    splits = [r for r in salvage_report if str(r.get("action", "")).startswith("split to ")]
    if splits:
        print("  " + str(len(splits)) + " duplicate series ID"
              + ("s" if len(splits) != 1 else "")
              + " kept as separate series (join=False):")
        for s in splits:
            newid = str(s["action"]).replace("split to ", "")
            print("    " + str(s["series"]) + ": disjoint block kept as " + newid)

    # Advisory heads-ups: the file read fine, but these spots deserve a human eye.
    # 1. Characters beyond the last data column (col 72) that were not parsed --
    #    most importantly a value that overflowed its field and was truncated.
    if beyond_column:
        print("  heads-up: " + str(len(beyond_column)) + " row"
              + ("s" if len(beyond_column) != 1 else "")
              + " had characters beyond the last data column (col 72) that were "
              "not parsed -- check for a truncated value:")
        for b in beyond_column[:10]:
            note = ("  (looks like a split value)" if b["kind"] == "truncated_value"
                    else "")
            print("    " + str(b["series"]) + " " + str(b["year"]) + ": read "
                  + repr(b["in_column"]) + ", ignored " + repr(b["unparsed"]) + note)
        if len(beyond_column) > 10:
            print("    ... and " + str(len(beyond_column) - 10) + " more "
                  "(see df.attrs['dplpy_beyond_column']).")
    # 2. Short interior gaps -- a blank year (or two) between measured years, i.e.
    #    a value that was probably dropped. Long structural gaps are recorded on
    #    df.attrs['dplpy_interior_gaps'] but not announced (they are usually real).
    short_gaps = [g for g in interior_gaps if g["short_gap_years"]]
    if short_gaps:
        total = sum(len(g["short_gap_years"]) for g in short_gaps)
        print("  heads-up: " + str(total) + " short interior gap"
              + ("s" if total != 1 else "") + " (a blank year between measured "
              "years -- possibly a dropped value) in " + str(len(short_gaps))
              + " series:")
        for g in short_gaps[:10]:
            yrs = ", ".join(str(y) for y in g["short_gap_years"][:8])
            print("    " + str(g["series"]) + ": " + yrs)
        if len(short_gaps) > 10:
            print("    ... and " + str(len(short_gaps) - 10) + " more series "
                  "(see df.attrs['dplpy_interior_gaps']).")
    # 3. Series IDs that differ only in letter case -- read as separate series but
    #    usually one core whose ID case flipped mid-file (which can also strip a
    #    stop marker from one block, tripping the precision fallback). Name the
    #    real cause so it isn't mistaken for a generic missing-terminator issue.
    if case_variants:
        print("  heads-up: " + str(len(case_variants)) + " set"
              + ("s" if len(case_variants) != 1 else "")
              + " of series IDs differ only in letter case -- read as separate "
              "series, but likely one core each (make the case consistent in the "
              "file if so):")
        for g in case_variants[:10]:
            print("    " + " / ".join(g["ids"]))
        if len(case_variants) > 10:
            print("    ... and " + str(len(case_variants) - 10) + " more "
                  "(see df.attrs['dplpy_case_variant_ids']).")
    return series_data


# ---------------------------------------------------------------------------
# .rwl (Tucson) reading
# ---------------------------------------------------------------------------

def process_rwl_pandas(filename, skip_lines, header, strict=True, join=True,
                       encoding=None):
    """Read a Tucson (.rwl/.raw) file into a Year-indexed dataframe.

    Returns a dataframe with a ``Year`` column (the public ``readers`` wrapper
    sets it as the index), or ``None`` if nothing usable could be parsed. In
    salvage mode (strict=False) the returned frame carries a report of what
    was dropped/renamed on ``df.attrs["dplpy_salvage"]``.
    """
    text, enc, assumed = _read_text(filename, encoding)
    raw_lines = text.splitlines(keepends=True)
    df = _lines_to_dataframe(raw_lines, skip_lines, header, strict,
                             os.path.basename(filename), join=join)
    if df is not None:
        df.attrs["dplpy_encoding"] = enc
        df.attrs["dplpy_encoding_assumed"] = assumed
    return df


# A Tucson .rwl has at most 3 header/metadata lines before the first data row (the
# ITRDB spec's site-name / region-species / investigators records; 0-2 also occur).
# More than 3 means the file is not a clean Tucson .rwl: either a nonstandard file
# (e.g. the fl0xx sites' accidentally doubled 3-line header) or an altogether
# different format (most often a NOAA Template file -- a tab-delimited table under a
# ~100-line "# ..." metadata header). Forcing those through the decadal grammar
# yields silent garbage, so strict mode raises and salvage mode warns + returns None
# when the header runs past this limit. A caller who is sure can pass header=False.
_MAX_AUTO_HEADER = 3

# Header phrases unique to a NOAA Template file (a tab-delimited data table under a
# large '#' metadata header, e.g. ITRDB's '*-noaa.rwl'). These live in the '#'
# lines, which are stripped as comments before the header-length guard runs, so a
# NOAA file must be recognised from the RAW lines up front -- otherwise its tab
# header is force-fit through the Tucson grammar and reported as a misaligned row.
_NOAA_TEMPLATE_MARKERS = (
    "world data service for paleoclimatology",
    "noaa paleoclimatology program",
    "noaa template",
    "template version",
)


def _is_noaa_template(raw_lines):
    """True if the file is a NOAA Template file rather than a Tucson .rwl, judged
    by the NOAA template banner in its metadata header (checked on the raw lines,
    before '#' comments are stripped)."""
    for line in raw_lines[:60]:
        low = line.lower()
        if any(m in low for m in _NOAA_TEMPLATE_MARKERS):
            return True
    return False


def _lines_to_dataframe(raw_lines, skip_lines, header, strict, source_name, join=True):
    """Shared pipeline for the file and URL readers: clean lines, resolve the
    header, parse, and assemble the Year-column dataframe (with salvage report on
    ``df.attrs['dplpy_salvage']``). Returns None if nothing usable is present."""
    # 0. Reject a NOAA Template file up front (its '#' markers are stripped as
    #    comments below, and its tab-delimited table is not Tucson data). A caller
    #    who is sure the file really is Tucson can bypass this with header=False.
    if header is not False and _is_noaa_template(raw_lines):
        msg = (source_name + " is a NOAA Template file, not a Tucson .rwl; use the "
               "Tucson decadal file (the same name without '-noaa').")
        if not strict:
            warnings.warn(msg + " Returning None.")
            return None
        raise ValueError("Cannot read file -- " + msg)
    # 1. Drop blank lines and comment lines. A line is a comment (see
    #    _is_comment_line) when its first non-blank character is '#', or when it
    #    contains a '#' anywhere and does not parse as a data row -- so real series
    #    IDs containing '#' (e.g. 'SP#1') are kept. Blank lines are harmless (a
    #    trailing newline, or a "double-spaced" ITRDB file), so they are recorded
    #    silently on df.attrs["dplpy_blank_lines"] (1-indexed against the original
    #    input) rather than warned about line by line.
    clean_lines = []
    blank_lines = []
    for lineno, line in enumerate(raw_lines, start=1):
        line = line.rstrip("\r\n")
        if len(line.strip()) == 0:
            blank_lines.append(lineno)
            continue
        if _is_comment_line(line):
            continue  # a '#'-comment or a '#'-marked note row (not a '#' inside an ID)
        clean_lines.append(line)

    # 2. Honour an explicit skip_lines against the cleaned stream.
    if skip_lines:
        clean_lines = clean_lines[skip_lines:]
    if len(clean_lines) == 0:
        return None

    # 3. Resolve the header. Rather than assume a fixed 3-line header, skip any
    #    number of leading header/metadata lines up to the first line that looks
    #    like data (robust to 1-, 2- or other-length headers). header=False
    #    disables this; header=True and header=None both skip robustly.
    if header is False:
        start = 0
    else:
        start = _first_data_line_index(clean_lines)

    # Guard: refuse a file whose header is too long to be a Tucson .rwl. This
    # catches non-Tucson formats (e.g. NOAA Template files) before they are
    # force-fit into the decadal grammar and returned as garbage. header=False
    # (start forced to 0) bypasses the guard for a caller who is sure.
    if start > _MAX_AUTO_HEADER:
        msg = (source_name + " does not look like a Tucson .rwl file: " + str(start)
               + " header/metadata lines precede the first data row (a Tucson .rwl "
               "has at most 3). It may be a nonstandard file (e.g. a doubled header) "
               "or a different format -- for example a NOAA Template file (a "
               "tab-delimited table under a large '#' metadata header). If it really "
               "is Tucson data, pass header=False to force the read.")
        if not strict:
            warnings.warn(msg + " Returning None.")
            return None
        raise ValueError(msg)

    header_block = clean_lines[:start]      # the lines auto-skipped as header
    clean_lines = clean_lines[start:]
    if len(clean_lines) == 0:
        return None

    parsed = read_rwl(clean_lines, strict=strict, join=join)
    if parsed is None:
        return None
    rwl_data, precision, order, report, dropped, combined, case_merged = parsed

    # 4. Assemble the dataframe. The index spans the first to last year with
    #    data; years with no row stay NaN (a deliberate departure from dplR,
    #    which zero-fills such gaps).
    df = _assemble_dataframe(rwl_data, precision, order)
    if df is None:
        return None
    df.attrs["dplpy_salvage"] = report
    df.attrs["dplpy_combined"] = combined            # duplicate IDs merged from >1 block
    df.attrs["dplpy_case_merged"] = case_merged      # case-variant IDs merged into one core
    df.attrs["dplpy_dropped"] = dropped              # non-integer + anomalous-negative cells set to NaN
    # Measurement precision per series, in mm: divisor 100 -> 0.01, 1000 -> 0.001
    # (what each series was measured at; the raw integers were divided by it). A
    # file that mixes the two is flagged, since it changes the scale between series.
    prec_mm = {sid: (0.001 if div == 1000 else 0.01)
               for sid, div in precision.items() if sid in df.columns}
    df.attrs["dplpy_precision"] = prec_mm
    df.attrs["dplpy_mixed_precision"] = (len(set(prec_mm.values())) > 1)
    df.attrs["dplpy_header_lines_skipped"] = start   # header lines auto-skipped
    df.attrs["dplpy_metadata"] = _extract_header_metadata(header_block)
    df.attrs["dplpy_blank_lines"] = blank_lines      # blank input lines, dropped silently
    # Advisory (non-fatal) data-quality notes -- surfaced in both strict and salvage
    # mode, since these rows parse successfully but a human should eyeball them.
    df.attrs["dplpy_beyond_column"] = _beyond_column_findings(clean_lines)
    df.attrs["dplpy_interior_gaps"] = _interior_gap_findings(df)
    if not strict and report:
        _warn_salvage_summary(source_name, report)
    return df


# ---------------------------------------------------------------------------
# Header metadata extraction (prototype). The classic ITRDB Tucson header is 3
# lines, each prefixed by the site code + a line number (1/2/3):
#   line 1: site name ............................................ SPCODE
#   line 2: region   species-name   ELEVm   LAT LONG   __   firstYr lastYr
#   line 3: investigator(s)
# Fields are best-effort: anything not confidently found is left None, and the
# raw header lines are always retained for provenance.
# ---------------------------------------------------------------------------

_METADATA_FIELDS = ("site_id", "site_name", "species_code", "species_name",
                    "country_region", "elevation_m", "latitude", "longitude",
                    "first_year", "last_year", "investigators")


_NORTH_AMERICA = frozenset({
    # US states
    "alabama", "alaska", "arizona", "arkansas", "california", "colorado",
    "connecticut", "delaware", "florida", "georgia", "hawaii", "idaho",
    "illinois", "indiana", "iowa", "kansas", "kentucky", "louisiana", "maine",
    "maryland", "massachusetts", "michigan", "minnesota", "mississippi",
    "missouri", "montana", "nebraska", "nevada", "new hampshire", "new jersey",
    "new mexico", "new york", "north carolina", "north dakota", "ohio",
    "oklahoma", "oregon", "pennsylvania", "rhode island", "south carolina",
    "south dakota", "tennessee", "texas", "utah", "vermont", "virginia",
    "washington", "west virginia", "wisconsin", "wyoming",
    "usa", "u.s.a.", "us", "united states",
    # Canada + provinces/territories
    "canada", "alberta", "british columbia", "manitoba", "new brunswick",
    "newfoundland", "labrador", "nova scotia", "ontario", "quebec",
    "saskatchewan", "prince edward island", "yukon", "northwest territories",
    "nunavut",
    # Mexico + Central America (all North + West)
    "mexico", "guatemala", "belize", "honduras", "el salvador", "nicaragua",
    "costa rica", "panama",
})
# South America: entirely West longitude, but latitude straddles the equator.
_SOUTH_AMERICA = frozenset({
    "colombia", "venezuela", "guyana", "suriname", "french guiana", "ecuador",
    "peru", "brazil", "bolivia", "paraguay", "chile", "argentina", "uruguay",
})


def _region_hemisphere(region):
    """Expected (latitude_sign, longitude_sign) for a *standardized ITRDB*
    country/state name, or (None, None) if the name is not recognized. Only the
    Americas are handled -- their longitude is unambiguously West -- because
    Eastern-hemisphere longitude is not determinable from country alone (UK,
    Portugal, Morocco are West while their neighbours are East)."""
    r = (region or "").strip().lower()
    if r in _NORTH_AMERICA:
        return (1, -1)          # North, West
    if r in _SOUTH_AMERICA:
        return (None, -1)       # latitude ambiguous (equator), longitude West
    return (None, None)


def _dm_to_decimal(token):
    """Decode a packed degrees-minutes coordinate (DDMM / DDDMM, optional leading
    '-') to decimal degrees: '3627' -> 36.45, '-2053' -> -20.8833, '00406' -> 4.1."""
    neg = token.startswith("-")
    digits = token.lstrip("-")
    if not digits.isdigit() or len(digits) < 3:
        return None
    minutes = int(digits[-2:])
    degrees = int(digits[:-2])
    if minutes >= 60:
        return None                      # not a valid DDMM value
    val = degrees + minutes / 60.0
    return round(-val if neg else val, 4)


# Precompiled ITRDB Tucson header-parsing patterns (compiled once, not per file).
_RE_HEADER_PREFIX = re.compile(r"^\s*(\S+)\s+(?:\d\s)?(.*)$")
_RE_TRAILING_JUNK = re.compile(r"[\s\-]+$")     # trailing spaces / placeholder dashes
_RE_SPECIES_CODE = re.compile(r"[A-Z]{2,4}")
_RE_YEAR_PAIR = re.compile(r"(-?\d{3,4})\s*(-?\d{3,4})$")
_RE_ELEVATION = re.compile(r"(\d{2,5})\s*[Mm]\b")
_RE_LATLONG = re.compile(r"(-?\d{4})\s*(-?\d{4,5})")
_RE_FIELD_SPLIT = re.compile(r"\s{2,}")
_RE_LEADING_DIGIT = re.compile(r"^-?\d")


def _split_header_prefix(line):
    """Strip the leading 'SITEID  N ' prefix from a header line, returning
    (site_id, remaining_content). The line number (1/2/3) is optional -- some
    ITRDB files omit it -- so a header like 'SFP519AA ARIZONA ...' still splits
    into ('SFP519AA', 'ARIZONA ...')."""
    m = _RE_HEADER_PREFIX.match(line)
    if m:
        return m.group(1), m.group(2)
    toks = line.split()
    return (toks[0] if toks else None), line


def _extract_header_metadata(header_lines):
    """Parse ITRDB Tucson header lines into a metadata dict (best-effort)."""
    md = {k: None for k in _METADATA_FIELDS}
    md["n_header_lines"] = len(header_lines)
    md["header_raw"] = list(header_lines)
    if not header_lines:
        return md

    # ---- line 1: site id, site name, species code ----
    sid, c1 = _split_header_prefix(header_lines[0])
    md["site_id"] = sid
    c1 = _RE_TRAILING_JUNK.sub("", c1)          # strip trailing spaces / placeholder dashes
    toks1 = c1.split()
    if toks1 and _RE_SPECIES_CODE.fullmatch(toks1[-1]):
        md["species_code"] = toks1[-1]
        md["site_name"] = c1[:c1.rfind(toks1[-1])].strip() or None
    elif c1.strip():
        md["site_name"] = c1.strip()

    # ---- line 2: region, species name, elevation, lat/long, year range ----
    if len(header_lines) >= 2:
        _, c2 = _split_header_prefix(header_lines[1])
        c2 = _RE_TRAILING_JUNK.sub("", c2)      # strip trailing junk (e.g. ' -')
        # trailing year pair: space-separated OR bunched negatives ('-2220-1890')
        ym = _RE_YEAR_PAIR.search(c2)
        if ym:
            md["first_year"] = int(ym.group(1))
            md["last_year"] = int(ym.group(2))
            c2_geo = c2[:ym.start()]
        else:
            c2_geo = c2
        em = _RE_ELEVATION.search(c2_geo)          # elevation
        if em:
            md["elevation_m"] = int(em.group(1))
        gm = _RE_LATLONG.search(c2_geo)      # packed lat/long
        if gm:
            md["latitude"] = _dm_to_decimal(gm.group(1))
            md["longitude"] = _dm_to_decimal(gm.group(2))
        fields2 = [f for f in _RE_FIELD_SPLIT.split(c2.strip()) if f]
        if fields2:
            md["country_region"] = fields2[0]
            if len(fields2) >= 2 and not _RE_LEADING_DIGIT.match(fields2[1]):
                md["species_name"] = fields2[1]

    # ---- line 3: investigator(s) ----
    if len(header_lines) >= 3:
        _, c3 = _split_header_prefix(header_lines[2])
        c3 = _RE_TRAILING_JUNK.sub("", c3)
        md["investigators"] = c3.strip() or None

    # ---- hemisphere correction ----
    # The packed lat/long carries an unreliable sign (ITRDB files variably omit
    # the '-' on West longitudes or use '-' as a separator). Where the header's
    # country/state is a recognized standardized ITRDB name, force the correct
    # hemisphere. Otherwise leave the decoded sign and flag it unverified, so a
    # caller (e.g. a user's own non-ITRDB file) knows the coordinate sign was not
    # checked.
    md["hemisphere_verified"] = False
    lat_sign, lon_sign = _region_hemisphere(md["country_region"])
    if lat_sign is not None or lon_sign is not None:
        md["hemisphere_verified"] = True
        if lon_sign is not None and md["longitude"] is not None:
            md["longitude"] = lon_sign * abs(md["longitude"])
        if lat_sign is not None and md["latitude"] is not None:
            md["latitude"] = lat_sign * abs(md["latitude"])

    return md


def metadata(filename, header=None, skip_lines=0):
    """Extract site/sample metadata from a Tucson (.rwl) file's header.

    Returns a dict with best-effort fields (site_id, site_name, species_code,
    species_name, country_region, elevation_m, latitude, longitude, first_year,
    last_year, investigators) plus n_header_lines and the raw header lines.
    Unreadable fields are None. Reads only the header, so it is cheap and
    independent of loading the data; accepts a local path or an http(s) URL.
    This is a prototype -- see df.attrs['dplpy_metadata'] for the same result
    captured at read time.
    """
    is_url = filename.lower().startswith(("http://", "https://"))
    if is_url:
        raw = _fetch_url_lines(filename)
    else:
        raw = _read_text(filename)[0].split("\n")
    clean = []
    for line in raw:
        line = line.rstrip("\r\n")
        if len(line.strip()) == 0:
            continue
        if 0 <= line.find("#") <= 77:
            continue
        clean.append(line)
    if skip_lines:
        clean = clean[skip_lines:]
    if not clean:
        return _extract_header_metadata([])
    start = 0 if header is False else _first_data_line_index(clean)
    return _extract_header_metadata(clean[:start])


def _fetch_url_lines(url):
    """Download a Tucson file from an http(s) URL and return it as a list of
    lines, matching what ``open(...).readlines()`` yields for a local file."""
    with urllib.request.urlopen(url) as resp:
        text = resp.read().decode("utf-8", errors="replace")
    return text.split("\n")


def _sniff_format(filename, is_url):
    """Decide 'tucson' vs 'csv' from a file's content when the suffix is not one
    of the recognized ones. Returns 'tucson', 'csv', or None if undetermined.
    A Tucson file has a line that parses as ID + integer year + numeric values;
    a CSV does not (its comma-joined fields fail that parse) but contains commas.
    File-open / network errors are left to propagate (so a missing file raises
    FileNotFoundError rather than a vague 'unknown format')."""
    if is_url:
        lines = _fetch_url_lines(filename)
    else:
        lines = _read_text(filename)[0].split("\n")
    # TRiDaS: a <tridas> element in the first lines (an XML declaration or
    # comments may precede it, so scan a block rather than line 1 alone).
    if any("<tridas" in ln for ln in lines[:30]):
        return "tridas"
    sample = []
    for ln in lines:
        ln = ln.rstrip("\r\n")
        if len(ln.strip()) == 0:
            continue
        if _is_comment_line(ln):               # '#'-comment or '#'-marked note row
            continue
        sample.append(ln)
        if len(sample) >= 50:
            break
    if not sample:
        return None
    start = _first_data_line_index(sample)
    for ln in sample[start:]:
        if _looks_like_data(ln):
            return "tucson"
    if any("," in ln for ln in sample):
        return "csv"
    return None


def _assemble_dataframe(rwl_data, precision, order):
    """Build a Year-column DataFrame from parsed rwl data. Shared by the file and
    URL readers. Years with no value are NaN. Returns None if there is no data."""
    all_years = [yr for series in rwl_data.values() for yr in series]
    if len(all_years) == 0:
        return None
    first_date = min(all_years)
    last_date = max(all_years)
    index = list(range(first_date, last_date + 1))
    df = pd.DataFrame(data={"Year": index})
    series_columns = []
    for series in order:
        div = precision[series]
        # Vectorized: the {year: value} dict becomes a Series indexed by year,
        # divided to mm and reindexed to the full year span (NaN for missing
        # years). Values line up positionally with `index`, exactly as the old
        # per-year comprehension did, but at C speed rather than interpreted.
        col = (pd.Series(rwl_data[series]) / div).reindex(index).to_numpy()
        series_columns.append(pd.Series(data=col, name=series))
    return pd.concat([df] + series_columns, axis=1)


# A short interior gap -- a blank year (or two) flanked by measured years within a
# single series -- is the tell-tale of a value that was probably dropped in data
# entry (e.g. ok049's LIN01A 1939), and is worth a heads-up. A LONG interior gap
# (many blank years in a row) is almost always intentional/structural -- a rotten
# or unmeasurable section, or two disjoint dated segments -- and is common enough
# across the ITRDB (hundreds of series) that warning about it would only train
# users to ignore the message. So every interior gap is recorded on df.attrs, but
# only runs no longer than this are surfaced as an advisory.
_SHORT_GAP_MAX = 2


def _consecutive_runs(sorted_ints):
    """Group a sorted list of ints into runs of consecutive values, e.g.
    [1939, 1970, 1971] -> [[1939], [1970, 1971]]."""
    runs = []
    cur = []
    for y in sorted_ints:
        if cur and y == cur[-1] + 1:
            cur.append(y)
        else:
            if cur:
                runs.append(cur)
            cur = [y]
    if cur:
        runs.append(cur)
    return runs


def _case_variant_findings(columns):
    """Series IDs that are identical except for letter case (e.g. 'FDD08A' and
    'FDD08a'). A case-sensitive read keeps them as separate series; almost always
    they are one core whose ID case flipped mid-file (a data-entry inconsistency),
    which can also leave one block without its stop marker. Returns a list of
    ``{"ids": [...]}`` groups, one per set of case-colliding IDs (order preserved),
    or an empty list when every ID is case-unique."""
    groups = {}
    for c in columns:
        groups.setdefault(str(c).lower(), []).append(str(c))
    return [{"ids": v} for v in groups.values() if len(v) > 1]


def _interior_gap_findings(df):
    """Find interior NaN gaps: years with no value that fall strictly *between* a
    series' first and last measured year (so leading/trailing missing years, which
    are just where a series does not reach, are ignored). Returns a list of
    {series, gap_years, short_gap_years, max_run} -- one entry per series that has
    at least one interior gap. ``short_gap_years`` are the years in runs no longer
    than _SHORT_GAP_MAX (the 'probably a dropped value' subset)."""
    if df is None or "Year" not in df.columns:
        return []
    years = df["Year"].to_numpy()
    findings = []
    for col in df.columns:
        if col == "Year":
            continue
        present_mask = df[col].notna().to_numpy()
        if present_mask.sum() < 2:
            continue
        present_years = years[present_mask]
        lo, hi = int(present_years.min()), int(present_years.max())
        present = set(int(y) for y in present_years.tolist())
        missing = [y for y in range(lo, hi + 1) if y not in present]
        if not missing:
            continue
        runs = _consecutive_runs(missing)
        short_years = [y for r in runs if len(r) <= _SHORT_GAP_MAX for y in r]
        findings.append({"series": col, "gap_years": missing,
                         "short_gap_years": short_years,
                         "max_run": max(len(r) for r in runs)})
    return findings


def _beyond_column_findings(data_lines):
    """Find fixed-width data rows with non-blank characters in the separator column
    that follows the ten value fields (1-indexed column 73 / 0-indexed 72 -- the
    reserved gap before the optional site-ID field at cols 74-78). That column
    should always be blank; a character there means the last value overflowed its
    six-character field (e.g. ok049's LIN152A 1839, where '3035' left '5' past the
    column and only '303' was read) or some other stray content butts against the
    values -- either way something was written that the fixed-width read does not
    capture. Content that begins at the site-ID field (col 74+) is NOT flagged: it
    is the standard optional site ID and is common and legitimate.

    Returns a list of {series, year, in_column, unparsed, kind}. ``year`` is the
    year of the tenth (last) value field, where the overflow lands; ``kind`` is
    'truncated_value' when a digit runs contiguously across the boundary (a value
    was split) or 'unexpected_chars' otherwise."""
    findings = []
    for line in data_lines:
        if not _looks_like_data(line):
            continue
        # Same column arithmetic as _parse_fixed (incl. the bunched BC-year case).
        if len(line) >= 9 and line[7] == '-' and line[8].isdigit():
            idw, yrw = 7, 5
        else:
            idw, yrw = 8, 4
        boundary = idw + yrw + 60                 # first column after the 10 values
        if boundary >= len(line) or line[boundary].isspace():
            continue                               # separator column is blank -> fine
        sid, row_year, _vals = _parse_fixed(line)
        last_cell = line[idw + yrw + 54:boundary].strip()   # the 10th value field
        tail = line[boundary:].rstrip()
        contiguous_digit = (line[boundary - 1].isdigit() and line[boundary].isdigit())
        findings.append({"series": sid, "year": row_year + 9,
                         "in_column": last_cell, "unparsed": tail[:20],
                         "kind": "truncated_value" if contiguous_digit
                                 else "unexpected_chars"})
    return findings


def _warn_salvage_summary(basename, report):
    """One concise per-file warning summarising salvage actions, so a large batch
    stays legible. Full detail lives in df.attrs['dplpy_salvage']."""
    # A post-marker orphan drops only a mislabeled FRAGMENT, not the whole series, so
    # it is summarised separately from series that were dropped entirely.
    dropped = [r for r in report if r["action"] == "dropped"
               and r["issue"] != "post_marker_orphan"]
    orphans = [r for r in report if r["issue"] == "post_marker_orphan"]
    renamed = [r for r in report if r["action"].startswith("renamed")]
    parts = []
    if dropped:
        preview = "; ".join(r["series"] + ":" + r["issue"] for r in dropped[:5])
        parts.append("dropped " + str(len(dropped)) + " series (" + preview
                     + (" ..." if len(dropped) > 5 else "") + ")")
    if renamed:
        preview = "; ".join(r["action"] for r in renamed[:5])
        parts.append("renamed " + str(len(renamed)) + " (" + preview
                     + (" ..." if len(renamed) > 5 else "") + ")")
    if orphans:
        preview = "; ".join(r["series"] for r in orphans[:5])
        parts.append("dropped a post-marker fragment from " + str(len(orphans))
                     + " series (" + preview + (" ..." if len(orphans) > 5 else "") + ")")
    if parts:
        warnings.warn("Salvaged " + basename + ": " + "; ".join(parts))


def _looks_like_data(line):
    """True if the line parses as *fixed-width* Tucson data: an ID, an integer
    year, and a numeric first measurement in the fixed value columns (13 on).

    Classification is fixed-position ONLY -- we never fall back to whitespace
    tokenising here. A genuine data row is fixed-width, so its measurements live
    in the value columns; a header/metadata line has text there (a site name,
    species, investigator), or nothing, even when a stray number sits in the
    decade column (a street address, a distance -- e.g. '50km   1 54 km from
    Ust...'). Whitespace tokenising used to turn that header line into a phantom
    series ('50km', year 1, value 54); reading the value region by fixed position
    instead keeps header lines out of the data. Trailing notes on a real data row
    are tolerated: _trim_trailing_junk removes them before the first value is seen.
    """
    if len(line) < 12:
        return False
    try:
        _sid, _yr, vals = _parse_fixed(line)
    except (ValueError, IndexError):
        return False
    for v in vals:
        vs = v.strip()
        if vs == "":
            continue                 # skip leading blank (missing) fields
        try:
            int(vs)
            return True              # first real measurement is numeric -> data
        except ValueError:
            return False             # first real field is text -> header/metadata
    return False


def _first_data_line_index(lines):
    """Index of the first line that looks like Tucson data rather than a header
    or metadata line -- used to skip a header of *any* length (1, 2, 3 or more
    lines) instead of assuming exactly three. Returns 0 if none looks like data
    (leave the lines untouched and let parsing report the problem)."""
    for i, ln in enumerate(lines):
        if _looks_like_data(ln):
            return i
    return 0


def _trim_trailing_junk(values):
    """Drop trailing tokens that are not measurements -- appended notes/comments
    and trailing blanks -- by keeping everything up to and including the last
    token that parses as an integer (a real value or a 999 / -9999 stop marker).
    Interior blank fields (missing rings written as blanks) are preserved as ""
    so they hold their year position; only *trailing* junk/blanks are removed."""
    last = -1
    for i, v in enumerate(values):
        vs = v.strip()
        if vs == "":
            continue
        try:
            int(vs)
            last = i
        except ValueError:
            continue
    return values[:last + 1]


def _parse_fixed(line):
    """Parse one line by fixed Tucson columns: (id, year, [value strings]).

    Interior blank 6-char fields are kept as "" so a missing ring written as
    blanks holds its year position (dropping it would shift the rest of the
    decade); trailing blanks/notes are trimmed by _trim_trailing_junk.

    A bunched negative (BC) year -- written with no space between the ID and the
    year's minus sign, e.g. 'MNP262M-1262' (= -1262) or '600610 -990' (= -990) --
    is detected per line by a '-' in column 8 followed by a digit, and read as a
    7-char ID + a 5-char year field (cols 8-12), the same handling dplR's `long`
    mode and read.tucson2 give the long-chronology case. Detecting it by width
    alone (a full 5-char year that fills column 12) missed 4-char BC years like
    '-990': the '-' then landed in the ID field ('600610 -') and the year read as
    +990, silently splitting the series. int() strips the trailing space, so a
    shorter year in the 5-char field (e.g. '-990 ') still parses correctly."""
    if len(line) >= 9 and line[7] == '-' and line[8].isdigit():
        idw, yrw = 7, 5                       # bunched BC year (any width)
    else:
        idw, yrw = 8, 4                        # standard 8-char id + 4-char year
    series_id = line[:idw].strip()
    year = int(line[idw:idw + yrw])          # may raise ValueError
    # The ITRDB decadal record holds exactly ten 6-char value fields (cols
    # 13-72); cols 74-78 are an optional site ID and anything further is junk.
    # Read only those ten fields so a nonstandard trailing column (e.g. a
    # per-row value count) or a joined next record does not inflate the value
    # count and force a fall back to whitespace parsing.
    rest = line[idw + yrw:idw + yrw + 60]
    values = [rest[i:i + 6].strip() for i in range(0, len(rest), 6)]
    values = _trim_trailing_junk(values)
    return series_id, year, values


def _parse_ws(line):
    """Parse one line by whitespace delimiting: (id, year, [value strings])."""
    tokens = line.split()
    if len(tokens) < 2:
        raise ValueError("too few fields")
    series_id = tokens[0]
    year = int(tokens[1])                    # may raise ValueError
    values = _trim_trailing_junk(tokens[2:])
    return series_id, year, values


def _parses_as_data(line):
    """True if ``line`` parses as a Tucson data row (an id, a plausible year, values).

    Used to tell a data row whose series ID contains '#' (e.g. 'SP#1', 'GFI48C#H')
    from a '#'-marked note/annotation line that does not (e.g. a CDendro line
    'BAZENA  #### corrC GT 0.7...'). The former is data; the latter is a comment.
    """
    for parser in (_parse_fixed, _parse_ws):
        try:
            _sid, yr, vals = parser(line)
        except (ValueError, IndexError):
            continue
        if -12000 <= yr <= 12000 and vals:
            return True
    return False


def _is_comment_line(line):
    """A comment is a line whose first non-blank character is '#', or any other
    '#'-bearing line that is not a valid data row (a '#'-marked note/annotation).

    A '#' inside a real series ID is data (the row parses), so a parseable row is
    never treated as a comment -- this keeps ITRDB series like 'SP#1' / 'GFI48C#H'
    while still dropping interspersed annotation rows like 'BAZENA  #### ...'.
    """
    if line.lstrip().startswith("#"):
        return True
    return "#" in line and not _parses_as_data(line)


def _parse_all(lines, method):
    """Parse every line with one method. Returns a list where each element is
    (id, year, values, lineno) or None if that line could not be parsed."""
    rows = []
    for k, line in enumerate(lines):
        if len(line.strip()) < 7:
            rows.append(None)
            continue
        try:
            if method == "fixed":
                sid, yr, vals = _parse_fixed(line)
            else:
                sid, yr, vals = _parse_ws(line)
            rows.append((sid, yr, vals, k))
        except (ValueError, IndexError):
            rows.append(None)
    return rows


def _rows_valid(rows):
    """dplR input.ok essence: reject a parse where any row carries more values
    than its decade allows (the tell-tale of a mis-tokenised line). One extra
    column is permitted for a trailing stop marker."""
    good = [r for r in rows if r is not None]
    if not good:
        return False
    for sid, yr, vals, k in good:
        full_per_row = 10 - (yr % 10)
        if len(vals) > full_per_row + 1:
            return False
    return True


def _block_year_values(rows, row_indices):
    """Map of {year: raw integer value} a block assigns -- used to tell a true
    duplicate (two blocks giving DIFFERENT values for the same year) from an
    identical copy-paste (same values, handled by dedup) or a disjoint segment.
    Blank fields, trailing stop markers, and negatives (which become NaN) are
    excluded so they do not create spurious conflicts."""
    yv = {}
    for i in row_indices:
        sid, yr, vals, k = rows[i]
        n = len(vals)
        for j in range(n):
            tok = vals[j].strip()
            if tok == "":
                continue
            if j == n - 1 and tok in ("999", "-9999"):
                continue
            try:
                v = int(tok)
            except ValueError:
                continue
            if v < 0:
                continue
            yv[yr + j] = v
    return yv


def _row_misaligned(r):
    """True if a fixed-width row's grid is broken: a value field that -- once
    stripped -- still holds an internal space (two values captured in one 6-char
    cell, e.g. az606's '6  142' / arge041's '1  065'), or a TAB in the ID or a
    value (a tab is one character where the layout needs space padding, so it
    shifts the year and every value after it, e.g. cana588 'moo07b<TAB>1'). Either
    way the fixed-width record is corrupt and cannot be trusted."""
    if r is None:
        return False
    if "\t" in r[0]:                       # a TAB inside the ID field -> shifted columns
        return True
    return any(("\t" in tok) or (" " in tok.strip()) for tok in r[2])


def _segment_blocks(rows):
    """Segment parsed rows into blocks, in file order, as {sid, rows:[indices]}.

    A new block starts when the series ID changes OR when the year fails to
    advance for the same ID (a backward -- or repeated -- year). Within one core
    the row years strictly increase (each row is the next decade), so a year that
    goes backward is the tell-tale of a SECOND block stacked under the same code
    with no separating line -- e.g. two cores mistakenly sharing an ID. Splitting
    on that reset (not just on an ID change) is what lets a back-to-back duplicate
    ID be recognised as a duplicate rather than mislabelled a self-overlap."""
    blocks = []
    cur = None
    for i, r in enumerate(rows):
        if r is None:
            continue
        sid, yr = r[0], r[1]
        if cur is not None and cur["sid"] == sid and yr > cur["last_year"]:
            cur["rows"].append(i)
            cur["last_year"] = yr
        else:
            if cur is not None:
                blocks.append(cur)
            cur = {"sid": sid, "rows": [i], "last_year": yr}
    if cur is not None:
        blocks.append(cur)
    return blocks


def _is_terminator_row(r, precision=None):
    """True if a parsed row ends with a Tucson stop marker -- the marker that
    terminates a series. ``-9999`` is always the 0.001 mm marker (it is never a real
    value). ``999`` terminates only a 0.01 mm series; in a 0.001 mm series ``999`` is
    a real 0.999 mm measurement, so without a known precision (or a 0.001 mm one) a
    trailing 999 is NOT treated as a terminator. Used to segment a file into
    terminator-delimited blocks, so a backward year AFTER a terminator (the same code
    reappearing as a second core) is told apart from a backward year WITHIN a block
    (one series with a row out of order -- a flipped or mistyped decade)."""
    if r is None or not r[2]:
        return False
    last = r[2][-1].strip()
    if last == "-9999":
        return True
    if last == "999":
        return precision is not None and precision.get(r[0]) == 100
    return False


def _terminated_blocks(rows, precision=None):
    """Segment parsed rows into blocks that each end at a stop-marker terminator (or
    where the ID changes), in file order, as [{sid, rows, min_year, max_year}].

    Unlike ``_segment_blocks`` (which splits on any backward year), a backward year
    *within* a block does NOT start a new block here -- so an out-of-order row (a
    flipped date: wy002's 283012, nm604's 101401) stays inside its single block,
    while the same ID reappearing AFTER its terminator (a second core stacked under
    one code: ut542's CC1-2, ut550's RCB183A) becomes a separate block. That is the
    distinction the duplicate-vs-flipped-date logic keys on. ``precision`` (sid ->
    100/1000) makes the terminator test exact for a trailing 999 (see
    ``_is_terminator_row``)."""
    blocks = []
    cur = None
    prev_term = False
    for i, r in enumerate(rows):
        if r is None:
            continue
        sid = r[0]
        if cur is None or cur["sid"] != sid or prev_term:
            if cur is not None:
                blocks.append(cur)
            cur = {"sid": sid, "rows": [i]}
        else:
            cur["rows"].append(i)
        prev_term = _is_terminator_row(r, precision)
    if cur is not None:
        blocks.append(cur)
    for b in blocks:
        yrs = [rows[ri][1] for ri in b["rows"]]
        b["min_year"], b["max_year"] = min(yrs), max(yrs)
    return blocks


def _disjoint_duplicate_ids(rows, present, precision=None):
    """IDs that appear as two or more terminator-delimited blocks whose years are
    disjoint (they do not share any year). These are the same code written as, or
    stacked from, separate blocks -- a series split into forward pieces (dplR's
    BT006) or two cores stacked under one code out of order (ut542 CC1-2, ut550
    RCB183A). Either way their years do not clash, so they merge into one series and
    are reported/warned about (not silently merged, and not mistaken for a
    flipped-date row within one block). An identical copy-paste over the same years
    (a dedup) or an overlapping conflict (raised in strict / renamed in salvage
    upstream) shares years, so it is excluded here. ``present`` limits the result to
    IDs that survived to the final frame."""
    by_sid = {}
    for b in _terminated_blocks(rows, precision):
        by_sid.setdefault(b["sid"], []).append(b)
    dup = set()
    for sid, bl in by_sid.items():
        if len(bl) < 2 or sid not in present:
            continue
        # Blocks must be disjoint in their actual data years. Blocks that share a
        # year are an identical copy-paste (dedup) or a conflict (handled upstream),
        # not a disjoint join, so they are not reported here.
        seen_years = set()
        disjoint = True
        for b in bl:
            ys = set(_block_year_values(rows, b["rows"]).keys())
            if seen_years & ys:
                disjoint = False
                break
            seen_years |= ys
        if disjoint:
            dup.add(sid)
    return dup


def _rename_overlapping_duplicates(rows):
    """Salvage helper. When a series ID appears in more than one block and those
    blocks actually share years (two cores sharing a code), rename the second and
    later blocks (ID2, ID3, ...) so both are kept as distinct series. A single ID
    split into disjoint segments (a gap, e.g. dplR's BT006 case) is left untouched
    so it still merges. Mutates and returns `rows`, plus a list of
    {series, issue, action, detail} records for the report."""
    # Blocks in file order (split on an ID change or a backward-year reset), as
    # lists of row indices.
    blocks = [{"sid": b["sid"], "rows": b["rows"]} for b in _segment_blocks(rows)]

    by_sid = {}
    for b in blocks:
        by_sid.setdefault(b["sid"], []).append(b)

    existing = set(by_sid.keys())
    records = []
    for sid, bl in by_sid.items():
        if len(bl) < 2:
            continue
        # A block is a true duplicate only if it gives a DIFFERENT value for a
        # year an earlier block already covered. Sharing years with identical
        # values is a copy-paste (dedup handles it); disjoint years is a
        # legitimately segmented series (merge). Only genuine conflicts rename.
        accum = {}
        rename_flags = []
        for b in bl:
            yv = _block_year_values(rows, b["rows"])
            conflict = any(y in accum and accum[y] != v for y, v in yv.items())
            rename_flags.append(conflict)
            if not conflict:
                for y, v in yv.items():
                    accum.setdefault(y, v)
        if not any(rename_flags):
            continue
        # A conflicting duplicate ID with a decade-misaligned (corrupt) block cannot
        # be rationally salvaged: its second block is not a real core but malformed
        # structure (e.g. an offset grid), and there is no telling which block is the
        # true series. Rather than rename a garbage block into a fabricated series,
        # drop the whole ID and record it. (Two valid, decade-aligned cores sharing a
        # code -- the ordinary duplicate -- are still renamed and kept, below.)
        misaligned = any(
            len(rows[ri][2]) > (10 - (rows[ri][1] % 10)) + 1
            for b in bl for ri in b["rows"]
        )
        if misaligned:
            for b in bl:
                for ri in b["rows"]:
                    rows[ri] = None
            records.append({"series": sid, "issue": "duplicate_id",
                            "action": "dropped",
                            "detail": "unsalvageable duplicate ID (a block is "
                                      "decade-misaligned)"})
            continue
        suffix = 2
        for b, needs_rename in zip(bl, rename_flags):
            if not needs_rename:
                continue  # keep the first (and any disjoint) block under the ID
            newid = sid + str(suffix)
            while newid in existing:
                suffix += 1
                newid = sid + str(suffix)
            existing.add(newid)
            for ri in b["rows"]:
                s, y, v, k = rows[ri]
                rows[ri] = (newid, y, v, k)
            records.append({"series": sid, "issue": "duplicate_id",
                            "action": "renamed to " + newid,
                            "detail": "overlapping duplicate block kept as " + newid})
            suffix += 1
    return rows, records


def _split_disjoint_duplicates(rows, precision, skip_sids):
    """join=False helper. Keep a series written as two or more DISJOINT same-ID
    terminated blocks as SEPARATE series (COFECHA's per-segment convention: e.g.
    ak200's CM82S 1651-1774 and 1800-1974 are two entries, not one). The first
    block keeps the original ID; each later block is renamed ID2, ID3, ... and given
    the same precision. Overlapping/conflicting duplicates and unterminated orphan
    fragments (``skip_sids``) are left to their own handling. Mutates ``rows`` and
    ``precision``; returns rename records for the report."""
    by_sid = {}
    for b in _terminated_blocks(rows, precision):
        by_sid.setdefault(b["sid"], []).append(b)
    existing = set(by_sid.keys())
    records = []
    for sid, bl in by_sid.items():
        if len(bl) < 2 or sid in skip_sids:
            continue
        # keep only blocks that actually carry data, and require them disjoint
        yvs = [(b, set(_block_year_values(rows, b["rows"]).keys())) for b in bl]
        yvs = [(b, ys) for b, ys in yvs if ys]
        if len(yvs) < 2:
            continue
        seen = set()
        disjoint = True
        for _b, ys in yvs:
            if seen & ys:
                disjoint = False
                break
            seen |= ys
        if not disjoint:
            continue                              # overlap/conflict -> handled elsewhere
        suffix = 2
        for b, _ys in yvs[1:]:                    # first block keeps the original ID
            newid = sid + str(suffix)
            while newid in existing:
                suffix += 1
                newid = sid + str(suffix)
            existing.add(newid)
            precision[newid] = precision.get(sid)
            for ri in b["rows"]:
                s, y, v, k = rows[ri]
                rows[ri] = (newid, y, v, k)
            records.append({"series": sid, "issue": "duplicate_id",
                            "action": "split to " + newid,
                            "detail": "same ID kept as a separate series " + newid
                                      + " (join=False)"})
            suffix += 1
    return records


def _looks_like_record(s):
    """True if ``s`` begins a Tucson data record: an ID, a plausible year, a value."""
    toks = s.split()
    if len(toks) < 3:
        return False
    try:
        yr = int(toks[1])
    except ValueError:
        return False
    return -12000 <= yr <= 12000


def _split_joined_records(line, _depth=0):
    """Split a line where a stop marker is butted directly against a new core ID.

    A missing line break in the file can join one series' terminal row to the
    next series' first row, e.g. ``...   999FR-002  1660  ...``. Left alone this
    collapses into a mis-tokenised row (the values of the second record land on
    the first, inventing impossible years). We split at a stop marker (999 or
    -9999) that sits at a field boundary (not inside a value) and is immediately
    followed by a letter, but only when the remainder actually parses as a fresh
    record -- so a normal trailing site ID or note is left untouched. Returns a
    list of one or more lines.

    The stop marker must fall in the value region (column 12 onward): a '999'
    inside a series ID (e.g. 'S999A') is not a stop marker, and splitting there
    would wreck a perfectly good row (aus118/aus123's S999* cores).
    """
    if _depth >= 50:
        return [line]
    for m in re.finditer(r"(?<!\d)(?:999|-9999)(?=[A-Za-z])", line):
        if m.start() < 12:                    # in the id/decade field, not a stop marker
            continue
        cut = m.end()
        tail = line[cut:]
        if _looks_like_record(tail):
            return [line[:cut]] + _split_joined_records(tail, _depth + 1)
    return [line]


def read_rwl(lines, strict=True, join=True):
    """Parse cleaned Tucson data lines into (rwl_data, precision, order, report).

    rwl_data  : {series_id: {year: raw_integer_value}}
    precision : {series_id: 100 or 1000}   (divisor to convert to mm)
    order     : [series_id, ...]           (first-appearance order)
    report    : [{series, issue, action, detail}, ...]  (salvage actions taken)

    Uses a fixed-width parse first (the Tucson "standard"), falling back to a
    whitespace-delimited parse when the fixed one fails validation -- exactly
    the strategy dplR uses to cope with long IDs, negative years, etc. Returns
    ``None`` if nothing usable could be parsed.

    strict=False enables salvage mode: instead of raising on an unrecoverable
    per-series problem, a self-overlap or precision-shift series is dropped and a
    duplicate-ID's later block(s) are renamed and kept, each recorded in report.

    join=True (the default, matching dplR) merges a series written as two or more
    disjoint same-ID blocks into one series. join=False keeps them as SEPARATE
    series -- the 2nd+ terminated block renamed to a unique ID -- which is what a
    per-segment QA (COFECHA-style crossdating) wants.
    """
    salvage = not strict
    report = []

    # Repair joined records: a missing line break that butts a stop marker
    # against the next series' ID (e.g. '...999FR-002  1660...') is split so both
    # records parse independently instead of collapsing into a mis-tokenised line.
    repaired = []
    n_joined = 0
    joined_example = None
    for ln in lines:
        parts = _split_joined_records(ln)
        if len(parts) > 1 and joined_example is None:
            joined_example = ln.strip()[:60]
        n_joined += len(parts) - 1
        repaired.extend(parts)
    if n_joined and not salvage:
        raise ValueError(
            "Cannot read file -- " + str(n_joined) + " missing line break(s): a stop "
            "marker runs into the next series ID (e.g. '" + str(joined_example) + "').")
    if n_joined:
        warnings.warn(str(n_joined) + " missing line break(s) split (a stop marker ran "
                      "into the next series ID)")
    lines = repaired

    fixed_rows = _parse_all(lines, "fixed")
    # Rows carrying more values than fit before their next decade boundary. In a
    # FIXED parse (a rigid 6-char grid that cannot merge columns) this is never a
    # tokenisation failure -- it means a decade-MISALIGNED row: an offset duplicate
    # block, or a mistyped start year. We keep the list so the accurate downstream
    # guards (duplicate/overlap, then the decade guard) can name the real problem,
    # instead of mislabelling it a fixed-width/column failure the way it reads.
    decade_overrun = [r for r in fixed_rows if r is not None
                      and len(r[2]) > (10 - (r[1] % 10)) + 1]
    if _rows_valid(fixed_rows):
        rows = fixed_rows
    elif not salvage:
        # Clean grid, just decade-misaligned: accept the fixed parse and let the
        # duplicate/overlap analysis and the decade guard below produce the precise
        # error. (A genuinely broken grid -- an embedded space / TAB -- is caught
        # by the misalignment guard just below and reported as such.)
        rows = fixed_rows
    else:
        # Salvage. If the fixed grid is clean (only decade-misaligned), keep it so
        # the duplicate renamer can split an offset stacked block; only a broken
        # grid falls back to a whitespace re-parse.
        grid_clean = not any(_row_misaligned(r) for r in fixed_rows)
        if grid_clean:
            rows = fixed_rows
        else:
            ws_rows = _parse_all(lines, "ws")
            if _rows_valid(ws_rows):
                warnings.warn("fixed-width parse failed; re-read with variable (whitespace) columns")
                rows = ws_rows
            else:
                # Neither validated cleanly. Keep the parse that recovered the most
                # rows so a single malformed file still yields as much data as
                # possible, and tell the user the read may be incomplete.
                n_fixed = sum(1 for r in fixed_rows if r is not None)
                n_ws = sum(1 for r in ws_rows if r is not None)
                if max(n_fixed, n_ws) == 0:
                    return None
                warnings.warn("file has formatting problems; read may be incomplete")
                rows = fixed_rows if n_fixed >= n_ws else ws_rows

    n_bad = sum(1 for r in rows if r is None)
    if n_bad:
        warnings.warn(str(n_bad) + " line(s) could not be parsed and were skipped")

    # Column-misalignment guard (fixed-width). A value field that -- once stripped
    # -- still contains an internal space means the decadal 6-char grid captured
    # parts of two values: a shifted column (e.g. az606's '6  142', where 126 was
    # truncated to 12 and 142 mis-captured) or a value written with embedded spaces
    # (arge041's '1  065' = 1065). Either way the fixed-width record is corrupt and
    # cannot be trusted. In a fixed-width format this is severe, so strict mode
    # refuses the whole file; salvage NaNs the whole offending row (once the grid
    # shifts, everything after the shift point is suspect) and keeps going. Checked
    # BEFORE the overlap/duplicate analysis so it is reported as misalignment, not
    # mislabelled as an overlap (which is how az606 used to fail).
    # A row is misaligned if a value field, once stripped, still holds an internal
    # space (two values captured in one 6-char cell -- az606/arge041), or if the ID
    # or any value contains a TAB. A tab is a single character where the layout
    # needs space padding, so it shifts the year and every value after it one column
    # left; when it lands in the ID field the parsed ID keeps the tab (e.g. cana588
    # 'moo07b<TAB>1', which then reads year 800 instead of 1800). Both mean the
    # fixed-width grid is broken and the row cannot be trusted. (_row_misaligned is
    # a module-level helper so the parse gate above can use it too.)
    misaligned = [r for r in rows if _row_misaligned(r)]
    if misaligned:
        def _bad_detail(r):
            sid, yr = r[0], r[1]
            if "\t" in sid:
                return "series '%s' at year %d (a TAB in the ID field)" % (
                    sid.replace("\t", "<TAB>"), yr)
            tok = next(t for t in r[2] if ("\t" in t) or (" " in t.strip()))
            return "series '%s' at year %d (field '%s')" % (
                sid, yr, tok.strip().replace("\t", "<TAB>"))
        ex = "; ".join(_bad_detail(r) for r in misaligned[:3])
        more = " ..." if len(misaligned) > 3 else ""
        if not salvage:
            raise ValueError(
                "Cannot read file -- misaligned fixed-width columns (an embedded space or "
                "TAB in a field): " + ex + more + " (<TAB> marks a tab).")
        # salvage: NaN the whole misaligned row(s); record once per affected series
        seen = set()
        for r in misaligned:
            if r[0] not in seen:
                seen.add(r[0])
                report.append({"series": r[0], "issue": "column_misalignment",
                               "action": "misaligned row(s) set to NaN",
                               "detail": "a fixed-width field held an embedded space or TAB"})
        rows = [None if _row_misaligned(r) else r for r in rows]
        warnings.warn(str(len(misaligned)) + " misaligned row(s) (embedded space/TAB) "
                      "set to NaN: " + ex + more)

    # Salvage: rename the later block(s) of any duplicate series ID whose blocks
    # overlap in time (two cores sharing a code) so both are kept as distinct
    # series. A single ID split into disjoint segments is left to merge, as in
    # strict mode. Done before block/precision analysis so renamed blocks are
    # treated as independent series downstream.
    if salvage:
        rows, rename_recs = _rename_overlapping_duplicates(rows)
        report.extend(rename_recs)

    # Two per-series block counts, used for two different jobs:
    #
    #  * block_count -- segments split on an ID change OR a backward-year reset.
    #    Used only to tell a genuine duplicate ID (two blocks of the same code that
    #    OVERLAP, e.g. a stacked offset duplicate) from a single series that
    #    overlaps *itself* because one row is malformed. It is consulted only where
    #    an overlap has already been found, so a backward reset there means a
    #    second core, not a misplaced row.
    #
    #  * appearances -- maximal CONTIGUOUS runs of an ID (split on ID change only).
    #    Used for the "combined" report of disjoint duplicate blocks that were
    #    merged. A single series with a row written out of order (a backward jump
    #    WITHIN one contiguous run -- e.g. wy002's 283012, nm604's 101401) is still
    #    one appearance, so it is NOT mislabelled a merged duplicate; only an ID
    #    that truly recurs in a separate place in the file (>1 run) is reported.
    block_count = {}
    for b in _segment_blocks(rows):
        block_count[b["sid"]] = block_count.get(b["sid"], 0) + 1
    appearances = {}
    prev = None
    for r in rows:
        if r is None:
            continue
        sid = r[0]
        if sid != prev:
            appearances[sid] = appearances.get(sid, 0) + 1
            prev = sid

    # Determine each series' measurement precision from its TERMINATOR -- the stop
    # marker (999 for 0.01 mm, -9999 for 0.001 mm) that ends a block -- exactly as dplR
    # does (a mid-series 999 in a 0.001 mm series stays a real 0.999 mm value).
    #
    # We work per contiguous block (a new block begins at a backward year), because a
    # marker can be followed by more tokens under the same ID:
    #   * missing padding -- blanks or a -999 "absent" code (brit020's 568112: 999 at
    #     1907 then -999 to 1919). Reading the literal last token would miss the 999,
    #     mark the series "no stop marker", and -- precision then unknown in the value
    #     pass -- read the 999 as a bogus 9.99 mm value. So the terminator is the
    #     block's last NON-padding token; padding after it is dropped.
    #   * a whole further block. If that block is itself terminated it is a stacked
    #     duplicate (merged by the disjoint-duplicate logic below). If it is
    #     UNTERMINATED it is an orphan -- a mislabeled/misplaced fragment (roma009's
    #     f1-03, whose trailing 1847 line is really f1-03b's) -- and is dropped (strict
    #     refuses the file); it must NOT be merged into the terminated series.
    # A series' precision comes from its FIRST terminated block.
    def _is_trailing_pad(tok):
        # A missing/absent cell that may legitimately follow a stop marker: a blank,
        # or a negative code that is not the -9999 (0.001 mm) marker itself.
        if tok == "":
            return True
        try:
            return int(tok) < 0 and tok != "-9999"
        except ValueError:
            return False

    def _block_cells(b):                 # (row_index, token_index, stripped token)
        for ri in b["rows"]:
            toks = rows[ri][2]
            for j in range(len(toks)):
                yield ri, j, toks[j].strip()

    blocks_by_sid = {}
    for b in _segment_blocks(rows):
        blocks_by_sid.setdefault(b["sid"], []).append(b)

    precision = {}
    drop_cells = set()  # (row_index, token_index) to skip: post-marker padding + orphans
    post_marker = {}    # sid -> count of dropped post-marker padding values (brit020)
    orphan_year = {}    # sid -> first year of a dropped unterminated post-marker block
    for sid, bl in blocks_by_sid.items():
        seen_terminator = False
        for b in bl:
            mri = mj = None                      # position of this block's terminator
            term = ""
            for ri, j, s in _block_cells(b):     # terminator = last non-padding token
                if not _is_trailing_pad(s):
                    mri, mj, term = ri, j, s
            if term in ("999", "-9999"):
                if sid not in precision:         # precision from the FIRST terminated block
                    precision[sid] = 100 if term == "999" else 1000
                after = False                    # drop padding AFTER the marker (in file order)
                for ri, j, s in _block_cells(b):
                    if after:
                        drop_cells.add((ri, j))
                        if s != "":
                            post_marker[sid] = post_marker.get(sid, 0) + 1
                    if ri == mri and j == mj:
                        after = True
                seen_terminator = True
            elif seen_terminator:
                # An unterminated block after a terminator: an orphan fragment. Drop
                # every cell so it is not merged into the (already ended) series.
                for ri, j, s in _block_cells(b):
                    drop_cells.add((ri, j))
                orphan_year.setdefault(sid, int(rows[b["rows"][0]][1]))
        # otherwise unknown -> resolved by the dominant-precision fallback below

    # Data after a series' stop marker (an orphan block). Strict refuses the file;
    # salvage drops the fragment (already excluded via drop_cells) and records it.
    if orphan_year:
        if not salvage:
            ex = "; ".join("series '%s' at year %d" % (s, y)
                           for s, y in list(orphan_year.items())[:3])
            more = " ..." if len(orphan_year) > 3 else ""
            raise ValueError(
                "Cannot read file -- data after the stop marker: " + ex + more
                + ". A block under an existing series ID appears after that series' "
                "stop marker (likely a mislabeled series ID)."
            )
        for sid, y in orphan_year.items():
            report.append({"series": sid, "issue": "post_marker_orphan",
                           "action": "dropped",
                           "detail": "block beginning " + str(y) + " after the stop "
                                     "marker dropped (likely a mislabeled series ID)"})

    # join=False: keep same-ID disjoint blocks as separate series (rename the 2nd+),
    # rather than merging them. Done here -- after precision is known (terminated-block
    # detection needs it) and orphans are identified (which are skipped) -- so the
    # accumulation below treats the renamed blocks as independent series.
    split_sids = set()      # originals split into separate series (not combined)
    if not join:
        split_records = _split_disjoint_duplicates(rows, precision, set(orphan_year))
        report.extend(split_records)
        split_sids = {r["series"] for r in split_records}

    rwl_data = {}
    order = []
    neg_hits = []       # (series, year) for anomalous negatives -> NaN
    nonint_cells = []   # (series, year, token) for non-integer tokens -> NaN
    identical_dups = 0  # cells duplicated with an identical value (copy-paste)
    year_src = {}       # sid -> {year: start-year of the row that wrote it}
    overlaps = []       # (sid, year, first_row_start, second_row_start)
    overlap_seen = set()
    prec_shift = []     # (sid, year) where a 0.01 mm series carries a stray -9999
    drop_series = set() # series to drop in salvage mode

    for ri, r in enumerate(rows):
        if r is None:
            continue
        sid, yr, vals, k = r
        if sid not in rwl_data:
            rwl_data[sid] = {}
            year_src[sid] = {}
            order.append(sid)
        prec = precision.get(sid)
        for j, tok in enumerate(vals):
            if (ri, j) in drop_cells:
                continue             # post-marker padding or orphan block (dropped above)
            s = tok.strip()
            y = yr + j
            if s == "":
                continue             # interior blank field = missing ring (holds its year)
            if s == "-9999":
                # -9999 is only ever the 0.001 mm stop marker. In a 0.001 mm
                # series it is a marker -> drop. In a series terminated at
                # 0.01 mm it signals a measurement-precision shift (e.g. an early
                # 0.001 mm segment inside a 0.01 mm series): record to fail below.
                if prec == 100:
                    prec_shift.append((sid, y))
                continue
            if s == "999":
                if prec == 100:
                    continue             # 0.01 mm stop marker (dplR nulls all 999 here)
                # 0.001 mm (or unknown): 999 is a real 0.999 mm value -> keep it
            try:
                v = int(s)
            except ValueError:
                nonint_cells.append((sid, y, s))   # non-integer token -> NaN
                continue
            if v < 0:
                # Anomalous negative (not a stop marker): treat as missing.
                neg_hits.append((sid, y))
                continue
            if y in rwl_data[sid]:
                # A value is already present for this (series, year). If it is
                # identical it's a harmless duplicate -- a copy-paste of a row or
                # of the whole file -- so ignore it. If it differs, the data
                # genuinely conflicts: record it and refuse the file below.
                if v == rwl_data[sid][y]:
                    identical_dups += 1
                elif sid not in overlap_seen:
                    overlaps.append((sid, y, year_src[sid].get(y), yr))
                    overlap_seen.add(sid)
                continue
            rwl_data[sid][y] = v
            year_src[sid][y] = yr

    # Fail loudly on overlapping data. Silently merging or overwriting would
    # corrupt the series, so -- like dplR -- we refuse the file; unlike dplR we
    # say *which* kind of problem it is and point at the offending row.
    if overlaps and salvage:
        # In salvage mode the duplicate-ID overlaps were already resolved by the
        # rename pre-pass, so anything left is a series overlapping itself (a
        # malformed row). Drop those series and record it.
        for sid, y, first_start, second_start in overlaps:
            drop_series.add(sid)
            report.append({"series": sid, "issue": "self_overlap",
                           "action": "dropped",
                           "detail": "overlaps itself at year " + str(y)})
    elif overlaps:
        problems = []
        for sid, y, first_start, second_start in overlaps:
            if block_count.get(sid, 1) > 1:
                # Same ID in two separate blocks: a genuine duplicate series ID.
                problems.append(
                    "Duplicate series ID '" + str(sid) + "' (two blocks overlap at year "
                    + str(y) + ") -- rename or remove the duplicate."
                )
            else:
                # One contiguous block that runs into itself: a malformed row.
                allowed = 10 - (first_start % 10) if first_start is not None else None
                next_dec = first_start - (first_start % 10) + 10 if first_start is not None else None
                if allowed is not None:
                    problems.append(
                        "Series '" + str(sid) + "' overlaps itself at year " + str(y)
                        + ": the row beginning " + str(first_start) + " has one value too "
                        "many (only " + str(allowed) + " fit before " + str(next_dec)
                        + ") -- a misplaced value or mistyped start year."
                    )
                else:
                    problems.append(
                        "Series '" + str(sid) + "' overlaps itself at year " + str(y)
                        + " (a misplaced value or mistyped start year)."
                    )
        raise ValueError(
            "Cannot read file -- overlapping data:\n  " + "\n  ".join(problems)
        )

    # Decade-alignment guard. A row carrying more values than fit before its next
    # decade boundary is malformed Tucson (dplR: "rows have too many values"). If
    # such a row created a duplicate/self overlap, that more specific error was
    # already raised (or the series dropped) above; anything still here is a
    # genuinely mis-decaded row with no overlap to key on (most often a mistyped
    # start year, or a stray extra value). The columns parse fine; the fault is the
    # decade/year. Strict rejects the file; salvage drops the whole affected
    # series and informs -- a decade-misaligned row is corrupt structure, not
    # something to place at guessed years.
    if decade_overrun:
        if not salvage:
            ex = "; ".join("series '%s' at year %d" % (r[0], r[1])
                           for r in decade_overrun[:3])
            more = " ..." if len(decade_overrun) > 3 else ""
            raise ValueError(
                "Cannot read file -- row(s) with too many values or mistyped start "
                "year: " + ex + more + "."
            )
        # Salvage: drop each affected series (skip any already dropped/renamed as a
        # duplicate, or dropped as a self-overlap) and record it so the drop is not
        # silent.
        for sid in dict.fromkeys(r[0] for r in decade_overrun):
            if sid in rwl_data and sid not in drop_series:
                drop_series.add(sid)
                yy = min(r[1] for r in decade_overrun if r[0] == sid)
                report.append({"series": sid, "issue": "too_many_values",
                               "action": "dropped",
                               "detail": "row with too many values / mistyped start "
                                         "year near " + str(yy)})

    # Fail on a measurement-precision shift within a single series (a 0.01 mm
    # series that also carries a -9999). Reading such a series at one precision
    # makes part of it 10x wrong, so -- in normal mode -- we refuse and name the
    # series. (Salvage mode will instead drop the affected series and continue.)
    if prec_shift:
        affected = []
        for sid, y in prec_shift:
            if sid not in affected:
                affected.append(sid)
        if salvage:
            for sid in affected:
                drop_series.add(sid)
                yy = min(y for s, y in prec_shift if s == sid)
                report.append({"series": sid, "issue": "precision_shift",
                               "action": "dropped",
                               "detail": "stray -9999 near year " + str(yy)})
        else:
            where = ", ".join(str(sid) for sid in affected)
            raise ValueError(
                "Cannot read file -- mixed precision: series: " + where + "."
            )

    # Resolve precision for any series that never showed a stop marker. Precision
    # is encoded by the terminator (999 => 0.01 mm, -9999 => 0.001 mm), so a
    # series missing its terminator has no precision of its own. The safety net:
    # if OTHER series in the file are terminated, adopt the file's dominant
    # precision for the missing one(s) and warn -- a safe inference, since a file
    # is measured at one precision but for rare mixed-precision cases. Only when
    # NO series in the whole file has a terminator is precision truly
    # undeterminable; strict then refuses (naming the series) rather than guess.
    #
    # Before that fallback, catch the specific case that motivated it here: a core
    # whose ID CASE flipped mid-series (e.g. 'FDD08A' then 'FDD08a'). On their own,
    # case-variant IDs are separate series (and are flagged; see readers()). But
    # when their years are DISJOINT *and* at least one block has no stop marker,
    # that combination is a strong sign the case flip split ONE core in two -- the
    # unterminated block simply ran on into the case-flipped continuation. Under
    # join=True (the default) merge them into the first-seen ID, inheriting the
    # terminated block's precision, exactly as disjoint same-ID blocks are joined.
    # (join=False leaves them separate, like other disjoint splits; and if every
    # block is already terminated we do NOT merge -- they may be distinct cores.)
    case_merged = []
    if join:
        lower_groups = {}
        for sid in order:
            lower_groups.setdefault(sid.lower(), []).append(sid)
        for low, sids in lower_groups.items():
            if len(sids) < 2:
                continue                     # ID case already consistent
            yearsets = [set(rwl_data.get(s, {})) for s in sids]
            disjoint = all(not (yearsets[a] & yearsets[b])
                           for a in range(len(sids))
                           for b in range(a + 1, len(sids)))
            terminated = [s for s in sids if s in precision]
            # require disjoint years, a missing terminator, and a precision source
            if not disjoint or all(s in precision for s in sids) or not terminated:
                continue
            canonical = sids[0]              # first-seen (earliest in `order`)
            merged_years = {}
            for s in sids:
                merged_years.update(rwl_data.get(s, {}))
            rwl_data[canonical] = merged_years
            precision[canonical] = precision[terminated[0]]
            for s in sids:
                if s != canonical:
                    rwl_data.pop(s, None)
                    precision.pop(s, None)
            order = [s for s in order if s == canonical or s not in sids]
            case_merged.append({"canonical": canonical, "ids": list(sids),
                                "n_blocks": len(sids),
                                "first_year": int(min(merged_years)),
                                "last_year": int(max(merged_years))})
            if salvage:
                report.append({"series": canonical, "issue": "case_variant_id",
                               "action": "merged",
                               "detail": "case-variant IDs " + " / ".join(sids)
                                         + " with a missing stop marker and no "
                                           "overlapping years joined into one series "
                                           "(likely one core split by a case change)"})
            else:
                warnings.warn(
                    "case-variant IDs " + " / ".join(sids) + " (differing only in "
                    "letter case, with a missing stop marker and no overlapping "
                    "years) merged into '" + canonical + "' -- likely one core split "
                    "by a case change. Pass join=False to keep them separate.")

    known = list(precision.values())
    missing = [sid for sid in order if sid not in precision]
    if missing and not known and not salvage:
        raise ValueError(
            "Cannot read file -- no stop marker (999/-9999) and precision is unknown.")
    if known:
        dominant = Counter(known).most_common(1)[0][0]
    else:
        dominant = 1000
        warnings.warn("no stop markers found in file; assuming 0.001 mm precision")
    for sid in missing:
        precision[sid] = dominant
        warnings.warn(
            "series '" + str(sid) + "': no stop marker; assuming the file's dominant "
            + ("0.01" if dominant == 100 else "0.001") + " mm precision."
        )

    if identical_dups:
        warnings.warn(
            str(identical_dups) + " identical duplicate value(s) ignored (looks copy-pasted)"
        )

    if nonint_cells:
        # A measurement field that is not a whole number is a format violation (the
        # series ID aside). Embedded-space tokens were already caught by the
        # misalignment guard; anything left here is a genuinely non-numeric cell.
        ex = "; ".join(str(sid) + "@" + str(y) + " '" + tok.strip() + "'"
                       for sid, y, tok in nonint_cells[:3])
        more = " ..." if len(nonint_cells) > 3 else ""
        if not salvage:
            raise ValueError(
                "Cannot read file -- " + str(len(nonint_cells)) + " non-integer "
                "measurement value(s): " + ex + more + ".")
        warnings.warn(str(len(nonint_cells)) + " non-integer value(s) could not be read "
                      "and were set to NaN: " + ex + more)

    if neg_hits:
        preview = ", ".join(str(sid) + "@" + str(yr) for sid, yr in neg_hits[:5])
        more = "" if len(neg_hits) <= 5 else " ..."
        warnings.warn(
            str(len(neg_hits)) + " anomalous negative value(s) (not the -9999 stop "
            "marker) were set to NaN [" + preview + more + "]"
        )

    # Values written after a series' stop marker are not data (the marker ends the
    # series); they are ignored. Note it once -- an unusual file structure worth
    # surfacing in a sweep -- rather than mislabelling the padding as measurements.
    if post_marker:
        survivors = {s: n for s, n in post_marker.items() if s in rwl_data}
        if survivors:
            if len(survivors) == 1:
                sid, n = next(iter(survivors.items()))
                warnings.warn("Series " + str(sid) + " had " + str(n) + " value(s) "
                              "after its stop marker (ignored).")
            else:
                ids = ", ".join(str(s) for s in survivors)
                warnings.warn(str(len(survivors)) + " series had value(s) after their "
                              "stop marker (ignored): " + ids + ".")

    # Drop salvage-flagged series (self-overlap / precision-shift), then any
    # series that ended up with no usable data at all.
    if drop_series:
        order = [sid for sid in order if sid not in drop_series]
    order = [sid for sid in order if len(rwl_data.get(sid, {})) > 0]
    rwl_data = {sid: rwl_data[sid] for sid in order}
    if len(order) == 0:
        return None

    dropped = len(nonint_cells) + len(neg_hits)   # values the file had but couldn't be used

    # Duplicate IDs written as two or more terminator-delimited blocks with disjoint
    # years -- a series split into forward pieces (dplR's BT006) or two cores stacked
    # under one code out of order (ut542 CC1-2, ut550 RCB183A). Their years do not
    # overlap (a conflict would have raised in strict / been renamed in salvage
    # above), so they are joined into one series. This is reported (never a silent
    # merge) and, in strict mode, warned about; it is not mistaken for a flipped-date
    # row (which is a backward year WITHIN one block, handled below).
    dup_joined = _disjoint_duplicate_ids(rows, set(order), precision)
    dup_joined -= set(orphan_year)   # an orphan fragment was dropped, not joined
    tblock_count = {}
    if dup_joined:
        for b in _terminated_blocks(rows, precision):
            tblock_count[b["sid"]] = tblock_count.get(b["sid"], 0) + 1

    # Combined series: a duplicate ID merged into one series because its blocks do
    # not conflict -- either a genuine re-appearance elsewhere in the file (more
    # than one contiguous run) or the disjoint duplicate blocks just described.
    # (In strict mode a conflicting duplicate would already have raised above; in
    # salvage mode a conflicting block was renamed.) A single series with a row
    # written out of order is one contiguous, in-place run, so it is not reported.
    # Reported on a successful read so a real merge is not silent.
    combined = []
    for sid in order:
        if not rwl_data.get(sid):
            continue
        if sid in split_sids:
            continue        # join=False: these blocks were split into separate
                            # series (recorded in the salvage report), not combined
        is_dup_joined = sid in dup_joined
        if appearances.get(sid, 1) >= 2 or is_dup_joined:
            n = tblock_count.get(sid, 1) if is_dup_joined else appearances.get(sid, 1)
            yrs = rwl_data[sid].keys()
            combined.append({"series": sid, "n_blocks": n,
                             "first_year": int(min(yrs)), "last_year": int(max(yrs))})

    # Surface the disjoint-duplicate join: strict warns; salvage records it in the
    # report (its standard channel). Kept about as terse as the out-of-order warning.
    if dup_joined:
        dj = [s for s in order if s in dup_joined]
        if salvage:
            for sid in dj:
                report.append({"series": sid, "issue": "duplicate_id", "action": "joined",
                               "detail": "same ID in " + str(tblock_count.get(sid, 2))
                                         + " separate blocks with no overlapping years, "
                                           "joined into one series"})
        else:
            ids = ", ".join(str(s) for s in dj)
            if len(dj) == 1:
                warnings.warn("Series " + ids + " had a duplicate ID in separate blocks "
                              "with no overlapping years (joined into one series).")
            else:
                warnings.warn(str(len(dj)) + " series had a duplicate ID in separate "
                              "blocks with no overlapping years (joined into one series "
                              "each): " + ids + ".")

    # Out-of-order rows: a surviving series whose row years step backward in file
    # order (a decade written before an earlier one -- wy002's 283012, nm604's
    # 101401). The data still reads correctly (rows are placed by year), but the
    # file was untidy, so warn once per series. Series explained as combined or as
    # a joined duplicate are skipped (their reappearance, not a misplaced row within
    # one block, is the cause).
    combined_ids = {c["series"] for c in combined}
    out_of_order = []
    max_year_seen = {}
    for r in rows:
        if r is None:
            continue
        sid, yr = r[0], r[1]
        if sid in max_year_seen and yr < max_year_seen[sid] and sid not in out_of_order:
            out_of_order.append(sid)
        max_year_seen[sid] = max(max_year_seen.get(sid, yr), yr)
    out_of_order = [s for s in out_of_order
                    if s in rwl_data and s not in combined_ids and s not in dup_joined
                    and s not in orphan_year]   # an orphan's backward jump was the dropped fragment
    if out_of_order:
        if len(out_of_order) == 1:
            warnings.warn("Series " + str(out_of_order[0]) + " had rows out of year "
                          "order (read correctly by placing each row at its year).")
        else:
            warnings.warn(str(len(out_of_order)) + " series had rows out of year order "
                          "(read correctly by placing each row at its year): "
                          + ", ".join(str(s) for s in out_of_order))

    return rwl_data, precision, order, report, dropped, combined, case_merged
