import dplpy as dpl
import pandas as pd
import numpy as np
import pytest
import io
import warnings
from unittest.mock import patch, Mock
import importlib
_readers_mod = importlib.import_module("dplpy.readers")

'''
    An unrecognized suffix is no longer rejected outright -- the content is
    sniffed. A file whose format can't be inferred from suffix OR content raises
    a clear error telling the user to pass format=.
'''
def test_unknown_format_raises_helpful_error(tmp_path):
    p = tmp_path / "mystery.dat"
    p.write_text("this is not ring-width data\njust some prose here\n")
    with pytest.raises(ValueError) as e:
        dpl.readers(str(p))
    assert "format" in str(e.value).lower()


def test_bad_format_argument_raises():
    with pytest.raises(ValueError):
        dpl.readers("tests/data/rwl/ca533.rwl", format="bogus")


'''
    Mocks output of pd.read_csv to return appropriate dataframe only if the
    parameter used is the expected file name.
'''
def mock_read_csv_output(file_path, skiprows=0, encoding=None):
    if file_path == "correct_file.csv":
        return pd.DataFrame(data={"SeriesA": [0.1, 0.3, 0.5, 0.7],
                                  "SeriesB": [0.2, 0.4, 0.6, 0.8],
                                  "Year": [1, 2, 3, 4]})
    return None

'''
    Mocks dplpy.readers._read_text, the single seam the reader now uses to read a
    file's text (binary read + encoding resolution). Returns (text, encoding,
    assumed), matching the real helper, so the parser downstream is unchanged.
'''
_MOCK_RWL_TEXT = {
    "valid_rwl_correct_format.rwl": (
        "SeriesA 1       10    30    50    70   999\n"
        "SeriesB 1      200   400   600   800 -9999\n"),
    "valid_rwl_with_headers.rwl": (
        "Header line 1\n"
        "Header line 2\n"
        "Header line 3\n"
        "SeriesA 1       10    30    50    70   999\n"
        "SeriesB 1      200   400   600   800 -9999\n"),
    "valid_rwl_with_blanks.rwl": (
        "SeriesA 1       10    30    50    70   999\n"
        "                                          \n"
        "SeriesB 1      200   400   600   800 -9999\n"),
}

def mock_read_text_output(file_path, encoding=None):
    if file_path in _MOCK_RWL_TEXT:
        return _MOCK_RWL_TEXT[file_path], "utf-8", False
    raise OSError("File not found")

'''
    Given input file.csv, test that readers produces the expected dataframe.
'''
@patch('pandas.read_csv')
def test_correct_csv_format(mock_read_csv: Mock):
    mock_read_csv.side_effect = mock_read_csv_output
    results = dpl.readers("correct_file.csv")
    mock_read_csv.assert_called_once_with("correct_file.csv", skiprows=0, encoding=None)

    expected_df = pd.DataFrame(data={"SeriesA": [0.1, 0.3, 0.5, 0.7], 
                                     "SeriesB": [0.2, 0.4, 0.6, 0.8]}, 
                                     index=pd.Index(data=[1, 2, 3, 4], 
                                                    name="Year")
                                    )
    pd.testing.assert_frame_equal(results, expected_df)

'''
    Given input file valid_rwl_correct_format.rwl, test that readers produces
    the expected dataframe.
'''
@patch.object(_readers_mod, '_read_text')
def test_correct_rwl_format(mock_open: Mock):
    mock_open.side_effect = mock_read_text_output

    results = dpl.readers("valid_rwl_correct_format.rwl")
    mock_open.assert_called_once_with("valid_rwl_correct_format.rwl", None)

    expected_df = pd.DataFrame(data={"SeriesA": [0.1, 0.3, 0.5, 0.7],
                                     "SeriesB": [0.2, 0.4, 0.6, 0.8]},
                                     index=pd.Index(data=[1, 2, 3, 4], 
                                                    name="Year"))
    print(results)
    pd.testing.assert_frame_equal(results, expected_df)

'''
    Given input valid_rwl_correct_format.rwl, and skip_lines=1, test that readers
    produces the expected dataframe.
'''
@patch.object(_readers_mod, '_read_text')
def test_correct_rwl_skip_lines(mock_open: Mock):
    mock_open.side_effect = mock_read_text_output

    results = dpl.readers("valid_rwl_correct_format.rwl", skip_lines=1)
    print(results)
    mock_open.assert_called_once_with("valid_rwl_correct_format.rwl", None)

    expected_df = pd.DataFrame(data={"SeriesB": [0.2, 0.4, 0.6, 0.8]},
                                     index=pd.Index(data=[1, 2, 3, 4], 
                                                    name="Year"))
    pd.testing.assert_frame_equal(results, expected_df)

'''
    Given input valid_rwl_correct_format.rwl, and header=True, test that readers
    correctly skips header lines to produce the expected dataframe.
'''
@patch.object(_readers_mod, '_read_text')
def test_correct_rwl_with_headers(mock_open: Mock):
    mock_open.side_effect = mock_read_text_output

    results = dpl.readers("valid_rwl_with_headers.rwl", header=True)
    mock_open.assert_called_once_with("valid_rwl_with_headers.rwl", None)

    expected_df = pd.DataFrame(data={"SeriesA": [0.1, 0.3, 0.5, 0.7],
                                     "SeriesB": [0.2, 0.4, 0.6, 0.8]},
                                     index=pd.Index(data=[1, 2, 3, 4], 
                                                    name="Year"))
    pd.testing.assert_frame_equal(results, expected_df)

@patch.object(_readers_mod, '_read_text')
def test_rwl_with_blank_lines(mock_open: Mock):
    # Blank lines are harmless (a trailing newline, or a "double-spaced" ITRDB
    # file) and no longer warned about line by line -- they are dropped and their
    # 1-indexed positions recorded silently on df.attrs["dplpy_blank_lines"].
    mock_open.side_effect = mock_read_text_output

    expected_df = pd.DataFrame(data={"SeriesA": [0.1, 0.3, 0.5, 0.7],
                                     "SeriesB": [0.2, 0.4, 0.6, 0.8]},
                                     index=pd.Index(data=[1, 2, 3, 4],
                                                    name="Year"))

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        results = dpl.readers("valid_rwl_with_blanks.rwl")
    mock_open.assert_called_once_with("valid_rwl_with_blanks.rwl", None)
    pd.testing.assert_frame_equal(results, expected_df)
    assert not [x for x in w if "Empty line" in str(x.message)]   # no blank-line alarm
    assert results.attrs["dplpy_blank_lines"] == [2]              # recorded silently


# ===========================================================================
# Hardened Tucson (.rwl) reader (v0.2.x): header auto-detection, dplR fidelity,
# deliberate NaN divergences (gaps / anomalous negatives), and duplicate-ID
# rejection. Reference values are hardcoded from dplR 1.7.9 read.rwl() so the
# validation runs in CI without requiring R.
# ===========================================================================

RWL = "tests/data/rwl/"


def _read_quiet(path, **kw):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        return dpl.readers(path, **kw)


def test_rwl_autodetect_matches_dplR_ca533():
    # Read with NO header argument (auto-detection) and check exact dplR values.
    data = _read_quiet(RWL + "ca533.rwl")
    assert data.shape == (1358, 34)
    # dplR read.rwl() reference cells for series CAM011:
    assert data.loc[1530, "CAM011"] == pytest.approx(1.04)
    assert data.loc[1800, "CAM011"] == pytest.approx(0.44)
    assert data.loc[1900, "CAM011"] == pytest.approx(0.45)
    assert data.loc[1983, "CAM011"] == pytest.approx(0.68)
    # outside the series span -> NaN (dplR agrees)
    assert np.isnan(data.loc[1500, "CAM011"])


def _flip_case_rwl(tmp_path, terminate_first=False):
    # One core whose ID case flips mid-series: an uppercase block running into a
    # lowercase continuation that carries the -9999 stop marker. terminate_first=True
    # gives the first block its own stop marker too (two properly-terminated
    # case-variant blocks, which must NOT be merged).
    first = ("AAA01A  1000   100   200   300   400 -9999\n" if terminate_first
             else "AAA01A  1000   100   200   300   400   500\n")
    p = tmp_path / "flip.rwl"
    p.write_text(first + "AAA01a  1005   150   250   350 -9999\n")
    return str(p)


def test_case_variant_missing_terminator_merges_under_join_true(tmp_path):
    # Case flip + a missing stop marker + disjoint years -> one core, merged by
    # default (join=True). The merge is recorded and no case-variant pair remains.
    df = _read_quiet(_flip_case_rwl(tmp_path))
    assert "AAA01A" in df.columns and "AAA01a" not in df.columns
    s = df["AAA01A"].dropna()
    assert (int(s.index.min()), int(s.index.max())) == (1000, 1007)
    assert df.attrs["dplpy_case_merged"] == [
        {"canonical": "AAA01A", "ids": ["AAA01A", "AAA01a"], "n_blocks": 2,
         "first_year": 1000, "last_year": 1007}]
    assert df.attrs["dplpy_case_variant_ids"] == []


def test_case_variant_kept_separate_under_join_false(tmp_path):
    # join=False keeps the segments separate (per-segment view) and flags the pair.
    df = _read_quiet(_flip_case_rwl(tmp_path), join=False)
    assert "AAA01A" in df.columns and "AAA01a" in df.columns
    assert df.attrs["dplpy_case_merged"] == []
    assert df.attrs["dplpy_case_variant_ids"] == [{"ids": ["AAA01A", "AAA01a"]}]


def test_case_variant_both_terminated_not_merged(tmp_path):
    # Two case-variant IDs that are BOTH properly terminated may be distinct cores,
    # so they are NOT merged even under join=True -- only flagged.
    df = _read_quiet(_flip_case_rwl(tmp_path, terminate_first=True))
    assert "AAA01A" in df.columns and "AAA01a" in df.columns
    assert df.attrs["dplpy_case_merged"] == []
    assert df.attrs["dplpy_case_variant_ids"] == [{"ids": ["AAA01A", "AAA01a"]}]


def test_no_case_variant_flag_for_clean_file():
    data = _read_quiet(RWL + "ca533.rwl")
    assert data.attrs["dplpy_case_variant_ids"] == []
    assert data.attrs["dplpy_case_merged"] == []


def test_rwl_header_autodetected_by_default():
    # th001 has a 3-line header; before hardening this failed unless header=True
    # was passed. Auto-detection must now read it with no header argument.
    data = _read_quiet(RWL + "th001.rwl")
    assert data.shape == (448, 77)
    assert "PATUNG" in data.columns


def test_rwl_duplicate_id_raises_and_names_series():
    # viet001 contains the duplicated ID BDF02A (two cores sharing a code).
    # dplPy must refuse rather than silently merge, and name the offender.
    with pytest.raises(ValueError) as e:
        _read_quiet(RWL + "viet001.rwl")
    msg = str(e.value)
    assert "Duplicate series ID" in msg
    assert "BDF02A" in msg


def test_rwl_anomalous_negative_becomes_nan_with_warning():
    # th001's PATUNG decade-1920 row carries a spurious -2599; it must become
    # NaN (not -2.599, not 0.0) and the user must be warned.
    with pytest.warns(UserWarning, match="anomalous negative"):
        data = dpl.readers(RWL + "th001.rwl")
    assert np.isnan(data.loc[1928, "PATUNG"])       # the anomalous value -> NaN
    assert data.loc[1927, "PATUNG"] == pytest.approx(0.983)  # neighbours intact
    assert data.loc[1929, "PATUNG"] == pytest.approx(0.597)


def test_rwl_internal_gap_stays_nan_not_zero():
    # ca667's ST850A has a real ~250-year data gap. dplR fills it with 0.0
    # (a zero-init artifact); dplPy deliberately keeps genuine gaps as NaN so
    # they stay out of downstream means. Valid values still match dplR exactly.
    data = _read_quiet(RWL + "ca667.rwl")
    assert data.loc[-390, "ST850A"] == pytest.approx(0.35)   # matches dplR
    assert data.loc[-389, "ST850A"] == pytest.approx(0.36)   # matches dplR
    assert np.isnan(data.loc[-388, "ST850A"])                # stop-marker slot
    assert np.isnan(data.loc[-385, "ST850A"])                # inside the gap


def test_rwl_self_overlap_reported_not_as_duplicate(tmp_path):
    # akfirmc-style hidden error: a single series whose opening partial-decade
    # row carries one value too many (6 values from a 1205 start), so it runs
    # into the next row that begins at 1210. This must be reported as the series
    # overlapping ITSELF (pointing at the offending row), NOT as a duplicate ID
    # -- there is only one block for this series.
    p = tmp_path / "selfoverlap.rwl"
    p.write_text(
        "AAA01   1205   206   144   216   316   308   420\n"
        "AAA01   1210   732   500   642   784   816   470   446   474   432   519\n"
        "AAA01   1220   140   160 -9999\n"
    )
    with pytest.raises(ValueError) as e:
        dpl.readers(str(p))
    msg = str(e.value)
    assert "overlaps itself" in msg          # correctly diagnosed as self-overlap
    assert "AAA01" in msg
    assert "1210" in msg                     # names the overlapping year
    assert "Duplicate series ID" not in msg  # NOT mislabelled as a duplicate


# Two blocks of one ID stacked back-to-back with no separating line: the year
# jumps backward (1820 -> 1805), the tell-tale of a second core sharing the code.
# The second block is on an offset decade grid and overlaps the first.
_OFFSET_DUP = (
    "SYN01A  1800   100   110   120   130   140   150   160   170   180   190\n"
    "SYN01A  1810   200   210   220   230   240   250   260   270   280   290\n"
    "SYN01A  1820   300   310   320   999\n"
    "SYN01A  1805   500   510   520   530   540   550   560   570   580   590\n"
    "SYN01A  1815   600   610   620   630   640   650   660   670   680   690\n"
    "SYN01A  1825   700   710   720   999\n"
    "SYN02A  1800    50    60    70    80    90   100   110   120   130   140\n"
    "SYN02A  1810   150   160   170   999\n"
)


def test_rwl_offset_duplicate_reported_as_duplicate(tmp_path):
    # A back-to-back offset duplicate must be diagnosed as a DUPLICATE ID -- not a
    # self-overlap (there really are two blocks, found via the backward-year reset)
    # and NOT the misleading "does not parse as fixed-width columns" error: the
    # columns parse cleanly, only the decade is offset.
    p = tmp_path / "offsetdup.rwl"
    p.write_text(_OFFSET_DUP)
    with pytest.raises(ValueError) as e:
        dpl.readers(str(p))
    msg = str(e.value)
    assert "Duplicate series ID" in msg
    assert "SYN01A" in msg
    assert "overlaps itself" not in msg               # not a self-overlap
    assert "does not parse as fixed-width" not in msg  # not mislabelled


def test_out_of_order_row_is_one_series_not_a_duplicate(tmp_path):
    # A single core whose rows are written OUT OF ORDER (a decade placed before an
    # earlier one -- as in wy002's 283012 and nm604's 101401) has a backward year
    # jump, but its blocks are DISJOINT (they fill each other's gaps, nothing
    # overlaps). It must read as ONE merged series over the full span, and must NOT
    # be mislabelled a merged duplicate in the combined-series report (the backward
    # jump alone is not a duplicate -- only an overlap, or a separate reappearance,
    # is).
    p = tmp_path / "outoforder.rwl"
    p.write_text(
        "AAA01   1820    10    11    12    13    14    15    16    17    18    19\n"
        "AAA01   1800    20    21    22    23    24    25    26    27    28    29\n"
        "AAA01   1810    30    31    32    33    34    35    36    37    38    39\n"
        "AAA01   1830    40    41    42    43    44    45    46   999\n"
    )
    with pytest.warns(UserWarning, match="AAA01 had rows out of year order"):
        d = dpl.readers(str(p))
    assert list(d.columns) == ["AAA01"]                  # one series, not two
    assert int(d.index.min()) == 1800 and int(d.index.max()) == 1836
    assert d.loc[1800, "AAA01"] == pytest.approx(0.20)   # 1800 row placed at 1800
    assert d.loc[1820, "AAA01"] == pytest.approx(0.10)   # out-of-order row placed right
    assert not np.isnan(d.loc[1829, "AAA01"])            # no gap where 1820 block sits
    combined = d.attrs.get("dplpy_combined", [])
    assert combined == []                                # NOT reported as a duplicate merge


def test_salvage_offset_duplicate_drops_whole_series(tmp_path):
    # An offset duplicate cannot be rationally salvaged: the second block is on a
    # 5-year-offset grid (corrupt structure, not a real second core), so there is
    # no telling which block is the true SYN01A. Salvage drops the WHOLE series
    # (both blocks) rather than fabricate a renamed SYN01A2, and keeps SYN02A.
    p = tmp_path / "offsetdup.rwl"
    p.write_text(_OFFSET_DUP)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        d = dpl.readers(str(p), strict=False)
    assert "SYN02A" in d.columns                       # the clean series survives
    assert "SYN01A" not in d.columns                   # dropped, not kept
    assert "SYN01A2" not in d.columns                  # and NOT fabricated
    dropped = [r for r in d.attrs["dplpy_salvage"]
               if r["series"] == "SYN01A" and r["action"] == "dropped"]
    assert dropped and dropped[0]["issue"] == "duplicate_id"


def test_salvage_lone_decade_overrun_drops_series(tmp_path):
    # A decade-misaligned row with no overlap/duplicate to key on is corrupt
    # structure. Salvage drops the whole affected series (and records it) rather
    # than silently placing its values at guessed years; a clean series alongside
    # it survives.
    p = tmp_path / "overrun.rwl"
    p.write_text(
        "AAA1    1693" + "".join("%6d" % v for v in range(1, 11)) + "\n"  # 10 vals @1693
        "BBB1    1900   100   110   120   999\n"                          # clean
    )
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        d = dpl.readers(str(p), header=False, strict=False)
    assert list(d.columns) == ["BBB1"]                 # clean series kept
    assert "AAA1" not in d.columns                      # offset series dropped
    dropped = [r for r in d.attrs["dplpy_salvage"]
               if r["series"] == "AAA1" and r["action"] == "dropped"]
    assert dropped and dropped[0]["issue"] == "too_many_values"


def test_salvage_aligned_duplicate_still_renames_and_keeps_both():
    # The ordinary duplicate -- two VALID decade-aligned cores sharing a code
    # (viet001's BDF02A) -- is still rename-and-kept, not dropped.
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        d = dpl.readers(RWL + "viet001.rwl", strict=False)
    assert "BDF02A" in d.columns and "BDF02A2" in d.columns


def test_rwl_999_is_real_value_in_thousandths_series(tmp_path):
    # In a 0.001 mm series (terminated by -9999), the token 999 is a real
    # 0.999 mm ring, NOT a stop marker. Precision is taken from the series
    # terminator, so a mid-series 999 must be kept as 0.999 (the older
    # "any 999 is a marker" logic silently dropped it to NaN). dplR keeps it.
    p = tmp_path / "thousandths.rwl"
    p.write_text(
        "AAA01   1900   500   600   999   700   800   650   720   540   610   590\n"
        "AAA01   1910   480   999   520   540   560   580   600   620   640   660\n"
        "AAA01   1920   700 -9999\n"
    )
    d = dpl.readers(str(p))
    assert d.loc[1902, "AAA01"] == pytest.approx(0.999)   # kept, not NaN
    assert d.loc[1911, "AAA01"] == pytest.approx(0.999)
    assert d.loc[1900, "AAA01"] == pytest.approx(0.5)
    assert d.loc[1920, "AAA01"] == pytest.approx(0.7)


def test_rwl_measurement_precision_shift_raises(tmp_path):
    # A single series measured at two precisions -- an early 0.001 mm segment
    # (ending in -9999) then a later 0.01 mm segment (ending in 999), the kok3a
    # pattern from kyrg014. Reading it at one precision makes part of it 10x
    # wrong, so normal mode must refuse and name the series.
    p = tmp_path / "shift.rwl"
    p.write_text(
        "AAA01   1900   910  1180  1480  1270 -9999\n"
        "AAA01   1910    24    20    15    23   999\n"
    )
    with pytest.raises(ValueError) as e:
        dpl.readers(str(p))
    msg = str(e.value)
    assert "precision" in msg.lower()
    assert "AAA01" in msg


def test_rwl_recovers_first_data_row_with_hash_in_header():
    # nm580's header line 1 contains 'UAFACC#=04-223'. The '#' made the older
    # reader treat that header line as a comment, after which "skip exactly 3"
    # ate the first real data row (BCS05B's 1370 decade). Skipping to the first
    # *data* line instead recovers it. dplR 1.7.9 still drops this row; dplPy now
    # reads it (matching OpenDendro's corrected read.tucson2). Raw row values ÷1000.
    d = _read_quiet(RWL + "nm580.rwl")
    assert d.loc[1370, "BCS05B"] == pytest.approx(1.373)
    assert d.loc[1379, "BCS05B"] == pytest.approx(0.784)


def test_rwl_single_line_header_keeps_all_rows(tmp_path):
    # A 1-line header must not cost the first two data rows (the old skip-3 bug).
    p = tmp_path / "h1.rwl"
    p.write_text(
        "ONE LINE OF HEADER TEXT SITE SPECIES INVESTIGATOR\n"
        "AAA01   1900   100   200   300   400   500   600   700   800   900  1000\n"
        "AAA01   1910   110 -9999\n"
    )
    d = dpl.readers(str(p))
    assert 1900 in d.index and 1909 in d.index
    assert d.loc[1900, "AAA01"] == pytest.approx(0.1)


def test_rwl_blank_interior_field_preserves_alignment(tmp_path):
    # A blank 6-char field (a missing ring written as blanks) must leave the rest
    # of the decade aligned, not shift every later value one year to the left.
    p = tmp_path / "blank.rwl"
    p.write_text(
        "AAA01   1900   100   200         400   500   600   700   800   900  1000\n"
        "AAA01   1910  1100 -9999\n"
    )
    d = dpl.readers(str(p))
    assert d.loc[1901, "AAA01"] == pytest.approx(0.2)
    assert np.isnan(d.loc[1902, "AAA01"])          # the blank -> missing
    assert d.loc[1903, "AAA01"] == pytest.approx(0.4)   # NOT shifted into 1902
    assert d.loc[1909, "AAA01"] == pytest.approx(1.0)   # last value not lost


def test_rwl_trailing_notes_are_ignored(tmp_path):
    # Notes appended after the data columns must not break the read.
    p = tmp_path / "notes.rwl"
    p.write_text(
        "AAA01   1900   100   200   300   400   500 -9999   note: suspect core\n"
        "AAA01B  1900   111   222 -9999\n"
    )
    d = dpl.readers(str(p))
    assert d.loc[1900, "AAA01"] == pytest.approx(0.1)
    assert d.loc[1904, "AAA01"] == pytest.approx(0.5)


def test_rwl_identical_duplicate_rows_deduped(tmp_path):
    # A byte-identical duplicated row (copy-paste) is unambiguous: dedupe + warn,
    # do NOT fail.
    p = tmp_path / "dup.rwl"
    p.write_text(
        "AAA01   1900   100   200   300 -9999\n"
        "AAA01   1900   100   200   300 -9999\n"
    )
    with pytest.warns(UserWarning, match="identical duplicate"):
        d = dpl.readers(str(p))
    assert d.loc[1900, "AAA01"] == pytest.approx(0.1)


def test_rwl_conflicting_duplicate_still_raises(tmp_path):
    # Same core+year with a DIFFERENT value is a genuine conflict -> still fail.
    p = tmp_path / "conf.rwl"
    p.write_text(
        "AAA01   1900   100   200   300 -9999\n"
        "AAA01   1900   555   200   300 -9999\n"
    )
    with pytest.raises(ValueError):
        dpl.readers(str(p))


def test_rwl_bunched_negative_year_uses_long_format(tmp_path):
    # A BC year < -999 written bunched to the ID with no space, e.g.
    # 'MNP262M-1270' = year -1270 (the chin067 / long-negative-years case).
    # Must be read as a 7-char ID + 5-char year, not as ID 'MNP262M-' + year
    # +1270 (which would misorder the series and trip the self-overlap check).
    p = tmp_path / "bc.rwl"
    p.write_text(
        "MNP262M-1270   375   250   300   280   310   295   330   340   360   355\n"
        "MNP262M-1260   245   240   290   220   320   280   215   300   410   500\n"
        "MNP262M-1250   170 -9999\n"
    )
    d = dpl.readers(str(p))
    assert "MNP262M" in d.columns              # 7-char ID, not 'MNP262M-'
    assert d.index.min() == -1270              # negative year parsed correctly
    assert d.loc[-1270, "MNP262M"] == pytest.approx(0.375)
    assert d.loc[-1261, "MNP262M"] == pytest.approx(0.355)


# ---------------------------------------------------------------------------
# Salvage mode (strict=False): recover as much as possible instead of raising.
# ---------------------------------------------------------------------------

def test_salvage_self_overlap_drops_series_keeps_rest(tmp_path):
    p = tmp_path / "so.rwl"
    p.write_text(
        "AAA01   1205   206   144   216   316   308   420\n"   # 6 vals -> overruns to 1210
        "AAA01   1210   732   500   642 -9999\n"
        "BBB01   1900   100   200   300 -9999\n"               # clean series
    )
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        d = dpl.readers(str(p), strict=False)
    assert "AAA01" not in d.columns        # bad series dropped
    assert "BBB01" in d.columns            # clean series kept
    rep = d.attrs["dplpy_salvage"]
    assert any(r["series"] == "AAA01" and r["issue"] == "self_overlap"
               and r["action"] == "dropped" for r in rep)


def test_salvage_precision_shift_drops_series_keeps_rest(tmp_path):
    p = tmp_path / "ps.rwl"
    p.write_text(
        "AAA01   1900   910  1180 -9999\n"   # 0.001 segment...
        "AAA01   1910    24    20   999\n"    # ...then 0.01 -> precision shift
        "BBB01   1900   100   200   300 -9999\n"
    )
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        d = dpl.readers(str(p), strict=False)
    assert "AAA01" not in d.columns
    assert "BBB01" in d.columns
    assert any(r["issue"] == "precision_shift" for r in d.attrs["dplpy_salvage"])


def test_salvage_duplicate_id_renames_and_keeps_both():
    # viet001 has BDF02A used by two overlapping cores. Salvage keeps both,
    # renaming the second block; strict still refuses.
    with pytest.raises(ValueError):
        dpl.readers(RWL + "viet001.rwl")                       # strict
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        d = dpl.readers(RWL + "viet001.rwl", strict=False)  # salvage
    assert "BDF02A" in d.columns and "BDF02A2" in d.columns
    assert any(r["issue"] == "duplicate_id" and r["action"].startswith("renamed")
               for r in d.attrs["dplpy_salvage"])


def test_salvage_disjoint_segments_merge_and_report(tmp_path):
    # One ID written as two disjoint (non-overlapping) terminated blocks is joined
    # into a single series -- never renamed/split. Because the blocks have the same
    # ID with no shared years, salvage records the join in its report (and strict
    # warns about it -- see the next test): a real merge is not silent.
    p = tmp_path / "seg.rwl"
    p.write_text(
        "AAA01   1900   100   200   300 -9999\n"
        "AAA01   2000   400   500   600 -9999\n"
    )
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        d = dpl.readers(str(p), strict=False)
    assert "AAA01" in d.columns and "AAA012" not in d.columns   # merged, not split
    assert d.loc[1900, "AAA01"] == pytest.approx(0.1)
    assert d.loc[2000, "AAA01"] == pytest.approx(0.4)
    rep = d.attrs["dplpy_salvage"]
    assert len(rep) == 1
    assert rep[0]["series"] == "AAA01"
    assert rep[0]["issue"] == "duplicate_id" and rep[0]["action"] == "joined"


def test_strict_disjoint_duplicate_joins_and_warns(tmp_path):
    # In strict (default) mode the same disjoint-duplicate ID is still joined into
    # one series, but it WARNS rather than raising (the years do not conflict, so
    # there is nothing to refuse) -- and it is NOT mislabelled a flipped-date
    # "out of year order" row (that is a backward year within one block).
    p = tmp_path / "seg.rwl"
    p.write_text(
        "AAA01   1900   100   200   300 -9999\n"
        "AAA01   2000   400   500   600 -9999\n"
    )
    with pytest.warns(UserWarning, match="duplicate ID in separate blocks"):
        d = dpl.readers(str(p))
    assert list(d.columns) == ["AAA01"]            # one merged series
    assert d.loc[1900, "AAA01"] == pytest.approx(0.1)
    assert d.loc[2000, "AAA01"] == pytest.approx(0.4)


def test_reverse_order_disjoint_duplicate_is_join_not_out_of_order(tmp_path):
    # The ut542 CC1-2 / ut550 RCB183A shape: the same ID as two SEPARATELY
    # TERMINATED blocks written OUT of chronological order (the older core second).
    # The blocks do not share years, so they merge into one series. This must be
    # recognised as a joined duplicate ID -- NOT the "out of year order" warning
    # (that is a backward row WITHIN one block, e.g. a flipped date), and NOT a
    # raise (there is no year conflict to refuse).
    p = tmp_path / "revdup.rwl"
    p.write_text(
        "BBB1    1900   100   200   300 -9999\n"   # newer core, terminated
        "BBB1    1800   400   500   600 -9999\n"   # older core, terminated (reverse)
    )
    with pytest.warns(UserWarning) as rec:
        d = dpl.readers(str(p))
    msgs = " || ".join(str(w.message) for w in rec)
    assert "duplicate ID in separate blocks" in msgs
    assert "out of year order" not in msgs         # not mislabelled a flipped date
    assert list(d.columns) == ["BBB1"]             # one merged series
    assert d.loc[1800, "BBB1"] == pytest.approx(0.4)   # older block placed by year
    assert d.loc[1900, "BBB1"] == pytest.approx(0.1)   # newer block placed by year


def test_salvage_identical_overlap_not_renamed(tmp_path):
    # Same ID in two blocks covering the same years with IDENTICAL values (a
    # copy-paste, the cana326 case) must dedup, not rename/split.
    p = tmp_path / "iddup.rwl"
    p.write_text(
        "AAA01   1900   100   200   300 -9999\n"
        "BBB01   1910   111   222 -9999\n"
        "AAA01   1900   100   200   300 -9999\n"
    )
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        d = dpl.readers(str(p), strict=False)
    assert "AAA01" in d.columns and "AAA012" not in d.columns
    assert not any(r["issue"] == "duplicate_id" for r in d.attrs["dplpy_salvage"])


def test_invalid_strict_value():
    # strict must be a bool; a stray string (e.g. an old on_error value) is rejected
    # with a clear ValueError rather than being silently treated as truthy=strict.
    with pytest.raises(ValueError):
        dpl.readers(RWL + "ca533.rwl", strict="bogus")


def test_readers_reads_rwl_from_url():
    # readers() accepts an http(s) URL directly and routes it through the same
    # pipeline as a local file. urllib is mocked to serve a local file's bytes
    # (no network), and the result must equal the local read.
    import urllib.request
    from unittest.mock import patch, MagicMock
    local = _read_quiet(RWL + "ca533.rwl")
    raw = open(RWL + "ca533.rwl", "rb").read()

    def fake_urlopen(url, *a, **k):
        m = MagicMock()
        m.read.return_value = raw
        m.__enter__.return_value = m
        m.__exit__.return_value = False
        return m

    # Patch urllib.request.urlopen directly (the object readers.py resolves at
    # call time). A string target like "dplpy.readers.urllib..." is fragile:
    # the package re-exports the `readers` function, so the name `dplpy.readers`
    # can resolve to the function rather than the module (version-dependent).
    with patch.object(urllib.request, "urlopen", side_effect=fake_urlopen):
        via_url = _read_quiet(
            "https://www.ncei.noaa.gov/pub/data/paleo/treering/measurements/"
            "northamerica/usa/ca533.rwl"
        )
    pd.testing.assert_frame_equal(local, via_url)


def test_reads_tucson_from_nonstandard_suffix(tmp_path):
    # A valid Tucson file with a .txt suffix is recognized by content sniffing.
    import shutil
    local = _read_quiet(RWL + "ca533.rwl")
    p = tmp_path / "ca533.txt"
    shutil.copy(RWL + "ca533.rwl", str(p))
    got = _read_quiet(str(p))
    pd.testing.assert_frame_equal(local, got)


def test_format_override_forces_tucson(tmp_path):
    # No suffix at all, but format='tucson' forces the Tucson reader.
    import shutil
    local = _read_quiet(RWL + "ca533.rwl")
    p = tmp_path / "ca533_nosuffix"
    shutil.copy(RWL + "ca533.rwl", str(p))
    got = _read_quiet(str(p), format="tucson")
    pd.testing.assert_frame_equal(local, got)


def test_reads_csv_from_nonstandard_suffix(tmp_path):
    # A CSV with a .txt suffix is sniffed as CSV, not Tucson.
    import shutil
    local = _read_quiet("tests/data/csv/ca533.csv")
    p = tmp_path / "ca533csv.txt"
    shutil.copy("tests/data/csv/ca533.csv", str(p))
    got = _read_quiet(str(p))
    pd.testing.assert_frame_equal(local, got)


def test_header_lines_skipped_reported():
    # Auto-detection records how many header lines it skipped (transparency).
    data = _read_quiet(RWL + "th001.rwl")           # 3-line header
    assert data.attrs["dplpy_header_lines_skipped"] == 3
    # a header-less file reports 0
    ca = _read_quiet(RWL + "ca533.rwl")
    assert ca.attrs["dplpy_header_lines_skipped"] == 0


# ---------------------------------------------------------------------------
# Header metadata extraction (prototype).
# ---------------------------------------------------------------------------

def test_metadata_extraction_tx042():
    md = dpl.metadata(RWL + "tx042.rwl")
    assert md["site_id"] == "BSC"
    assert md["species_code"] == "PSME"
    assert md["species_name"] == "Douglas Fir"
    assert md["country_region"] == "Texas"
    assert md["elevation_m"] == 2057
    assert md["latitude"] == pytest.approx(29.25, abs=1e-3)
    assert md["longitude"] == pytest.approx(-103.3, abs=1e-3)   # sign correct here
    assert md["first_year"] == 1473 and md["last_year"] == 1992


def test_metadata_extraction_th001():
    md = dpl.metadata(RWL + "th001.rwl")
    assert md["site_id"] == "MHGSTG"
    assert md["species_code"] == "TEGR"
    assert md["country_region"] == "Thailand"
    assert md["latitude"] == pytest.approx(19.2833, abs=1e-3)
    assert md["longitude"] == pytest.approx(98.9333, abs=1e-3)


def test_metadata_on_df_attrs():
    d = _read_quiet(RWL + "th001.rwl")
    assert "dplpy_metadata" in d.attrs
    assert d.attrs["dplpy_metadata"]["species_code"] == "TEGR"


def test_metadata_headerless_file_is_empty():
    # ca533 has no header -> all fields None, no crash.
    md = dpl.metadata(RWL + "ca533.rwl")
    assert md["n_header_lines"] == 0
    assert md["site_id"] is None and md["species_code"] is None


def test_dm_to_decimal_decoder():
    from dplpy.readers import _dm_to_decimal
    assert _dm_to_decimal("3627") == pytest.approx(36.45)
    assert _dm_to_decimal("-2053") == pytest.approx(-20.8833, abs=1e-3)
    assert _dm_to_decimal("00406") == pytest.approx(4.1, abs=1e-3)
    assert _dm_to_decimal("abc") is None


def test_metadata_hemisphere_correction_americas(tmp_path):
    # A recognized N. American state forces West longitude even when the file
    # stored it without the '-' sign.
    p = tmp_path / "arz.rwl"
    p.write_text(
        "ARZ    1 Some Arizona Site                                   PSME\n"
        "ARZ    2 Arizona      Douglas Fir       2000M  3530 11140    __    1500 1990\n"
        "ARZ    3 J. Smith\n"
        "ARZ    1500   100   200 -9999\n"
    )
    md = dpl.metadata(str(p))
    assert md["country_region"] == "Arizona"
    assert md["hemisphere_verified"] is True
    assert md["latitude"] == pytest.approx(35.5, abs=1e-2)
    assert md["longitude"] == pytest.approx(-111.6667, abs=1e-3)   # corrected to West


def test_metadata_hemisphere_unverified_eastern(tmp_path):
    # An Eastern-hemisphere country is left as decoded and flagged unverified
    # (we don't guess sign outside the Americas).
    p = tmp_path / "nor.rwl"
    p.write_text(
        "NOR    1 Some Norway Site                                    PISY\n"
        "NOR    2 Norway   Scots pine        200  6829 1602    __    1485 1978\n"
        "NOR    3 A. Person\n"
        "NOR    1485   100   200 -9999\n"
    )
    md = dpl.metadata(str(p))
    assert md["country_region"] == "Norway"
    assert md["hemisphere_verified"] is False
    assert md["longitude"] == pytest.approx(16.0333, abs=1e-3)     # left as decoded


def test_region_hemisphere_lookup():
    from dplpy.readers import _region_hemisphere
    assert _region_hemisphere("Texas") == (1, -1)
    assert _region_hemisphere("California") == (1, -1)
    assert _region_hemisphere("Chile") == (None, -1)
    assert _region_hemisphere("Norway") == (None, None)
    assert _region_hemisphere("") == (None, None)


def test_future_year_raises_in_strict_mode(tmp_path):
    # A most-recent year in the future is a sanity-check failure: a ring cannot
    # post-date the present. 2999 is safely in the future regardless of run date.
    p = tmp_path / "future.csv"
    pd.DataFrame({"Year": [2000, 2001, 2999], "S1": [0.1, 0.2, 0.3]}).to_csv(p, index=False)
    with pytest.raises(ValueError) as e:
        dpl.readers(str(p))                               # strict=True (default)
    assert "future" in str(e.value) and "2999" in str(e.value)


def test_future_year_warns_and_continues_in_salvage_mode(tmp_path):
    p = tmp_path / "future.csv"
    pd.DataFrame({"Year": [2000, 2001, 2999], "S1": [0.1, 0.2, 0.3]}).to_csv(p, index=False)
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        res = dpl.readers(str(p), strict=False)
    assert res is not None and int(res.index.max()) == 2999   # kept, not dropped
    assert any("future" in str(x.message) for x in w)


# --- fixed-width column misalignment ('1  065', shifted grids) ---------------
# A value field that still holds a space once stripped (e.g. '1  065', or az606's
# '6  142' where 126 was truncated to 12) means the fixed-width columns are shifted
# and the row is corrupt. In a fixed-width format that is severe: strict refuses
# the whole file, salvage NaNs the whole offending row and records it.
_SPLIT_RWL = [
    "S1        1 TEST SITE                      TS",
    "S1        2 TESTLAND SPECIES     1000 M ...  1900 1911",
    "S1        3 TESTER",
    "S1      1900   100   200   300   400   500   600   700   800   900   950",
    "S1      1910   1501  065   999",
]
_CLEAN_RWL = [
    "S1        1 TEST SITE                      TS",
    "S1        2 TESTLAND SPECIES     1000 M ...  1900 1902",
    "S1        3 TESTER",
    "S1      1900   100   200   999",
]


def test_embedded_space_value_raises_in_strict(tmp_path):
    # a value with embedded spaces ('1  065') means a shifted/embedded fixed-width
    # field -- a column misalignment. In a fixed-width format that is fatal, so
    # strict mode refuses the whole file.
    p = tmp_path / "split.rwl"
    p.write_text("\n".join(_SPLIT_RWL) + "\n")
    with pytest.raises(ValueError, match="misaligned"):
        dpl.readers(str(p), strict=True)


def test_embedded_space_value_is_nan_row_in_salvage(tmp_path):
    # salvage NaNs the whole misaligned row (once the grid shifts, the rest is
    # suspect), records it, and keeps the other decades / the rest of the batch.
    p = tmp_path / "split.rwl"
    p.write_text("\n".join(_SPLIT_RWL) + "\n")
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        df = dpl.readers(str(p), strict=False)
    assert 1900 in df["S1"].dropna().index                    # the clean 1900 decade still read
    assert 1910 not in df["S1"].dropna().index                # the misaligned 1910 row is gone
    acts = [a for a in df.attrs["dplpy_salvage"] if a["issue"] == "column_misalignment"]
    assert acts and acts[0]["series"] == "S1"
    assert any("misaligned" in str(x.message) for x in w)


def test_clean_file_reports_no_unreadable_clause(tmp_path, capsys):
    p = tmp_path / "clean.rwl"
    p.write_text("\n".join(_CLEAN_RWL) + "\n")
    df = dpl.readers(str(p))
    out = capsys.readouterr().out
    assert df.attrs["dplpy_dropped"] == 0
    assert "unreadable" not in out                           # clause omitted when nothing was dropped


# --- fixed-width value region capped at cols 13-72; joined-record splitting ----
def _rwl_row(sid, year, vals):
    return sid.ljust(8) + ("%4d" % year) + "".join("%6d" % v for v in vals)


def test_trailing_count_column_ignored(tmp_path):
    # a nonstandard per-row value-count past col 72 (as in germ012l) must not be
    # read as an 11th value -- that used to force a whitespace fall-back and a
    # spurious self-overlap.
    lines = [
        _rwl_row("SER1", 1900, [100, 110, 120, 130, 140, 150, 160, 170, 180, 190]) + "      10",
        _rwl_row("SER1", 1910, [200, 999]),
    ]
    p = tmp_path / "count.rwl"
    p.write_text("\n".join(lines) + "\n")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        df = dpl.readers(str(p), header=False, strict=True)   # no self-overlap raised
    assert list(df.columns) == ["SER1"]
    assert df["SER1"].loc[1900] == pytest.approx(1.00)             # 100 at 0.01 mm precision
    assert int(df["SER1"].last_valid_index()) == 1910


def test_joined_records_raise_strict_split_salvage(tmp_path):
    # a missing line break joining SER1's terminal row to SER2's first row
    joined = (_rwl_row("SER1", 1900, [100, 110, 120, 130, 140, 150, 160, 170, 180, 999])
              + _rwl_row("SER2", 1910, [200, 210, 999]))
    p = tmp_path / "joined.rwl"
    p.write_text(joined + "\n")
    # strict refuses: a missing line break is a file defect, not something to guess
    with pytest.raises(ValueError, match="missing line break"):
        dpl.readers(str(p), header=False, strict=True)
    # salvage splits both records apart and warns
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        df = dpl.readers(str(p), header=False, strict=False)
    assert set(df.columns) == {"SER1", "SER2"}
    assert int(df["SER1"].last_valid_index()) == 1908             # 999 stop at 1909
    assert int(df["SER2"].first_valid_index()) == 1910
    assert any("missing line break" in str(x.message) for x in w)


def test_site_id_after_stop_is_not_split(tmp_path):
    # a normal trailing site ID after the stop marker (no following year) must NOT
    # be treated as a joined record
    line = _rwl_row("SER1", 1900, [100, 110, 120, 130, 140, 150, 160, 170, 180, 999]) + "TRW1A"
    p = tmp_path / "siteid.rwl"
    p.write_text(line + "\n")
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        df = dpl.readers(str(p), header=False, strict=True)
    assert list(df.columns) == ["SER1"]
    assert not any("missing line break" in str(x.message) for x in w)


# --- guard: refuse files with more than 3 header lines (not a Tucson .rwl) ------
def test_over_long_header_is_refused(tmp_path):
    # >3 metadata lines before data -> not a clean Tucson .rwl (a NOAA Template
    # file has ~100; a doubled ITRDB header has 6). Strict raises, salvage -> None.
    for n in (4, 10):
        lines = ["metadata header line %d here" % i for i in range(1, n + 1)]
        lines += [_rwl_row("SER1", 1900, [100, 110, 999])]
        p = tmp_path / ("h%d.rwl" % n)
        p.write_text("\n".join(lines) + "\n")
        with pytest.raises(ValueError, match="does not look like a Tucson"):
            dpl.readers(str(p))
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            assert dpl.readers(str(p), strict=False) is None  # salvage -> None, not garbage


def test_three_line_header_reads(tmp_path):
    # the standard 3-line ITRDB header is the maximum and must still read
    lines = ["metadata header line %d here" % i for i in range(1, 4)]     # 3 header lines
    lines += [_rwl_row("SER1", 1900, [100, 110, 120, 999])]
    p = tmp_path / "std_header.rwl"
    p.write_text("\n".join(lines) + "\n")
    df = dpl.readers(str(p))
    assert list(df.columns) == ["SER1"]
    assert df.attrs["dplpy_header_lines_skipped"] == 3


def test_header_false_bypasses_the_guard(tmp_path):
    # header=False (caller is sure) must not trip the long-header guard
    lines = ["metadata header line %d here" % i for i in range(1, 11)]
    lines += [_rwl_row("SER1", 1900, [100, 110, 999])]
    p = tmp_path / "forced.rwl"
    p.write_text("\n".join(lines) + "\n")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        try:
            dpl.readers(str(p), header=False, strict=False)
        except ValueError as e:
            assert "does not look like a Tucson" not in str(e)     # guard not applied


# A minimal NOAA Template file: the WDS/NOAA banner and 'Template Version' in the
# '#' header, a '##' variable block, then a TAB-delimited data table (age_CE +
# series columns). This is a different format from a Tucson .rwl.
_NOAA_TEMPLATE = (
    "# World Data Service for Paleoclimatology, Boulder\n"
    "#     and NOAA Paleoclimatology Program\n"
    "# Template Version 3.0\n"
    "# Title\n"
    "#   Study_Name: Test Site\n"
    "## age_CE age,,,year Common Era,,tree ring,,,N,\n"
    "## 111011_raw ring width,,,mm,,tree ring,,,N,\n"
    "age_CE\t111011_raw\t111012_raw\n"
    "1900\t123\tNaN\n"
    "1901\t118\t130\n"
)


def test_noaa_template_file_rejected_with_clear_message(tmp_path):
    # A NOAA Template file (tab-delimited under a NOAA header) must be recognised
    # as such -- NOT reported as a misaligned Tucson row. Strict raises a clear
    # message; salvage warns it and returns None.
    p = tmp_path / "site-noaa.rwl"
    p.write_text(_NOAA_TEMPLATE)
    with pytest.raises(ValueError, match="NOAA Template file"):
        dpl.readers(str(p))
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        r = dpl.readers(str(p), strict=False)
    assert r is None
    assert any("NOAA Template file" in str(x.message) for x in w)
    assert not any("misaligned" in str(x.message) for x in w)   # not the old confusing msg


# --- '#' inside a series ID is data, not a comment (real ITRDB: SP#1, GFI..#H) --
def test_hash_in_series_id_is_not_a_comment(tmp_path):
    lines = [
        "# a genuine comment line at the top",           # starts with '#' -> stripped
        _rwl_row("SP#1", 1900, [100, 110, 999]),         # '#' inside the ID -> data, kept
        _rwl_row("SP#2", 1900, [120, 130, 999]),
    ]
    p = tmp_path / "hashid.rwl"
    p.write_text("\n".join(lines) + "\n")
    df = dpl.readers(str(p), strict=False)
    assert "SP#1" in df.columns and "SP#2" in df.columns   # not dropped as comments
    assert df.loc[1900, "SP#1"] == pytest.approx(1.00)
    assert df.loc[1901, "SP#2"] == pytest.approx(1.30)


def test_hash_marked_note_row_is_stripped_not_counted_as_header(tmp_path):
    # a '#### ...' annotation row (CDendro-style, as in ita065/prt004) sits between
    # the header and data; it doesn't start with '#' and doesn't parse as data, so
    # it must be stripped as a comment -- not counted as a 4th header line (which
    # would trip the >3 guard).
    lines = ["metadata header line %d here" % i for i in range(1, 4)]    # 3 real headers
    lines += ["SER1    #### corrC GT 0.7, CDendro note;"]                # annotation row
    lines += [_rwl_row("SER1", 1900, [100, 110, 999])]
    p = tmp_path / "noterow.rwl"
    p.write_text("\n".join(lines) + "\n")
    df = dpl.readers(str(p))                                             # not guard-rejected
    assert list(df.columns) == ["SER1"]
    assert df.attrs["dplpy_header_lines_skipped"] == 3                   # note row not a header


def test_999_inside_series_id_is_not_split(tmp_path):
    # a series ID containing '999' (e.g. 'S999A', as in aus118/aus123's Huon pine
    # cores) must NOT be split by the joined-record repair -- the '999' is in the
    # ID field (column < 12), not a stop marker in the value region.
    lines = ["metadata header line %d here" % i for i in range(1, 4)]
    lines += [_rwl_row("S999A", 1900, [100, 110, 120, 999])]
    p = tmp_path / "s999.rwl"
    p.write_text("\n".join(lines) + "\n")
    df = dpl.readers(str(p))
    assert "S999A" in df.columns and "S999" not in df.columns   # kept whole, not split
    assert df.loc[1900, "S999A"] == pytest.approx(1.00)


# --- new strict/salvage behaviours (readers.py hardening, 2026-09) -------------

def test_parse_fixed_bunched_bc_year_any_width():
    # A bunched BC year must parse as negative whether it is 5 chars (-1000) or
    # 4 chars (-990). The 4-char case used to mis-read as +990 (the '-' fell into
    # the ID field), fragmenting long chronologies like turk029's Gordion series.
    from dplpy.readers import _parse_fixed
    sid, yr, _ = _parse_fixed("600610 -1000   150   160   170")
    assert (sid, yr) == ("600610", -1000)
    sid, yr, _ = _parse_fixed("600610 -990    150   160   170")
    assert (sid, yr) == ("600610", -990)


def test_header_line_with_leading_number_not_read_as_series(tmp_path):
    # A 3-line ITRDB header whose line 1 carries a stray number in the decade
    # column (a street address / distance) must be skipped, not read as a phantom
    # series. Data/header classification is fixed-position only.
    lines = [
        "SITE   1 54 km from town                            SPP",
        "SITE   2 Country      Species        100M 1234 5678  __   1900 2000",
        "SITE   3 Investigator Name",
        _rwl_row("SITE01", 1900, [100, 110, 999]),
    ]
    p = tmp_path / "hdr.rwl"
    p.write_text("\n".join(lines) + "\n")
    df = _read_quiet(str(p))
    assert list(df.columns) == ["SITE01"]        # header line 1 is NOT a series


def test_tab_in_id_raises_naming_series(tmp_path):
    # A TAB after a 6-char ID shifts the columns (the parsed ID keeps the tab and
    # the year mis-reads). Strict refuses and names the offending series.
    rows = [
        _rwl_row("moo07b", 1790, [100, 110, 120, 130, 140, 150, 160, 170, 180, 999]),
        "moo07b\t1800" + "".join("%6d" % v for v in [200, 210, 999]),
    ]
    p = tmp_path / "tab.rwl"
    p.write_text("\n".join(rows) + "\n")
    with pytest.raises(ValueError) as e:
        dpl.readers(str(p), header=False, strict=True)
    msg = str(e.value)
    assert "TAB" in msg and "moo07b" in msg


def test_disjoint_out_of_order_same_id_merges(tmp_path):
    # The same ID in two disjoint blocks (later block earlier in time) is a
    # legitimately segmented series -- merge it (as dplR does), do not raise.
    rows = [
        _rwl_row("AAA1", 1900, [100, 110, 999]),
        _rwl_row("AAA1", 1850, [200, 210, 999]),
    ]
    p = tmp_path / "disjoint.rwl"
    p.write_text("\n".join(rows) + "\n")
    df = _read_quiet(str(p), header=False)
    assert df.loc[1850, "AAA1"] == pytest.approx(2.00)   # 200 / 100 (999 => 0.01 mm)
    assert df.loc[1900, "AAA1"] == pytest.approx(1.00)


def test_missing_terminator_infers_precision_from_siblings(tmp_path):
    # A series with no stop marker, when OTHER series in the file are terminated,
    # adopts the file's dominant precision and warns -- it does not raise.
    rows = [
        _rwl_row("AAA1", 1900, [100, 110, -9999]),   # terminated -> 0.001 mm
        _rwl_row("BBB1", 1900, [200, 210, 220]),     # no terminator
    ]
    p = tmp_path / "noterm.rwl"
    p.write_text("\n".join(rows) + "\n")
    with pytest.warns(UserWarning, match="no stop marker"):
        df = dpl.readers(str(p), header=False, strict=True)
    assert "BBB1" in df.columns
    assert df.loc[1900, "BBB1"] == pytest.approx(0.200)  # 200 / 1000 (inferred)


def test_no_terminators_anywhere_raises(tmp_path):
    # When NO series has a stop marker, precision cannot be inferred -> strict
    # refuses (naming the series).
    rows = [
        _rwl_row("AAA1", 1900, [100, 110, 120]),
        _rwl_row("BBB1", 1900, [200, 210, 220]),
    ]
    p = tmp_path / "none.rwl"
    p.write_text("\n".join(rows) + "\n")
    with pytest.raises(ValueError, match="no stop marker"):
        dpl.readers(str(p), header=False, strict=True)


def test_decade_misaligned_names_series(tmp_path):
    # A row carrying more values than fit before its next decade boundary is a
    # decade-alignment fault, not a fixed-width/column fault (the columns parse
    # cleanly). It is refused with a concise message that names the offending
    # series/year and does NOT mislabel it as a fixed-width column problem.
    row = "AAA1    1693" + "".join("%6d" % v for v in range(10))   # year 1693 + 10 vals
    p = tmp_path / "nfw.rwl"
    p.write_text(row + "\n")
    with pytest.raises(ValueError) as e:
        dpl.readers(str(p), header=False, strict=True)
    msg = str(e.value)
    assert "too many values" in msg and "AAA1" in msg
    assert "1693" in msg                       # names the offending row's year
    assert "does not parse as fixed-width" not in msg   # no longer mislabelled


# --- stop marker followed by missing padding (brit020's 568112) ---------------
def test_stop_marker_followed_by_missing_padding(tmp_path):
    # A 999 stop marker followed by a run of -999 "absent" padding (brit020 568112).
    # The 999 must be recognised as the terminator (0.01 mm), NOT read as a 9.99 mm
    # value; the series ends at the marker; the padding is ignored with a clear note;
    # and there is NO misleading "no stop marker" warning.
    p = tmp_path / "pad.rwl"
    p.write_text(
        "AAA     1900    50    60    70   999  -999  -999\n"
        "AAA     1910  -999  -999  -999  -999\n"
    )
    with warnings.catch_warnings(record=True) as rec:
        warnings.simplefilter("always")
        d = dpl.readers(str(p))
    msgs = " || ".join(str(w.message) for w in rec)
    assert "after its stop marker" in msgs          # the padding is noted
    assert "no stop marker" not in msgs             # NOT mislabelled unterminated
    assert d.loc[1900, "AAA"] == pytest.approx(0.50)   # 0.01 mm precision
    assert d.loc[1902, "AAA"] == pytest.approx(0.70)
    assert int(d["AAA"].dropna().index.max()) == 1902  # ends at the last real value
    assert 9.99 not in set(d["AAA"].dropna())          # 999 NOT read as a measurement


def test_stop_marker_padding_0001mm(tmp_path):
    # Same, for a 0.001 mm series: -9999 terminator then -999 padding. The -9999 is
    # found past the pad (0.001 mm), and the trailing -999 is ignored.
    p = tmp_path / "pad2.rwl"
    p.write_text("BBB     1900   500   600   700 -9999  -999\n")
    with warnings.catch_warnings(record=True) as rec:
        warnings.simplefilter("always")
        d = dpl.readers(str(p))
    msgs = " || ".join(str(w.message) for w in rec)
    assert "no stop marker" not in msgs
    assert d.loc[1900, "BBB"] == pytest.approx(0.500)   # 0.001 mm precision
    assert d.loc[1902, "BBB"] == pytest.approx(0.700)
    assert int(d["BBB"].dropna().index.max()) == 1902


# --- orphan block after a stop marker (roma009's f1-03) -----------------------
_ORPHAN = (
    "AAA     1980    50    60    70   999\n"   # AAA terminated 1980-1982 (0.01 mm)
    "AAA     1900    80    90   100\n"          # mislabeled fragment: same ID, unterminated
    "BBB     1910   110   120   130   999\n"    # the next series, intact
)


def test_orphan_after_stop_marker_raises_strict(tmp_path):
    # A block under an existing ID appearing AFTER that series' stop marker is an
    # orphan (a mislabeled fragment). Strict refuses the file with a clear message.
    p = tmp_path / "orphan.rwl"
    p.write_text(_ORPHAN)
    with pytest.raises(ValueError) as e:
        dpl.readers(str(p), header=False)
    msg = str(e.value)
    assert "after the stop marker" in msg
    assert "AAA" in msg and "1900" in msg


def test_orphan_after_stop_marker_salvage_drops_fragment(tmp_path):
    # Salvage keeps AAA at its terminated extent (1980-1982, no 9.99 from the 999),
    # drops the orphan 1900-1902 fragment (NOT joined), records it, and leaves the
    # next series BBB intact. AAA must NOT get a "no stop marker" warning.
    p = tmp_path / "orphan.rwl"
    p.write_text(_ORPHAN)
    with warnings.catch_warnings(record=True) as rec:
        warnings.simplefilter("always")
        d = dpl.readers(str(p), header=False, strict=False)
    msgs = " || ".join(str(w.message) for w in rec)
    a = d["AAA"]
    assert int(a.dropna().index.min()) == 1980            # fragment dropped, not joined
    assert int(a.dropna().index.max()) == 1982
    assert a.loc[1980] == pytest.approx(0.50)             # 0.01 mm precision (999 found)
    assert 9.99 not in set(a.dropna())                    # 999 not read as a value
    assert "no stop marker" not in msgs
    rpt = [r for r in d.attrs["dplpy_salvage"] if r["series"] == "AAA"]
    assert rpt and rpt[0]["issue"] == "post_marker_orphan"
    assert int(d["BBB"].dropna().index.min()) == 1910     # next series intact
    assert int(d["BBB"].dropna().index.max()) == 1912


# --- join switch: merge vs keep-separate for disjoint same-ID blocks -----------
_DISJOINT_DUP = (
    "AAA01   1900   100   200   300 -9999\n"   # AAA01 block 1: 1900-1902
    "AAA01   2000   400   500   600 -9999\n"   # AAA01 block 2: 2000-2002 (disjoint)
)


def test_join_true_merges_disjoint_blocks(tmp_path):
    p = tmp_path / "j.rwl"
    p.write_text(_DISJOINT_DUP)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        d = dpl.readers(str(p), header=False)            # join=True default
    assert list(d.columns) == ["AAA01"]                  # merged into one series
    assert d.loc[1900, "AAA01"] == pytest.approx(0.1)
    assert d.loc[2000, "AAA01"] == pytest.approx(0.4)
    # a genuine merge IS reported as combined
    assert [c["series"] for c in d.attrs["dplpy_combined"]] == ["AAA01"]


def test_join_false_keeps_disjoint_blocks_separate(tmp_path, capsys):
    p = tmp_path / "j.rwl"
    p.write_text(_DISJOINT_DUP)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        d = dpl.readers(str(p), header=False, join=False)
    assert list(d.columns) == ["AAA01", "AAA012"]        # kept as two separate series
    assert d.loc[1900, "AAA01"] == pytest.approx(0.1)
    assert d.loc[2000, "AAA012"] == pytest.approx(0.4)
    assert np.isnan(d.loc[2000, "AAA01"])                # not merged
    # a SPLIT must NOT be reported as combined (it is recorded as a split instead);
    # regression: join=False previously mislabeled the split series as combined.
    assert d.attrs["dplpy_combined"] == []
    splits = [r for r in d.attrs["dplpy_salvage"]
              if r["series"] == "AAA01" and r["action"].startswith("split")]
    assert len(splits) == 1 and "AAA012" in splits[0]["action"]
    # and the split is reported to the user (the counterpart of the merge report)
    out = capsys.readouterr().out
    assert "kept as separate series (join=False)" in out
    assert "AAA01: disjoint block kept as AAA012" in out


# --- advisory heads-ups: beyond-column content and short interior gaps ---------

def _rwl_row(sid, year, values):
    """Build one standard Tucson decadal row: 8-char id, 4-char year, then
    6-char right-justified value fields. Pass "" for a blank (missing) cell."""
    return sid.ljust(8) + str(year).rjust(4) + "".join(str(v).rjust(6) for v in values)


def _read_quiet(path, **kw):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        return dpl.readers(path, **kw)


def test_beyond_column_flags_truncated_value(tmp_path, capsys):
    # A value that overflows its 6-char field leaves a digit in the separator
    # column (col 73, 1-indexed): '3035' written with 3 leading spaces puts '5' at
    # col 72 (0-indexed), so only '303' is read. This must be flagged (ok049 case).
    p = tmp_path / "ovf.rwl"
    row = _rwl_row("LIN9A", 1830, [353, 835, 434, 390, 443, 267, 463, 372, 425]) + "   3035"
    p.write_text(row + "\n" +
                 _rwl_row("LIN9A", 1840, [88, 102, 145, 35, 65, 57, 110, 123, 328, -9999]) + "\n")
    d = _read_quiet(str(p), header=False)
    b = d.attrs["dplpy_beyond_column"]
    assert len(b) == 1
    assert b[0]["series"] == "LIN9A"
    assert b[0]["year"] == 1839                      # the 10th (last) value's year
    assert b[0]["in_column"] == "303"                # what was actually read
    assert b[0]["unparsed"] == "5"                   # the dropped digit
    assert b[0]["kind"] == "truncated_value"
    out = capsys.readouterr().out
    assert "beyond the last data column" in out      # announced with the success msg
    assert "LIN9A 1839" in out


def test_beyond_column_ignores_site_id(tmp_path):
    # A trailing site ID in the optional cols 74-78 (a blank separator column) is
    # standard ITRDB content and must NOT be flagged.
    p = tmp_path / "site.rwl"
    row = _rwl_row("SIT01A", 1900, [353, 835, 434, 390, 443, 267, 463, 372, 425, 353]) + " SITE"
    p.write_text(row + "\n" +
                 _rwl_row("SIT01A", 1910, [10, 20, 30, -9999]) + "\n")
    d = _read_quiet(str(p), header=False)
    assert d.attrs["dplpy_beyond_column"] == []      # site ID at col 74+ not flagged
    assert d.loc[1900, "SIT01A"] == pytest.approx(0.353)


def test_tab_in_id_padding_not_flagged(tmp_path):
    # va024 case: a tab replaces one space in the id->year gap. It parses correctly
    # (byte columns preserved, tab stripped) and must raise NO advisory.
    p = tmp_path / "tab.rwl"
    tabrow = "25B" + "\t" + "    " + "1930" + "".join(str(v).rjust(6) for v in
             [108, 97, 70, 65, 65, 54, 54, 47, 37, 47])
    p.write_text(_rwl_row("25B", 1920, [140, 162, 168, 195, 120, 142, 123, 130, 54, 76]) + "\n" +
                 tabrow + "\n" +
                 _rwl_row("25B", 1940, [41, 75, 51, -9999]) + "\n")
    d = _read_quiet(str(p), header=False)
    assert d.attrs["dplpy_beyond_column"] == []
    assert d.attrs["dplpy_interior_gaps"] == []
    assert d.loc[1930, "25B"] == pytest.approx(0.108)   # tab row read correctly


def test_short_interior_gap_reported(tmp_path, capsys):
    # A single blank year flanked by measured years (ok049 LIN01A 1939) is a likely
    # dropped value: recorded AND announced as a short gap.
    p = tmp_path / "gap.rwl"
    # 1930 decade with the 1939 cell (last) blank, then 1940 decade continues.
    p.write_text(
        _rwl_row("LIN01A", 1930, [1297, 1696, 1587, 1173, 1472, 1272, 1575, 1158, 1206, ""]) + "\n" +
        _rwl_row("LIN01A", 1940, [1366, 1322, 1332, 867, 886, -9999]) + "\n")
    d = _read_quiet(str(p), header=False)
    gaps = d.attrs["dplpy_interior_gaps"]
    assert len(gaps) == 1
    assert gaps[0]["series"] == "LIN01A"
    assert gaps[0]["short_gap_years"] == [1939]
    assert gaps[0]["max_run"] == 1
    import numpy as np
    assert np.isnan(d.loc[1939, "LIN01A"])           # the hole is a NaN
    out = capsys.readouterr().out
    assert "short interior gap" in out
    assert "LIN01A: 1939" in out


def test_long_interior_gap_recorded_but_not_announced(tmp_path, capsys):
    # A long interior gap (8 blank years between measured years) is almost always
    # structural (rot / disjoint segment), so it is recorded on df.attrs but NOT
    # surfaced as a heads-up (would be noise across the ITRDB).
    p = tmp_path / "longgap.rwl"
    p.write_text(
        _rwl_row("LNG01A", 1900, [100, "", "", "", "", "", "", "", "", 200]) + "\n" +
        _rwl_row("OTH01A", 1900, [50, 60, 70, -9999]) + "\n")
    d = _read_quiet(str(p), header=False)
    gaps = {g["series"]: g for g in d.attrs["dplpy_interior_gaps"]}
    assert "LNG01A" in gaps                            # recorded
    assert gaps["LNG01A"]["max_run"] == 8
    assert gaps["LNG01A"]["short_gap_years"] == []     # nothing short -> not announced
    out = capsys.readouterr().out
    assert "short interior gap" not in out


def test_non_utf8_file_reads_with_latin1_fallback(tmp_path):
    # A non-UTF-8 byte in a header comment (e.g. an accented investigator name,
    # the ITRDB norm for European sites) must not crash the reader. It falls back
    # to latin1 (lossless), warns, and records the encoding used.
    p = tmp_path / "latin1.rwl"
    lines = [
        "ABC01   invest. M\xfcller",                       # 0xFC in latin1
        "ABC01   1990   100   110   120   130   140   999",
    ]
    p.write_bytes(("\n".join(lines) + "\n").encode("latin1"))

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        df = dpl.readers(str(p))
    assert df.attrs["dplpy_encoding"] == "latin1"
    assert df.attrs["dplpy_encoding_assumed"] is True
    assert any("not valid UTF-8" in str(x.message) for x in w)
    assert "ABC01" in df.columns                           # data read fine

    # an explicit encoding is obeyed and does not warn
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        df2 = dpl.readers(str(p), encoding="latin1")
    assert df2.attrs["dplpy_encoding"] == "latin1"
    assert df2.attrs["dplpy_encoding_assumed"] is False
    assert not any("not valid UTF-8" in str(x.message) for x in w)


def test_precision_recorded_in_provenance():
    # The measurement precision each series was read at (0.01 or 0.001 mm) is now
    # recorded in df.attrs, with a flag when a file mixes the two.
    import io, contextlib
    def _quiet(fn, *a, **k):
        with contextlib.redirect_stdout(io.StringIO()):
            return fn(*a, **k)
    df = _quiet(dpl.readers, "tests/data/rwl/ca533.rwl")
    prec = df.attrs["dplpy_precision"]
    assert set(df.columns) <= set(prec)               # one entry per series
    assert set(prec.values()) == {0.01}               # ca533 is 0.01 mm throughout
    assert df.attrs["dplpy_mixed_precision"] is False
