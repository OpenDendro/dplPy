import dplpy as dpl
import pandas as pd
import pytest
import re
from unittest.mock import patch, Mock

def mock_get_running_rbar_method(data, min_seg_ratio, method="osborn", corr_type="pearson"):
    return 1.0

def mock_get_mean_series_intercorr_method(data_set, corr_type, min_seg_ratio, apply_mask=True):
    return 0.0

def mock_chron_method(input_df, biweight=False, prewhiten=False, plot=False):
    return pd.DataFrame(data={"std": [0.015, 0.035, 0.055, 0.075, 0.095, 0.115, 0.135, 0.155, 0.175, 0.195, 0.215, 0.235, 0.255, 0.275, 0.295, 0.315, 0.335, 0.355, 0.375, 0.395, 0.415, 0.435, 0.455, 0.475, 0.495, 0.515, 0.535, 0.555, 0.575, 0.595, 0.615, 0.635, 0.655, 0.675, 0.695, 0.715, 0.735, 0.755, 0.775, 0.795, 0.815, 0.835, 0.855, 0.875, 0.895, 0.915, 0.935, 0.955, 0.975, 0.995, 1.015, 1.035, 1.055, 1.075, 1.095, 1.115, 1.135, 1.155, 1.175, 1.195, 1.215, 1.235, 1.255, 1.275, 1.295, 1.315, 1.335, 1.355, 1.375, 1.395, 1.415, 1.435, 1.455, 1.475, 1.495, 1.515, 1.535, 1.555, 1.575, 1.595, 1.615, 1.635, 1.655, 1.675, 1.695, 1.715, 1.735, 1.755, 1.775, 1.795, 1.815, 1.835, 1.855, 1.875, 1.895, 1.915, 1.935, 1.955, 1.975, 1.995],
                                    "samp_depth": [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2]},
                                    index=pd.Index(data=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100], 
                                                    name="Year"))

import importlib
_m_chron_stabilized = importlib.import_module("dplpy.chron_stabilized")

@patch.object(_m_chron_stabilized, 'get_running_rbar')
@patch.object(_m_chron_stabilized, 'chron')
@patch.object(_m_chron_stabilized, 'mean_series_intercorrelation')
def test_chron_stabilized_valid_input(mock_mean_series_corr: Mock, mock_chron: Mock, mock_get_running_rbar: Mock):
    mock_mean_series_corr.side_effect = mock_get_mean_series_intercorr_method
    mock_chron.side_effect = mock_chron_method
    mock_get_running_rbar.side_effect = mock_get_running_rbar_method

    input_df = pd.DataFrame(data={"SeriesA": [0.01, 0.03, 0.05, 0.07, 0.09, 0.11, 0.13, 0.15, 0.17, 0.19, 0.21, 0.23, 0.25, 0.27, 0.29, 0.31, 0.33, 0.35, 0.37, 0.39, 0.41, 0.43, 0.45, 0.47, 0.49, 0.51, 0.53, 0.55, 0.57, 0.59, 0.61, 0.63, 0.65, 0.67, 0.69, 0.71, 0.73, 0.75, 0.77, 0.79, 0.81, 0.83, 0.85, 0.87, 0.89, 0.91, 0.93, 0.95, 0.97, 0.99, 1.01, 1.03, 1.05, 1.07, 1.09, 1.11, 1.13, 1.15, 1.17, 1.19, 1.21, 1.23, 1.25, 1.27, 1.29, 1.31, 1.33, 1.35, 1.37, 1.39, 1.41, 1.43, 1.45, 1.47, 1.49, 1.51, 1.53, 1.55, 1.57, 1.59, 1.61, 1.63, 1.65, 1.67, 1.69, 1.71, 1.73, 1.75, 1.77, 1.79, 1.81, 1.83, 1.85, 1.87, 1.89, 1.91, 1.93, 1.95, 1.97, 1.99],
                                    "SeriesB": [0.02, 0.04, 0.06, 0.08, 0.1, 0.12, 0.14, 0.16, 0.18, 0.2, 0.22, 0.24, 0.26, 0.28, 0.3, 0.32, 0.34, 0.36, 0.38, 0.4, 0.42, 0.44, 0.46, 0.48, 0.5, 0.52, 0.54, 0.56, 0.58, 0.6, 0.62, 0.64, 0.66, 0.68, 0.7, 0.72, 0.74, 0.76, 0.78, 0.8, 0.82, 0.84, 0.86, 0.88, 0.9, 0.92, 0.94, 0.96, 0.98, 1.0, 1.02, 1.04, 1.06, 1.08, 1.1, 1.12, 1.14, 1.16, 1.18, 1.2, 1.22, 1.24, 1.26, 1.28, 1.3, 1.32, 1.34, 1.36, 1.38, 1.4, 1.42, 1.44, 1.46, 1.48, 1.5, 1.52, 1.54, 1.56, 1.58, 1.6, 1.62, 1.64, 1.66, 1.68, 1.7, 1.72, 1.74, 1.76, 1.78, 1.8, 1.82, 1.84, 1.86, 1.88, 1.9, 1.92, 1.94, 1.96, 1.98, 2.0]},
                                    index=pd.Index(data=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100], 
                                                    name="Year"))
    
    result_chron = dpl.chron_stabilized(input_df, running_rbar=True)
    expected_chron = pd.DataFrame(data={"vsc": [1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005, 1.005],
                                        "Running rbar": [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0],
                                    "samp_depth": [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2]},
                                    index=pd.Index(data=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100], 
                                                    name="Year"))
    
    pd.testing.assert_frame_equal(expected_chron, result_chron)

    # add test for specific args
    mock_mean_series_corr.assert_called_once()  
    mock_chron.assert_called_once()

    mock_get_running_rbar.assert_called()


@patch.object(_m_chron_stabilized, 'get_running_rbar')
@patch.object(_m_chron_stabilized, 'chron')
@patch.object(_m_chron_stabilized, 'mean_series_intercorrelation')
def test_chron_stabilized_wrong_input_type(mock_mean_series_corr: Mock, mock_chron: Mock, mock_get_running_rbar: Mock):
    mock_mean_series_corr.side_effect = mock_get_mean_series_intercorr_method
    mock_chron.side_effect = mock_chron_method
    mock_get_running_rbar.side_effect = mock_get_running_rbar_method

    with pytest.raises(TypeError) as errorMsg:
        dpl.chron_stabilized("data")
    expected_msg = "Expected dataframe input, got <class 'str'> instead."
    assert expected_msg == str(errorMsg.value)

    mock_mean_series_corr.assert_not_called()
    mock_chron.assert_not_called()
    mock_get_running_rbar.assert_not_called()


@patch.object(_m_chron_stabilized, 'get_running_rbar')
@patch.object(_m_chron_stabilized, 'chron')
@patch.object(_m_chron_stabilized, 'mean_series_intercorrelation')
def test_chron_stabilized_invalid_winlen(mock_mean_series_corr: Mock, mock_chron: Mock, mock_get_running_rbar: Mock):
    mock_mean_series_corr.side_effect = mock_get_mean_series_intercorr_method
    mock_chron.side_effect = mock_chron_method
    mock_get_running_rbar.side_effect = mock_get_running_rbar_method

    input_df = pd.DataFrame(data={"SeriesA": [0.01, 0.03, 0.05, 0.07, 0.09, 0.11, 0.13, 0.15, 0.17, 0.19, 0.21, 0.23, 0.25, 0.27, 0.29, 0.31, 0.33, 0.35, 0.37, 0.39, 0.41, 0.43, 0.45, 0.47, 0.49, 0.51, 0.53, 0.55, 0.57, 0.59, 0.61, 0.63, 0.65, 0.67, 0.69, 0.71, 0.73, 0.75, 0.77, 0.79, 0.81, 0.83, 0.85, 0.87, 0.89, 0.91, 0.93, 0.95, 0.97, 0.99, 1.01, 1.03, 1.05, 1.07, 1.09, 1.11, 1.13, 1.15, 1.17, 1.19, 1.21, 1.23, 1.25, 1.27, 1.29, 1.31, 1.33, 1.35, 1.37, 1.39, 1.41, 1.43, 1.45, 1.47, 1.49, 1.51, 1.53, 1.55, 1.57, 1.59, 1.61, 1.63, 1.65, 1.67, 1.69, 1.71, 1.73, 1.75, 1.77, 1.79, 1.81, 1.83, 1.85, 1.87, 1.89, 1.91, 1.93, 1.95, 1.97, 1.99],
                                    "SeriesB": [0.02, 0.04, 0.06, 0.08, 0.1, 0.12, 0.14, 0.16, 0.18, 0.2, 0.22, 0.24, 0.26, 0.28, 0.3, 0.32, 0.34, 0.36, 0.38, 0.4, 0.42, 0.44, 0.46, 0.48, 0.5, 0.52, 0.54, 0.56, 0.58, 0.6, 0.62, 0.64, 0.66, 0.68, 0.7, 0.72, 0.74, 0.76, 0.78, 0.8, 0.82, 0.84, 0.86, 0.88, 0.9, 0.92, 0.94, 0.96, 0.98, 1.0, 1.02, 1.04, 1.06, 1.08, 1.1, 1.12, 1.14, 1.16, 1.18, 1.2, 1.22, 1.24, 1.26, 1.28, 1.3, 1.32, 1.34, 1.36, 1.38, 1.4, 1.42, 1.44, 1.46, 1.48, 1.5, 1.52, 1.54, 1.56, 1.58, 1.6, 1.62, 1.64, 1.66, 1.68, 1.7, 1.72, 1.74, 1.76, 1.78, 1.8, 1.82, 1.84, 1.86, 1.88, 1.9, 1.92, 1.94, 1.96, 1.98, 2.0]},
                                    index=pd.Index(data=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100], 
                                                    name="Year"))
    
    with pytest.raises(ValueError) as errorMsg:
        dpl.chron_stabilized(input_df, win_length=101)
    
    expected_msg = "Window length should not be greater than the number of rows in the dataset"
    assert expected_msg == str(errorMsg.value)

    mock_mean_series_corr.assert_not_called()
    mock_chron.assert_not_called()
    mock_get_running_rbar.assert_not_called()


@patch.object(_m_chron_stabilized, 'get_running_rbar')
@patch.object(_m_chron_stabilized, 'chron')
@patch.object(_m_chron_stabilized, 'mean_series_intercorrelation')
def test_chron_stabilized_invalid_min_seg_ratio(mock_mean_series_corr: Mock, mock_chron: Mock, mock_get_running_rbar: Mock):
    mock_mean_series_corr.side_effect = mock_get_mean_series_intercorr_method
    mock_chron.side_effect = mock_chron_method
    mock_get_running_rbar.side_effect = mock_get_running_rbar_method


    input_df = pd.DataFrame(data={"SeriesA": [0.01, 0.03, 0.05, 0.07, 0.09, 0.11, 0.13, 0.15, 0.17, 0.19, 0.21, 0.23, 0.25, 0.27, 0.29, 0.31, 0.33, 0.35, 0.37, 0.39, 0.41, 0.43, 0.45, 0.47, 0.49, 0.51, 0.53, 0.55, 0.57, 0.59, 0.61, 0.63, 0.65, 0.67, 0.69, 0.71, 0.73, 0.75, 0.77, 0.79, 0.81, 0.83, 0.85, 0.87, 0.89, 0.91, 0.93, 0.95, 0.97, 0.99, 1.01, 1.03, 1.05, 1.07, 1.09, 1.11, 1.13, 1.15, 1.17, 1.19, 1.21, 1.23, 1.25, 1.27, 1.29, 1.31, 1.33, 1.35, 1.37, 1.39, 1.41, 1.43, 1.45, 1.47, 1.49, 1.51, 1.53, 1.55, 1.57, 1.59, 1.61, 1.63, 1.65, 1.67, 1.69, 1.71, 1.73, 1.75, 1.77, 1.79, 1.81, 1.83, 1.85, 1.87, 1.89, 1.91, 1.93, 1.95, 1.97, 1.99],
                                    "SeriesB": [0.02, 0.04, 0.06, 0.08, 0.1, 0.12, 0.14, 0.16, 0.18, 0.2, 0.22, 0.24, 0.26, 0.28, 0.3, 0.32, 0.34, 0.36, 0.38, 0.4, 0.42, 0.44, 0.46, 0.48, 0.5, 0.52, 0.54, 0.56, 0.58, 0.6, 0.62, 0.64, 0.66, 0.68, 0.7, 0.72, 0.74, 0.76, 0.78, 0.8, 0.82, 0.84, 0.86, 0.88, 0.9, 0.92, 0.94, 0.96, 0.98, 1.0, 1.02, 1.04, 1.06, 1.08, 1.1, 1.12, 1.14, 1.16, 1.18, 1.2, 1.22, 1.24, 1.26, 1.28, 1.3, 1.32, 1.34, 1.36, 1.38, 1.4, 1.42, 1.44, 1.46, 1.48, 1.5, 1.52, 1.54, 1.56, 1.58, 1.6, 1.62, 1.64, 1.66, 1.68, 1.7, 1.72, 1.74, 1.76, 1.78, 1.8, 1.82, 1.84, 1.86, 1.88, 1.9, 1.92, 1.94, 1.96, 1.98, 2.0]},
                                    index=pd.Index(data=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100], 
                                                    name="Year"))
    
    with pytest.raises(ValueError) as errorMsg:
        dpl.chron_stabilized(input_df, min_seg_ratio=1.1)
    
    expected_msg = "min_seg_ratio cannot be <= 0 or > 1"
    assert expected_msg == str(errorMsg.value)

    mock_mean_series_corr.assert_not_called()
    mock_chron.assert_not_called()
    mock_get_running_rbar.assert_not_called()


@patch.object(_m_chron_stabilized, 'get_running_rbar')
@patch.object(_m_chron_stabilized, 'chron')
@patch.object(_m_chron_stabilized, 'mean_series_intercorrelation')
def test_chron_stabilized_weird_winlen(mock_mean_series_corr: Mock, mock_chron: Mock, mock_get_running_rbar: Mock):
    mock_mean_series_corr.side_effect = mock_get_mean_series_intercorr_method
    mock_chron.side_effect = mock_chron_method
    mock_get_running_rbar.side_effect = mock_get_running_rbar_method

    input_df = pd.DataFrame(data={"SeriesA": [0.01, 0.03, 0.05, 0.07, 0.09, 0.11, 0.13, 0.15, 0.17, 0.19, 0.21, 0.23, 0.25, 0.27, 0.29, 0.31, 0.33, 0.35, 0.37, 0.39, 0.41, 0.43, 0.45, 0.47, 0.49, 0.51, 0.53, 0.55, 0.57, 0.59, 0.61, 0.63, 0.65, 0.67, 0.69, 0.71, 0.73, 0.75, 0.77, 0.79, 0.81, 0.83, 0.85, 0.87, 0.89, 0.91, 0.93, 0.95, 0.97, 0.99, 1.01, 1.03, 1.05, 1.07, 1.09, 1.11, 1.13, 1.15, 1.17, 1.19, 1.21, 1.23, 1.25, 1.27, 1.29, 1.31, 1.33, 1.35, 1.37, 1.39, 1.41, 1.43, 1.45, 1.47, 1.49, 1.51, 1.53, 1.55, 1.57, 1.59, 1.61, 1.63, 1.65, 1.67, 1.69, 1.71, 1.73, 1.75, 1.77, 1.79, 1.81, 1.83, 1.85, 1.87, 1.89, 1.91, 1.93, 1.95, 1.97, 1.99],
                                    "SeriesB": [0.02, 0.04, 0.06, 0.08, 0.1, 0.12, 0.14, 0.16, 0.18, 0.2, 0.22, 0.24, 0.26, 0.28, 0.3, 0.32, 0.34, 0.36, 0.38, 0.4, 0.42, 0.44, 0.46, 0.48, 0.5, 0.52, 0.54, 0.56, 0.58, 0.6, 0.62, 0.64, 0.66, 0.68, 0.7, 0.72, 0.74, 0.76, 0.78, 0.8, 0.82, 0.84, 0.86, 0.88, 0.9, 0.92, 0.94, 0.96, 0.98, 1.0, 1.02, 1.04, 1.06, 1.08, 1.1, 1.12, 1.14, 1.16, 1.18, 1.2, 1.22, 1.24, 1.26, 1.28, 1.3, 1.32, 1.34, 1.36, 1.38, 1.4, 1.42, 1.44, 1.46, 1.48, 1.5, 1.52, 1.54, 1.56, 1.58, 1.6, 1.62, 1.64, 1.66, 1.68, 1.7, 1.72, 1.74, 1.76, 1.78, 1.8, 1.82, 1.84, 1.86, 1.88, 1.9, 1.92, 1.94, 1.96, 1.98, 2.0]},
                                    index=pd.Index(data=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100], 
                                                    name="Year"))
    
    expected_msg = "Window length greater than 50% of the chronology length is not recommended. Consider a shorter window.\n"
    with pytest.warns(UserWarning, match=re.escape(expected_msg)):
        dpl.chron_stabilized(input_df, win_length=100)


@patch.object(_m_chron_stabilized, 'get_running_rbar')
@patch.object(_m_chron_stabilized, 'chron')
@patch.object(_m_chron_stabilized, 'mean_series_intercorrelation')
def test_chron_stabilized_short_winlen(mock_mean_series_corr: Mock, mock_chron: Mock, mock_get_running_rbar: Mock):
    mock_mean_series_corr.side_effect = mock_get_mean_series_intercorr_method
    mock_chron.side_effect = mock_chron_method
    mock_get_running_rbar.side_effect = mock_get_running_rbar_method

    input_df = pd.DataFrame(data={"SeriesA": [0.01, 0.03, 0.05, 0.07, 0.09, 0.11, 0.13, 0.15, 0.17, 0.19, 0.21, 0.23, 0.25, 0.27, 0.29, 0.31, 0.33, 0.35, 0.37, 0.39, 0.41, 0.43, 0.45, 0.47, 0.49, 0.51, 0.53, 0.55, 0.57, 0.59, 0.61, 0.63, 0.65, 0.67, 0.69, 0.71, 0.73, 0.75, 0.77, 0.79, 0.81, 0.83, 0.85, 0.87, 0.89, 0.91, 0.93, 0.95, 0.97, 0.99, 1.01, 1.03, 1.05, 1.07, 1.09, 1.11, 1.13, 1.15, 1.17, 1.19, 1.21, 1.23, 1.25, 1.27, 1.29, 1.31, 1.33, 1.35, 1.37, 1.39, 1.41, 1.43, 1.45, 1.47, 1.49, 1.51, 1.53, 1.55, 1.57, 1.59, 1.61, 1.63, 1.65, 1.67, 1.69, 1.71, 1.73, 1.75, 1.77, 1.79, 1.81, 1.83, 1.85, 1.87, 1.89, 1.91, 1.93, 1.95, 1.97, 1.99],
                                    "SeriesB": [0.02, 0.04, 0.06, 0.08, 0.1, 0.12, 0.14, 0.16, 0.18, 0.2, 0.22, 0.24, 0.26, 0.28, 0.3, 0.32, 0.34, 0.36, 0.38, 0.4, 0.42, 0.44, 0.46, 0.48, 0.5, 0.52, 0.54, 0.56, 0.58, 0.6, 0.62, 0.64, 0.66, 0.68, 0.7, 0.72, 0.74, 0.76, 0.78, 0.8, 0.82, 0.84, 0.86, 0.88, 0.9, 0.92, 0.94, 0.96, 0.98, 1.0, 1.02, 1.04, 1.06, 1.08, 1.1, 1.12, 1.14, 1.16, 1.18, 1.2, 1.22, 1.24, 1.26, 1.28, 1.3, 1.32, 1.34, 1.36, 1.38, 1.4, 1.42, 1.44, 1.46, 1.48, 1.5, 1.52, 1.54, 1.56, 1.58, 1.6, 1.62, 1.64, 1.66, 1.68, 1.7, 1.72, 1.74, 1.76, 1.78, 1.8, 1.82, 1.84, 1.86, 1.88, 1.9, 1.92, 1.94, 1.96, 1.98, 2.0]},
                                    index=pd.Index(data=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100],
                                                    name="Year"))

    # win_length=25 is <=30 (triggers the absolute-floor warning) but is only
    # 25% of the 100-row chronology (well under the 50% relative-ceiling check),
    # so this should be the ONLY warning raised -- verifying the two checks
    # fire independently, matching dplR's chron.stabilized().
    expected_msg = "Window length less than 30 is not recommended. Consider a longer window.\n"
    with pytest.warns(UserWarning, match=re.escape(expected_msg)) as warning_record:
        dpl.chron_stabilized(input_df, win_length=25)
    assert len(warning_record) == 1


def test_rbar_uses_flat_mean_not_column_means():
    # dplR's chron.stabilized averages the windowed correlation matrix with a FLAT
    # mean -- mean(corMat, na.rm=TRUE), every retained pair weighted equally. A
    # mean-of-column-means drifts from dplR (~1e-4 on some windows) once the overlap
    # mask drops pairs unevenly across series. Build such a case (C and D never
    # overlap, so the mask is uneven) and confirm pairwise_corr_mean returns the
    # flat mean, not the column-means mean.
    import numpy as np
    import pandas as pd
    from dplpy.rbar import pairwise_corr_mean
    rng = np.random.default_rng(0)
    n = 40
    base = rng.standard_normal(n)
    df = pd.DataFrame({
        "A": base + 0.10 * rng.standard_normal(n),
        "B": base + 0.50 * rng.standard_normal(n),
        "C": base + 0.90 * rng.standard_normal(n),
        "D": -base + 0.30 * rng.standard_normal(n),
    })
    df.loc[:19, "C"] = np.nan      # C present years 20..39
    df.loc[20:, "D"] = np.nan      # D present years 0..19 -> C and D never overlap
    corr = df.corr()
    arr = corr.to_numpy(copy=True)
    np.fill_diagonal(arr, np.nan)
    pres = df.notnull().astype(int)
    overlap = (pres.T @ pres).to_numpy()
    masked = np.where(overlap >= 10, arr, np.nan)
    flat = np.nanmean(masked)
    col_means = np.nanmean(np.nanmean(masked, axis=0))

    impl = pairwise_corr_mean(df, "pearson", min_overlap=10, strict=False)
    assert abs(impl - flat) < 1e-12            # matches dplR's flat mean
    assert abs(flat - col_means) > 1e-3        # and the case is meaningful (they differ)
