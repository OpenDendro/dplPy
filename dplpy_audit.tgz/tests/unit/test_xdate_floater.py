import io
import contextlib

import numpy as np
import pandas as pd
import pytest

import dplpy as dpl


def _quiet(fn, *a, **k):
    with contextlib.redirect_stdout(io.StringIO()):
        return fn(*a, **k)


def _drop_and_recover(rwl_path, target, **kw):
    """Pull one dated series out of a collection, hand its bare ring widths back
    as a 'floating' series, and crossdate it against the remaining (dated) master.
    Returns (true_first, true_last, result)."""
    rwl = _quiet(dpl.readers, rwl_path)
    truth = rwl[target].dropna()
    reference = rwl.drop(columns=[target])
    res = _quiet(dpl.xdate_floater, reference, truth.to_numpy(),
                 series_name=target, verbose=False, **kw)
    return int(truth.index.min()), int(truth.index.max()), res


def test_recovers_known_date_ca533():
    first, last, res = _drop_and_recover("tests/data/rwl/ca533.rwl", "CAM011")
    assert res["best"]["min_year"] == first
    assert res["best"]["max_year"] == last


def test_recovers_known_date_co021():
    first, last, res = _drop_and_recover("tests/data/rwl/co021.rwl", "641114")
    assert res["best"]["min_year"] == first
    assert res["best"]["max_year"] == last


def test_recovers_date_when_floater_longer_than_reference():
    # Floating the deepest core (CAM211) removes it from the reference, so the
    # remaining leave-one-out master is SHORTER than the floater (ny > nx) and the
    # master lies entirely inside the floater at the correct offset. This used to
    # raise an IndexError in the sliding-search crawl (a negative-index slice);
    # it must now date correctly like any other series.
    first, last, res = _drop_and_recover("tests/data/rwl/ca533.rwl", "CAM211")
    assert res["best"]["min_year"] == first
    assert res["best"]["max_year"] == last


def test_future_best_date_is_flagged():
    # dplPy (unlike dplR) scores placements past the reference into future years.
    # If the WINNER lands past the present calendar year the date is impossible and
    # must be flagged. Build a floater whose true best placement runs into the
    # future: its first 60 rings match the reference's most recent 60 years, then
    # 10 more rings extend past the present.
    import datetime
    this = datetime.date.today().year
    rng = np.random.default_rng(7)
    s = rng.random(120) + 0.5
    years = list(range(this - 119, this + 1))          # reference ends at present
    ref = pd.DataFrame({"R%d" % k: s + rng.normal(0, 1e-3, 120) for k in range(4)},
                       index=years)
    floater = np.concatenate([s[60:120], rng.random(10) + 0.5])
    res = _quiet(dpl.xdate_floater, ref, floater, series_name="FUT01",
                 min_overlap=50, verbose=False)
    assert res["best"]["max_year"] > this
    assert res["best"]["date_warning"] == "future"


def test_normal_best_date_has_no_future_warning():
    _, _, res = _drop_and_recover("tests/data/rwl/ca533.rwl", "CAM011")
    assert res["best"]["date_warning"] is None


def test_fd_transform_recovers_date():
    first, last, res = _drop_and_recover("tests/data/rwl/ca533.rwl", "CAM011",
                                         transform="fd")
    assert res["best"]["min_year"] == first
    assert res["best"]["max_year"] == last


def test_best_is_by_t_and_decisive():
    _, _, res = _drop_and_recover("tests/data/rwl/ca533.rwl", "CAM011")
    stats = res["floater_cor_stats"]
    # table is sorted best-first by t, and the top match stands clearly above the rest
    assert stats["t"].iloc[0] == res["best"]["t"]
    assert stats["t"].iloc[0] - stats["t"].iloc[1] > 3.0
    assert (stats["n"] >= 50).all()             # every offset meets the minimum overlap
    span = stats["max_year"] - stats["min_year"] + 1
    assert (span == span.iloc[0]).all()         # full-timber span everywhere


def test_crossdating_stats_present_and_sane():
    _, _, res = _drop_and_recover("tests/data/rwl/ca533.rwl", "CAM011")
    for col in ("r", "t", "eff_df", "p_bonf", "n"):
        assert col in res["floater_cor_stats"].columns
    b = res["best"]
    for key in ("t", "eff_df", "p_bonf", "one_over_p", "isolation_factor"):
        assert key in b
    # the true date is a strong, highly significant match
    assert b["t"] > 3.5                          # classic acceptance threshold
    assert b["p_bonf"] < 0.01
    assert b["isolation_factor"] > 10            # clearly isolated from the runner-up


def test_effective_df_reduced_for_autocorrelation():
    # prewhitened series carry little autocorrelation, so eff_df stays near n;
    # differenced series carry induced (negative) AC, so eff_df drops below n.
    _, _, pw = _drop_and_recover("tests/data/rwl/ca533.rwl", "CAM011", transform="pw")
    _, _, fd = _drop_and_recover("tests/data/rwl/ca533.rwl", "CAM011", transform="fd")
    assert pw["best"]["eff_df"] <= pw["best"]["n"]
    assert fd["best"]["eff_df"] < fd["best"]["n"]        # differencing lowers eff df


def test_prewhiten_alias_and_transform_validation():
    rwl = _quiet(dpl.readers, "tests/data/rwl/ca533.rwl")
    truth = rwl["CAM011"].dropna().to_numpy()
    ref = rwl.drop(columns=["CAM011"])
    b_alias = _quiet(dpl.xdate_floater, ref, truth, prewhiten=True, verbose=False)["best"]
    b_pw = _quiet(dpl.xdate_floater, ref, truth, transform="pw", verbose=False)["best"]
    assert b_alias == b_pw
    with pytest.raises(ValueError):
        _quiet(dpl.xdate_floater, ref, truth, transform="bogus", verbose=False)


def test_accepts_series_list_and_dataframe():
    rwl = _quiet(dpl.readers, "tests/data/rwl/ca533.rwl")
    truth = rwl["CAM011"].dropna()
    ref = rwl.drop(columns=["CAM011"])
    b_arr = _quiet(dpl.xdate_floater, ref, truth.to_numpy(), verbose=False)["best"]
    b_list = _quiet(dpl.xdate_floater, ref, list(truth.to_numpy()), verbose=False)["best"]
    b_ser = _quiet(dpl.xdate_floater, ref, truth, verbose=False)["best"]
    b_df = _quiet(dpl.xdate_floater, ref, truth.to_frame(), verbose=False)["best"]
    assert b_arr == b_list == b_ser == b_df


def test_return_rwl_places_series():
    rwl = _quiet(dpl.readers, "tests/data/rwl/ca533.rwl")
    truth = rwl["CAM011"].dropna()
    ref = rwl.drop(columns=["CAM011"])
    res = _quiet(dpl.xdate_floater, ref, truth.to_numpy(), series_name="CAM011",
                 return_rwl=True, verbose=False)
    placed = res["placed"]
    assert list(placed.columns) == ["CAM011"]
    assert int(placed.index.min()) == res["best"]["min_year"]
    assert int(placed.index.max()) == res["best"]["max_year"]
    assert np.allclose(placed["CAM011"].to_numpy(), truth.to_numpy())
    assert "combined" in res


def test_min_overlap_validation():
    rwl = _quiet(dpl.readers, "tests/data/rwl/ca533.rwl")
    ref = rwl.drop(columns=["CAM011"])
    short = rwl["CAM011"].dropna().to_numpy()[:30]
    with pytest.raises(ValueError):
        _quiet(dpl.xdate_floater, ref, short, min_overlap=50, verbose=False)


def test_empty_series_raises():
    rwl = _quiet(dpl.readers, "tests/data/rwl/ca533.rwl")
    with pytest.raises(ValueError):
        _quiet(dpl.xdate_floater, rwl, [np.nan, np.nan], verbose=False)


def test_make_plot_runs():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    rwl = _quiet(dpl.readers, "tests/data/rwl/ca533.rwl")
    truth = rwl["CAM011"].dropna().to_numpy()
    ref = rwl.drop(columns=["CAM011"])
    res = _quiet(dpl.xdate_floater, ref, truth, series_name="CAM011",
                 plot=True, verbose=False)
    assert "placed" in res            # make_plot also builds the placed series
    plt.close("all")


def test_poor_match_plot_keeps_p_thresholds_in_panel():
    # A poor match (best p ~1) must not push the p=0.05 / p=0.0001 threshold labels
    # outside the p-value panel (which ballooned the figure with white space). The
    # inverted-log p-axis should always extend past the most significant threshold.
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    rng = np.random.default_rng(3)
    rwl = _quiet(dpl.readers, "tests/data/rwl/ca533.rwl")
    res = _quiet(dpl.xdate_floater, rwl, rng.random(250) + 0.5,
                 series_name="RANDOM", plot=True, verbose=False)
    assert res["best"]["p_bonf"] > 0.05             # genuinely a poor match
    # find the inverted log-scaled p-axis and confirm it reaches below 1e-4
    fig = plt.gcf()
    p_axes = [ax for ax in fig.axes
              if ax.get_yscale() == "log" and ax.get_ylim()[1] < ax.get_ylim()[0]]
    assert p_axes, "no inverted log p-axis found"
    assert min(p_axes[0].get_ylim()) <= 1e-4        # thresholds fit inside the panel
    plt.close("all")


def test_exported():
    assert hasattr(dpl, "xdate_floater")


def test_reference_accepts_series():
    # The reference (data) may be a single chronology passed as a pandas Series
    # (e.g. crn["std"] from dpl.read_crn), not only a DataFrame -- and it must give
    # the same result as the equivalent one-column DataFrame (this used to raise a
    # TypeError from the DataFrame-only guard).
    rwl = _quiet(dpl.readers, "tests/data/rwl/ca533.rwl")
    floater = rwl["CAM021"].dropna()
    master = rwl.drop(columns=["CAM021"]).mean(axis=1).dropna()
    master.name = "master"
    r_series = _quiet(dpl.xdate_floater, master, floater, verbose=False)
    r_frame = _quiet(dpl.xdate_floater, master.to_frame(), floater, verbose=False)
    assert (r_series["best"]["min_year"], r_series["best"]["max_year"]) == \
           (r_frame["best"]["min_year"], r_frame["best"]["max_year"])


def _ref_and_core(rwl_path, target):
    """Leave-one-out reference plus the target's bare ring widths (an array), for
    the segment-consensus tests."""
    rwl = _quiet(dpl.readers, rwl_path)
    core = rwl[target].dropna()
    ref = rwl.drop(columns=[target])
    return ref, core


def test_segmented_clean_has_no_internal_error():
    # A correctly-measured floater dates internally consistently: every segment
    # points at the same youngest-ring year, so the consensus is unanimous and no
    # internal dating error is flagged.
    first, last, res = _drop_and_recover("tests/data/rwl/ca533.rwl", "CAM011",
                                         segmented=True)
    assert res["internal_error"] is None
    assert not res["segments"].empty
    assert len(res["consensus"]) >= 1
    assert int(res["consensus"].index[0]) == last          # dominant vote is the truth
    # segmented mode does not disturb the whole-series answer
    assert res["best"]["max_year"] == last


def test_segmented_detects_missing_ring():
    # Drop one interior ring (a locally-absent ring the measurer missed): the rings
    # OLDER than the gap are now one short, so they date one year EARLY, while the
    # younger rings still date true. The step between the two blocks is the
    # signature of a missing ring, which a whole-series slide cannot reveal.
    ref, core = _ref_and_core("tests/data/rwl/ca533.rwl", "CAM011")
    clean_last = int(core.index.max())
    damaged = np.delete(core.to_numpy(), 249)              # remove ring at index 249
    res = _quiet(dpl.xdate_floater, ref, damaged, series_name="CAM011",
                 segmented=True, verbose=False)
    diag = res["internal_error"]
    assert diag is not None
    assert diag["kind"] == "missing"
    assert diag["reliable_end"] == clean_last              # younger rings date true
    assert diag["other_end"] == diag["reliable_end"] - 1   # older rings one year early


def test_segmented_detects_false_ring():
    # Insert a duplicate ring (a false ring measured as real): the rings OLDER than
    # the insertion carry one ring too many, so they date one year LATE while the
    # younger rings date true -- the opposite step from a missing ring.
    ref, core = _ref_and_core("tests/data/rwl/ca533.rwl", "CAM011")
    clean_last = int(core.index.max())
    arr = core.to_numpy()
    damaged = np.insert(arr, 249, arr[249])               # duplicate ring at index 249
    res = _quiet(dpl.xdate_floater, ref, damaged, series_name="CAM011",
                 segmented=True, verbose=False)
    diag = res["internal_error"]
    assert diag is not None
    assert diag["kind"] == "false"
    assert diag["reliable_end"] == clean_last              # younger rings date true
    assert diag["other_end"] == diag["reliable_end"] + 1   # older rings one year late


def test_segmented_false_by_default_leaves_result_unchanged():
    # segmented is opt-in: without it the result carries none of the segment keys,
    # and turning it on must not change the whole-series best placement.
    rwl = _quiet(dpl.readers, "tests/data/rwl/ca533.rwl")
    truth = rwl["CAM011"].dropna().to_numpy()
    ref = rwl.drop(columns=["CAM011"])
    plain = _quiet(dpl.xdate_floater, ref, truth, series_name="CAM011",
                   verbose=False)
    seg = _quiet(dpl.xdate_floater, ref, truth, series_name="CAM011",
                 segmented=True, verbose=False)
    for key in ("segments", "consensus", "internal_error"):
        assert key not in plain
        assert key in seg
    assert plain["best"] == seg["best"]


def test_segmented_short_floater_reports_without_verdict():
    # A short floater yields fewer than four segments -- too few to test for an
    # internal dating error. The result must still carry the per-segment dates but
    # leave internal_error None rather than over-claiming a clean verdict.
    rwl = _quiet(dpl.readers, "tests/data/rwl/ca533.rwl")
    short = rwl["CAM011"].dropna().to_numpy()[:82]
    res = _quiet(dpl.xdate_floater, rwl, short, series_name="SHORT82",
                 segmented=True, verbose=False)
    assert len(res["segments"]) < 4
    assert res["internal_error"] is None
    assert not res["consensus"].empty


def test_segmented_consensus_matches_plotted_segments():
    # Regression: the reported consensus must be a vote count of the segments' own
    # single-best implied end years (what the staircase plot shows), so every year in
    # the consensus corresponds to a plotted point and the votes sum to one per
    # segment. The previous top-K tally could report a dominant year no segment placed.
    rwl = _quiet(dpl.readers, "tests/data/rwl/ca533.rwl")
    ref = rwl.drop(columns=["CAM011"])
    truth = rwl["CAM011"].dropna().to_numpy()
    res = _quiet(dpl.xdate_floater, ref, truth, series_name="CAM011",
                 segmented=True, verbose=False)
    plotted = set(int(e) for e in res["segments"]["impl_end"])
    assert set(int(e) for e in res["consensus"].index) == plotted
    assert int(res["consensus"].sum()) == len(res["segments"])


def test_segmented_candidates_expose_top_placements():
    # segment_candidates lists each segment's top placements; rank 1 must equal the
    # single-best recorded in res["segments"], r must fall with rank so a near-tie is
    # visible, and segment_topk caps the rows per segment.
    rwl = _quiet(dpl.readers, "tests/data/rwl/ca533.rwl")
    ref = rwl.drop(columns=["CAM011"])
    truth = rwl["CAM011"].dropna().to_numpy()
    res = _quiet(dpl.xdate_floater, ref, truth, series_name="CAM011",
                 segmented=True, segment_topk=3, verbose=False)
    cand = res["segment_candidates"]
    assert list(cand.columns) == ["ring_lo", "ring_hi", "rank", "impl_end", "r"]
    seg = res["segments"]
    for (lo, hi), g in cand.groupby(["ring_lo", "ring_hi"]):
        assert len(g) <= 3                                   # capped by segment_topk
        assert list(g["rank"]) == list(range(1, len(g) + 1))
        assert list(g["r"]) == sorted(g["r"], reverse=True)  # best-first
        row = seg[(seg["ring_lo"] == lo) & (seg["ring_hi"] == hi)].iloc[0]
        top = g[g["rank"] == 1].iloc[0]
        assert top["impl_end"] == row["impl_end"]            # rank 1 == single best
        assert top["r"] == row["best_r"]


def test_segmented_floater_name_collision_builds_combined():
    # If the floater's name already exists in the reference collection (a leave-one-out
    # test that did not drop the column), building "combined" must not crash on the
    # overlapping column name.
    rwl = _quiet(dpl.readers, "tests/data/rwl/ca533.rwl")
    truth = rwl["CAM011"].dropna().to_numpy()
    res = _quiet(dpl.xdate_floater, rwl, truth, series_name="CAM011",
                 return_rwl=True, verbose=False)          # rwl still contains CAM011
    assert "combined" in res
    assert list(res["placed"].columns) == ["CAM011"]


def test_ar_order_controls_affect_prewhitening():
    # The COFECHA-preset default (ar_max=10, first_aic_min=True) selects a lower AR
    # order than dplR's global-AIC rule for a high-order series like CAM011, so it
    # trims fewer early rings (more overlap) while recovering the same date.
    rwl = _quiet(dpl.readers, "tests/data/rwl/ca533.rwl")
    ref = rwl.drop(columns=["CAM011"])
    truth = rwl["CAM011"].dropna().to_numpy()
    cof = _quiet(dpl.xdate_floater, ref, truth, series_name="CAM011", verbose=False)
    dplr = _quiet(dpl.xdate_floater, ref, truth, series_name="CAM011",
                  ar_max=None, first_aic_min=False, verbose=False)
    assert cof["best"]["n"] > dplr["best"]["n"]              # fewer early rings trimmed
    assert (cof["best"]["min_year"], cof["best"]["max_year"]) == \
           (dplr["best"]["min_year"], dplr["best"]["max_year"])   # same recovered date


def test_series_name_derived_from_series_object():
    # When series_name is not given, take it from the floating series itself so the
    # outputs/plot title show the real name instead of "Unknown".
    rwl = _quiet(dpl.readers, "tests/data/rwl/ca533.rwl")
    ref = rwl.drop(columns=["CAM021"])
    col = rwl["CAM021"].dropna()
    # a named pandas Series and a one-column DataFrame both carry the name
    assert _quiet(dpl.xdate_floater, ref, col,
                  verbose=False)["series_name"] == "CAM021"
    assert _quiet(dpl.xdate_floater, ref, rwl[["CAM021"]].dropna(),
                  verbose=False)["series_name"] == "CAM021"
    # an explicit series_name still wins; a bare array has no name to take
    assert _quiet(dpl.xdate_floater, ref, col, series_name="MYCORE",
                  verbose=False)["series_name"] == "MYCORE"
    assert _quiet(dpl.xdate_floater, ref, col.to_numpy(),
                  verbose=False)["series_name"] == "Unknown"
